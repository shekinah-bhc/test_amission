"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const ProgramController_1 = require("../../controllers/admin/ProgramController");
const router = express_1.default.Router();
router.get("/", ProgramController_1.getDepartments);
router.get("/:id", ProgramController_1.getDepartmentById);
router.get("/:id/programs", ProgramController_1.getProgramsByDepartment);
router.get("/program/:programId", ProgramController_1.getProgramById);
exports.default = router;
