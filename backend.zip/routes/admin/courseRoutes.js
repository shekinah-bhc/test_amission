"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const CourseController_1 = require("../../controllers/admin/CourseController");
const router = express_1.default.Router();
router.get("/", CourseController_1.getCourses);
router.get("/:course_code", CourseController_1.getCourseBycourse_code);
router.post("/", CourseController_1.createCourse);
router.put("/:course_code", CourseController_1.updateCourse);
router.delete("/:course_code", CourseController_1.deleteCourse);
exports.default = router;
