"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const PartVClubController_1 = require("../../controllers/admin/PartVClubController");
const router = (0, express_1.Router)();
router.post("/", PartVClubController_1.createPartVClub); // CREATE
router.get("/", PartVClubController_1.getAllPartVClubs); // READ ALL
router.get("/:id", PartVClubController_1.getPartVClubById); // READ ONE
router.put("/:id", PartVClubController_1.updatePartVClub); // UPDATE
router.delete("/:id", PartVClubController_1.deletePartVClub); // DELETE
router.post("/migrate", PartVClubController_1.migrateCSVPartV); // Import  
router.post("/migrate/studentClub", PartVClubController_1.migrateCSVPartVStudentClub); // Update PartV club code data to partv
exports.default = router;
