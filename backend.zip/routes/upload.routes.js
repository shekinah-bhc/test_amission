"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const upload_controller_1 = require("../controllers/upload/upload.controller");
const fileUpload_controller_1 = require("../controllers/upload/fileUpload.controller");
const router = (0, express_1.Router)();
// ######################################################
router.post("/upload_single", upload_controller_1.upload.single("file"), fileUpload_controller_1.uploadFile);
router.post("/upload_multiple", upload_controller_1.uploadMultiple.array("files", 5), fileUpload_controller_1.uploadMultipleFiles);
// Delete file (JSON body: { filePath })
router.delete("/delete", fileUpload_controller_1.deleteFile);
// ######################################################
exports.default = router;
