"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const express_validator_1 = require("express-validator");
const ESEController_1 = require("../../controllers/student/ESEController");
const studentSeatingController_1 = require("../../controllers/student/studentSeatingController");
const router = express_1.default.Router();
router.get('/ese/:exam_no', (0, express_validator_1.param)('exam_no').isInt(), ESEController_1.getEsMarksByExamNo);
router.get('/seating/:rollno', studentSeatingController_1.getSeatAllocationByRollNo);
exports.default = router;
