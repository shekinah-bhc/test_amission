"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const validateStudent_1 = require("../../middlewares/validateStudent");
const studentController_1 = require("../../controllers/student/studentController");
const studentCalendar_controller_1 = require("../../controllers/student/studentCalendar.controller");
const router = express_1.default.Router();
/**
 * @swagger
 * /students:
 *   get:
 *     summary: Get all students
 *     tags: [student]
 *     servers:
 *       - url: http://localhost:5000/students
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                 count:
 *                   type: integer
 *       500:
 *         description: Error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                 error:
 *                   type: string
 */
router.get('/', validateStudent_1.validateRequest, studentController_1.getAllStudents);
router.get('/stat', studentController_1.getStudentStats);
/**
 * @swagger
 * /students/{roll_no}:
 *   get:
 *     summary: Get student by roll number
 *     tags: [student]
 *     servers:
 *       - url: http://localhost:5000/students
 *     parameters:
 *       - in: path
 *         name: roll_no
 *         required: true
 *         schema:
 *           type: integer
 *         description: Student roll number
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *       404:
 *         description: Student not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *       500:
 *         description: Error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                 error:
 *                   type: string
 */
router.get('/:roll_no', validateStudent_1.validateRequest, studentController_1.getStudentByRollno);
// ==============Calendar Route==========================
/**
 * @swagger
 * /student/calendar/current:
 *   get:
 *     summary: Get current academic year calendar for student
 *     description: |
 *       Fetches the complete academic calendar for the current academic year.
 *       Automatically detects the current academic year and active semester based on current date.
 *       Returns holidays, events, exams, and metadata for both odd and even semesters.
 *     tags: [student]
 *     responses:
 *       200:
 *         description: Successfully retrieved current student calendar
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/StudentCalendarResponse'
 *             examples:
 *               success:
 *                 summary: Current calendar data
 *                 value:
 *                   success: true
 *                   message: Current student calendar fetched successfully
 *                   data:
 *                     academicYear: "2024-2025"
 *                     currentSemester: "odd"
 *                     semesters:
 *                       odd:
 *                         holidays:
 *                           - title: "Diwali"
 *                             description: "Festival of Lights"
 *                             startDate: "2024-10-23T00:00:00.000Z"
 *                             endDate: "2024-10-25T00:00:00.000Z"
 *                             holidayType: "National"
 *                             createdBy: "Admin"
 *                         events:
 *                           - title: "Sports Day"
 *                             description: "Annual sports competition"
 *                             startDate: "2024-11-15T00:00:00.000Z"
 *                             endDate: "2024-11-17T00:00:00.000Z"
 *                             eventType: "Sports"
 *                             createdBy: "Sports Committee"
 *                         exams:
 *                           internal1:
 *                             startDate: "2024-09-01T00:00:00.000Z"
 *                             endDate: "2024-09-10T00:00:00.000Z"
 *                             title: "Internal Assessment 1"
 *                           internal2:
 *                             startDate: "2024-11-01T00:00:00.000Z"
 *                             endDate: "2024-11-10T00:00:00.000Z"
 *                             title: "Internal Assessment 2"
 *                           practical:
 *                             startDate: "2024-12-01T00:00:00.000Z"
 *                             endDate: "2024-12-10T00:00:00.000Z"
 *                             title: "Practical Exams"
 *                           ese:
 *                             startDate: "2024-12-15T00:00:00.000Z"
 *                             endDate: "2024-12-30T00:00:00.000Z"
 *                             title: "End Semester Exams"
 *                         metadata:
 *                           nationalHolidays: 5
 *                           collegeHolidays: 3
 *                           sportsEvents: 2
 *                           departmentEvents: 4
 *                           staffEvents: 1
 *                           studentEvents: 3
 *                           commonEvents: 2
 *                           totalWorkingDays: 120
 *                           totalWeeks: 16
 *                         semesterInfo:
 *                           startDate: "2024-06-01T00:00:00.000Z"
 *                           endDate: "2024-12-31T00:00:00.000Z"
 *                           semesterName: "Odd Semester"
 *                       even:
 *                         holidays: []
 *                         events: []
 *                         exams:
 *                           internal1: null
 *                           internal2: null
 *                           practical: null
 *                           ese: null
 *                         metadata:
 *                           nationalHolidays: 0
 *                           collegeHolidays: 0
 *                           sportsEvents: 0
 *                           departmentEvents: 0
 *                           staffEvents: 0
 *                           studentEvents: 0
 *                           commonEvents: 0
 *                           totalWorkingDays: 0
 *                           totalWeeks: 0
 *                         semesterInfo:
 *                           startDate: "2025-01-15T00:00:00.000Z"
 *                           endDate: "2025-05-31T00:00:00.000Z"
 *                           semesterName: "Even Semester"
 *                     combinedMetadata:
 *                       totalNationalHolidays: 5
 *                       totalCollegeHolidays: 3
 *                       totalEvents:
 *                         sports: 2
 *                         department: 4
 *                         staff: 1
 *                         student: 3
 *                         common: 2
 *                       totalWorkingDays: 120
 *                       totalWeeks: 16
 *       404:
 *         description: Current academic calendar not found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             example:
 *               success: false
 *               message: Current academic calendar not found
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ErrorResponse'
 *             example:
 *               success: false
 *               message: Internal server error
 *               error: "Database connection failed"
 */
router.get('/calendar/current', studentCalendar_controller_1.getCurrentStudentCalendar);
router.post('/login', validateStudent_1.validateRequest, studentController_1.studentLogin);
router.post('/migrate/partv', studentController_1.studentLogin);
exports.default = router;
