"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const studentLeaveApproval_controller_1 = require("../../controllers/staff/studentLeaveApproval.controller");
const router = express_1.default.Router();
// ========== STAFF ROUTES ==========
/**
 * @route   GET /api/staff/:staffId/leaves
 * @desc    Get leave applications for staff (class incharge/mentor)
 * @access  Private
 */
router.get('/:staffId/leaves', studentLeaveApproval_controller_1.getStaffLeaveApplications);
/**
 * @route   GET /api/staff/:staffId/dashboard
 * @desc    Get staff dashboard summary
 * @access  Private
 */
router.get('/:staffId/dashboard', studentLeaveApproval_controller_1.getStaffDashboard);
// ========== HOD ROUTES ==========
/**
 * @route   GET /api/hod/:staffId/leaves
 * @desc    Get leave applications for HOD (by department and shift)
 * @access  Private
 * @query   department - Department name
 * @query   shift - Shift (Shift-1/Shift-2)
 * @query   status - Filter by status
 */
router.get('/hod/:staffId/leaves', studentLeaveApproval_controller_1.getHODLeaveApplications);
/**
 * @route   GET /api/hod/:staffId/dashboard
 * @desc    Get HOD dashboard summary
 * @access  Private
 */
// router.get('/hod/:staffId/dashboard', getHODDashboard);
// ========== CLUB COORDINATOR ROUTES ==========
/**
 * @route   GET /api/club-coordinator/:staffId/leaves
 * @desc    Get leave applications for club coordinator
 * @access  Private
 * @query   clubName - Club name
 */
router.get('/club-coordinator/:staffId/leaves', studentLeaveApproval_controller_1.getClubCoordinatorLeaveApplications);
// ========== COMMON ROUTES ==========
/**
 * @route   POST /api/leave/:leaveId/approve
 * @desc    Approve/Reject a leave application (common for all roles)
 * @access  Private
 */
router.post('/leave/:leaveId/approve', studentLeaveApproval_controller_1.updateLeaveStatus);
exports.default = router;
