"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mentorship_controller_1 = require("../../controllers/staff/mentorship.controller");
const ChatMessageMentorship_1 = __importDefault(require("../../models/staff/ChatMessageMentorship"));
const router = (0, express_1.Router)();
/**
 * @swagger
 * /staff/mentorship/init:
 *   get:
 *     summary: Initialize mentorship for all departments
 *     tags: [Mentorship]
 *     responses:
 *       200:
 *         description: Mentorship system initialized successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Mentorship system initialized for all departments"
 */
router.get('/init', mentorship_controller_1.mentorshipController.initializeAllDepartments);
/**
 * @swagger
 * /staff/mentorship/{department_code}/staff:
 *   post:
 *     summary: Add new staff to mentorship
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: department_code
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [staff_id, stream, shift]
 *             properties:
 *               staff_id:
 *                 type: string
 *                 example: "STAFF001"
 *               stream:
 *                 type: string
 *                 enum: [Aided, Self-Finance]
 *                 example: "Self-Finance"
 *               shift:
 *                 type: string
 *                 enum: [Shift-1, Shift-2]
 *                 example: "Shift-1"
 *     responses:
 *       200:
 *         description: Staff added successfully
 *       400:
 *         description: Bad request
 *       404:
 *         description: Department not found
 */
router.post('/:department_code/staff', mentorship_controller_1.mentorshipController.addStaff);
/**
 * @swagger
 * /staff/mentorship/{department_code}/staff/{staff_id}/move:
 *   patch:
 *     summary: Move staff between shift/stream/department
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: department_code
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *       - in: path
 *         name: staff_id
 *         required: true
 *         schema:
 *           type: string
 *         example: "STAFF001"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [target_stream, target_shift]
 *             properties:
 *               target_department_code:
 *                 type: string
 *                 example: "IT"
 *               target_stream:
 *                 type: string
 *                 enum: [Aided, Self-Finance]
 *                 example: "Self-Finance"
 *               target_shift:
 *                 type: string
 *                 enum: [Shift-1, Shift-2]
 *                 example: "Shift-2"
 *     responses:
 *       200:
 *         description: Staff moved successfully
 *       404:
 *         description: Staff or department not found
 */
router.patch('/:department_code/staff/:staff_id/move', mentorship_controller_1.mentorshipController.moveStaff);
/**
 * @swagger
 * /staff/mentorship/{department_code}/staff/{staff_id}:
 *   delete:
 *     summary: Remove staff and move students to unassigned
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: department_code
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *       - in: path
 *         name: staff_id
 *         required: true
 *         schema:
 *           type: string
 *         example: "STAFF001"
 *     responses:
 *       200:
 *         description: Staff deleted successfully
 *       404:
 *         description: Staff not found
 */
router.delete('/:department_code/staff/:staff_id', mentorship_controller_1.mentorshipController.deleteStaff);
/**
 * @swagger
 * /staff/mentorship/{department_code}/assign:
 *   post:
 *     summary: Assign students to staff (batch assignment)
 *     tags: [Student]
 *     parameters:
 *       - name: department_code
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [staff_id, student_ids, stream, shift]
 *             properties:
 *               staff_id:
 *                 type: string
 *                 example: "STAFF001"
 *               student_ids:
 *                 type: array
 *                 items:
 *                   type: number
 *                 example: [12345, 12346, 12347]
 *               stream:
 *                 type: string
 *                 enum: [Aided, Self-Finance]
 *                 example: "Self-Finance"
 *               shift:
 *                 type: string
 *                 enum: [Shift-1, Shift-2]
 *                 example: "Shift-1"
 *     responses:
 *       200:
 *         description: Students assigned successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "2 new students assigned, 1 students moved from other mentors, 1 students already assigned"
 *                 data:
 *                   type: object
 *                   properties:
 *                     assigned:
 *                       type: array
 *                       items:
 *                         type: number
 *                       example: [12345, 12346]
 *                     moved:
 *                       type: array
 *                       items:
 *                         type: number
 *                       example: [12347]
 *                     already_assigned:
 *                       type: array
 *                       items:
 *                         type: number
 *                       example: [12348]
 *                     errors:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           student_id:
 *                             type: number
 *                             example: 12349
 *                           error:
 *                             type: string
 *                             example: "Student not found"
 *       400:
 *         description: Bad request - invalid input
 *       404:
 *         description: Staff, students, or department not found
 */
router.post('/:department_code/assign', mentorship_controller_1.mentorshipController.assignStudentToStaff);
/**
 * @swagger
 * /staff/mentorship/{department_code}/unassign:
 *   post:
 *     summary: Unassign a student and move to unassigned pool
 *     tags: [Student]
 *     parameters:
 *       - name: department_code
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [student_id, stream, shift, batch, program_code, program_type]
 *             properties:
 *               student_id:
 *                 type: number
 *                 example: 12345
 *               stream:
 *                 type: string
 *                 enum: [Aided, Self-Finance]
 *                 example: "Self-Finance"
 *               shift:
 *                 type: string
 *                 enum: [Shift-1, Shift-2]
 *                 example: "Shift-1"
 *               batch:
 *                 type: string
 *                 example: "2024"
 *               program_code:
 *                 type: string
 *                 example: "BSC-CS"
 *               program_type:
 *                 type: string
 *                 enum: [UG, PG]
 *                 example: "UG"
 *     responses:
 *       200:
 *         description: Student unassigned successfully
 *       404:
 *         description: Student not found
 */
router.post('/:department_code/unassign', mentorship_controller_1.mentorshipController.unassignStudent);
/**
 * @swagger
 * /staff/mentorship/{department_code}/student/{student_id}/move:
 *   patch:
 *     summary: Move student between shift/stream/department
 *     tags: [Student]
 *     parameters:
 *       - name: department_code
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *       - name: student_id
 *         in: path
 *         required: true
 *         schema:
 *           type: number
 *         example: 12345
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [target_stream, target_shift]
 *             properties:
 *               target_department_code:
 *                 type: string
 *                 example: "IT"
 *               target_stream:
 *                 type: string
 *                 enum: [Aided, Self-Finance]
 *                 example: "Self-Finance"
 *               target_shift:
 *                 type: string
 *                 enum: [Shift-1, Shift-2]
 *                 example: "Shift-2"
 *     responses:
 *       200:
 *         description: Student moved successfully
 *       404:
 *         description: Student not found
 */
router.patch('/:department_code/student/:student_id/move', mentorship_controller_1.mentorshipController.moveStudent);
/**
 * @swagger
 * /staff/mentorship/{department_code}/{staff_id}/{student_id}/session:
 *   post:
 *     summary: Add mentorship session
 *     tags: [Sessions]
 *     parameters:
 *       - name: department_code
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *       - name: staff_id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *         example: "STAFF001"
 *       - name: student_id
 *         in: path
 *         required: true
 *         schema:
 *           type: number
 *         example: 12345
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [session_date]
 *             properties:
 *               session_date:
 *                 type: string
 *                 format: date
 *                 example: "2024-01-15"
 *               next_session_date:
 *                 type: string
 *                 format: date
 *                 example: "2024-02-15"
 *               details_matters:
 *                 type: array
 *                 items:
 *                   type: string
 *                 example: ["Academic progress", "Career guidance"]
 *               mentor_feedback:
 *                 type: string
 *                 example: "Student is performing well"
 *               positive_traits:
 *                 type: string
 *                 example: "Good analytical skills"
 *               corrective_measures:
 *                 type: string
 *                 example: "Need to improve time management"
 *               status:
 *                 type: string
 *                 enum: [scheduled, completed, cancelled, rescheduled]
 *                 example: "completed"
 *     responses:
 *       200:
 *         description: Session created successfully
 *       400:
 *         description: Invalid session data
 */
router.post('/:department_code/:staff_id/:student_id/session', mentorship_controller_1.mentorshipController.createSession);
/**
 * @swagger
 * /staff/mentorship/{department_code}/{staff_id}/{student_id}/session/{session_index}:
 *   patch:
 *     summary: Update mentorship session
 *     tags: [Sessions]
 *     parameters:
 *       - in: path
 *         name: department_code
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *       - in: path
 *         name: staff_id
 *         required: true
 *         schema:
 *           type: string
 *         example: "STAFF001"
 *       - in: path
 *         name: student_id
 *         required: true
 *         schema:
 *           type: number
 *         example: 12345
 *       - in: path
 *         name: session_index
 *         required: true
 *         schema:
 *           type: integer
 *         example: 0
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               next_session_date:
 *                 type: string
 *                 format: date
 *                 example: "2024-03-15"
 *               mentor_feedback:
 *                 type: string
 *                 example: "Updated feedback"
 *               status:
 *                 type: string
 *                 enum: [scheduled, completed, cancelled, rescheduled]
 *                 example: "completed"
 *     responses:
 *       200:
 *         description: Session updated successfully
 *       404:
 *         description: Session not found
 */
router.patch('/:department_code/:staff_id/:student_id/session/:session_index', mentorship_controller_1.mentorshipController.updateSession);
/**
 * @swagger
 * /staff/mentorship/{department_code}:
 *   get:
 *     summary: Get mentorship structure for department
 *     tags: [Dashboard]
 *     parameters:
 *       - in: path
 *         name: department_code
 *         required: true
 *         schema:
 *           type: string
 *         example: "CS"
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 department_code:
 *                   type: string
 *                 department_name:
 *                   type: string
 *                 staff:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       staff_id:
 *                         type: string
 *                       name:
 *                         type: string
 *                       students:
 *                         type: array
 *                         items:
 *                           type: object
 *                 unassigned_students:
 *                   type: array
 *                   items:
 *                     type: object
 */
router.get('/:department_code', mentorship_controller_1.mentorshipController.getDepartmentMentorship);
router.get('/get_all_sessions', mentorship_controller_1.mentorshipController.getAllSessions);
router.get('/get_department_session/:department_code', mentorship_controller_1.mentorshipController.getDepartmentSession);
router.get('/get_student_session/:roll_no', mentorship_controller_1.mentorshipController.getStudentSession);
router.post("/chat", async (req, res) => {
    try {
        const { senderId, receiverId, message } = req.body;
        const chat = await ChatMessageMentorship_1.default.create({
            senderId,
            receiverId,
            message,
        });
        res.status(201).json(chat);
    }
    catch (err) {
        res.status(500).json({ error: "Message not sent" });
    }
});
router.get("/chat/:staff_id/:rollno", async (req, res) => {
    try {
        const { staff_id, rollno } = req.params;
        if (!staff_id || !rollno) {
            return res.status(400).json({ error: "Invalid user ids" });
        }
        const messages = await ChatMessageMentorship_1.default.find({
            $or: [
                { senderId: staff_id, receiverId: rollno },
                { senderId: rollno, receiverId: staff_id },
            ],
        })
            .sort({ createdAt: 1 }) // oldest → newest
            .limit(100)
            .lean(); // 🚀 faster + safer
        res.status(200).json(messages);
    }
    catch (error) {
        console.error("Chat fetch error:", error);
        res.status(500).json({ error: "Failed to fetch messages" });
    }
});
router.get("/messages/:staffId", async (req, res) => {
    try {
        const { staffId } = req.params;
        console.log(staffId);
        const messages = await ChatMessageMentorship_1.default.aggregate([
            {
                $match: {
                    $or: [
                        { senderId: staffId },
                        { receiverId: staffId },
                    ],
                },
            },
            { $sort: { createdAt: -1 } },
            {
                $group: {
                    _id: {
                        $cond: [
                            { $eq: ["$senderId", staffId] },
                            "$receiverId",
                            "$senderId",
                        ],
                    },
                    lastMessage: { $first: "$$ROOT" },
                },
            },
            { $replaceRoot: { newRoot: "$lastMessage" } },
            { $sort: { createdAt: -1 } },
        ]);
        res.json({
            messages,
        });
    }
    catch (error) {
        console.error("Fetch mentee messages error:", error);
        res.status(500).json({ error: "Failed to fetch messages" });
    }
});
router.put("/messages/:messageId/read", async (req, res) => {
    try {
        const { messageId } = req.params;
        await ChatMessageMentorship_1.default.findByIdAndUpdate(messageId, {
            read: true,
        });
        res.json({ success: true });
    }
    catch (error) {
        console.error("Mark message read error:", error);
        res.status(500).json({ error: "Failed to mark message as read" });
    }
});
router.put("/messages/read-all/:staffId", async (req, res) => {
    try {
        const { staffId } = req.params;
        await ChatMessageMentorship_1.default.updateMany({
            receiverId: staffId,
            read: false,
        }, {
            $set: { read: true },
        });
        res.json({ success: true });
    }
    catch (error) {
        console.error("Mark all messages read error:", error);
        res.status(500).json({ error: "Failed to mark all as read" });
    }
});
exports.default = router;
