"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadMultiple = exports.upload = void 0;
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const util_1 = require("../../services/util");
// Create folder if not exists
const ensureDir = (dirPath) => {
    if (!fs_1.default.existsSync(dirPath)) {
        fs_1.default.mkdirSync(dirPath, { recursive: true });
    }
};
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        const { roll_no, uploadFor } = req.body;
        if (!roll_no || !uploadFor) {
            return cb(new Error("roll_no and uploadFor are required"), "");
        }
        const uploadPath = path_1.default.join(util_1.__dirname, `../../uploads/${roll_no}/${uploadFor}`);
        ensureDir(uploadPath);
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const ext = path_1.default.extname(file.originalname);
        const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
        cb(null, uniqueName);
    }
});
exports.upload = (0, multer_1.default)({
    storage,
    limits: { fileSize: 15 * 1024 * 1024 },
});
// Add multiple upload middleware with max 5 files
exports.uploadMultiple = (0, multer_1.default)({
    storage,
    limits: { fileSize: 15 * 1024 * 1024, files: 5 }, // Max 5 files
    fileFilter: (req, file, cb) => {
        // Accept only specific file types
        const allowedTypes = [
            'application/pdf',
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/gif'
        ];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        }
        else {
            cb(new Error('Invalid file type. Only PDF, JPEG, JPG, PNG, GIF are allowed.'));
        }
    }
});
