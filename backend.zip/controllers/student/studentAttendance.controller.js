"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAttendanceSummary = exports.getSingleStudentFullAttendance = exports.markAttendanceByRollNumbers = exports.getClassAttendance = exports.syncSemesterDatesFromCalendar = exports.syncStudentAttendanceData = exports.initializeAllStudentsAttendance = void 0;
const AcademicCalendar_modal_1 = __importDefault(require("../../models/admin/AcademicCalendar.modal"));
const Student_1 = require("../../models/students/Student");
const Studentattendance_types_1 = require("../../interfaces/Studentattendance.types");
const StudentAttendance_model_1 = require("../../models/students/StudentAttendance.model");
const util_1 = require("../../services/util");
// ############################################################################################################################################
const initializeAllStudentsAttendance = async (req, res) => {
    try {
        const { academicYear } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({
            academicYear: academicYear
        });
        if (!academicCalendar) {
            return res.status(404).json({
                message: `Academic calendar not found for year: ${academicYear}`
            });
        }
        const sem_odd_startDate = academicCalendar.sem_odd?.startDate;
        const sem_odd_endDate = academicCalendar.sem_odd?.endDate;
        const sem_even_startDate = academicCalendar.sem_even?.startDate;
        const sem_even_endDate = academicCalendar.sem_even?.endDate;
        if (!sem_odd_startDate || !sem_odd_endDate || !sem_even_startDate || !sem_even_endDate) {
            return res.status(400).json({
                message: "Incomplete semester dates in academic calendar"
            });
        }
        const allStudents = await Student_1.Student.find({});
        if (!allStudents || allStudents.length === 0) {
            return res.status(404).json({
                message: "No students found"
            });
        }
        const initializedStudents = [];
        const skippedStudents = [];
        for (const student of allStudents) {
            try {
                const existingAttendance = await StudentAttendance_model_1.StudentAttendance.findOne({
                    roll_no: student.roll_no,
                    'attendanceRecords.academicYear': academicYear
                });
                if (existingAttendance) {
                    skippedStudents.push(student.roll_no.toString());
                    continue;
                }
                const academicYearAttendance = {
                    academicYear: academicYear,
                    sem_odd: {
                        semesterType: Studentattendance_types_1.Semester.ODD,
                        startDate: sem_odd_startDate,
                        endDate: sem_odd_endDate,
                        attendance: [],
                        leaves: [],
                        summary: {
                            totalWorkingDays: 0,
                            presentDays: 0,
                            absentDays: 0,
                            lateDays: 0,
                            onDutyDays: 0,
                            leaveDays: 0,
                            medicalLeaveDays: 0,
                            halfDays: 0,
                            holidayDays: 0,
                            attendancePercentage: 0,
                            casualLeaves: 0,
                            medicalLeaves: 0,
                            odLeaves: 0,
                            lastUpdated: new Date()
                        }
                    },
                    sem_even: {
                        semesterType: Studentattendance_types_1.Semester.EVEN,
                        startDate: sem_even_startDate,
                        endDate: sem_even_endDate,
                        attendance: [],
                        leaves: [],
                        summary: {
                            totalWorkingDays: 0,
                            presentDays: 0,
                            absentDays: 0,
                            lateDays: 0,
                            onDutyDays: 0,
                            leaveDays: 0,
                            medicalLeaveDays: 0,
                            halfDays: 0,
                            holidayDays: 0,
                            attendancePercentage: 0,
                            casualLeaves: 0,
                            medicalLeaves: 0,
                            odLeaves: 0,
                            lastUpdated: new Date()
                        }
                    }
                };
                await StudentAttendance_model_1.StudentAttendance.findOneAndUpdate({ roll_no: student.roll_no }, {
                    $setOnInsert: {
                        roll_no: student.roll_no,
                        name: student.name,
                        gender: student.personal_info?.gender,
                        department_code: student.current_academic?.department_code,
                        department_name: student.current_academic?.department_name,
                        program_id: student.current_academic?.program_code,
                        program_name: student.current_academic?.program_name,
                        section: student.current_academic?.section,
                        batch: student.batch,
                        shift: student.shift,
                        stream: student.stream,
                        part_five: student.current_academic?.part_five ? [student.current_academic.part_five] : [],
                        registredClubs: []
                    },
                    $push: { attendanceRecords: academicYearAttendance }
                }, { upsert: true, new: true });
                initializedStudents.push(student.roll_no.toString());
            }
            catch (error) {
                console.error(`Failed for student ${student.roll_no}:`, error);
                continue;
            }
        }
        return res.status(200).json({
            message: "Attendance initialization completed",
            totalStudents: allStudents.length,
            initialized: initializedStudents.length,
            skipped: skippedStudents.length,
            initializedStudents,
            skippedStudents
        });
    }
    catch (error) {
        console.error("Error initializing student attendance:", error);
        return res.status(500).json({
            message: "Error initializing student attendance",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};
exports.initializeAllStudentsAttendance = initializeAllStudentsAttendance;
const syncStudentAttendanceData = async (req, res) => {
    console.log("🔄 Starting Data Sync from Student model");
    try {
        const allStudents = await Student_1.Student.find({});
        console.log(`📊 Total students: ${allStudents.length}`);
        const updatedStudents = [];
        const errors = [];
        for (const student of allStudents) {
            const rollNo = student.roll_no.toString();
            try {
                const result = await StudentAttendance_model_1.StudentAttendance.updateOne({ roll_no: rollNo }, {
                    $set: {
                        name: student.name,
                        gender: student.personal_info?.gender,
                        department_code: student.current_academic?.department_code,
                        department_name: student.current_academic?.department_name,
                        program_id: student.current_academic?.program_code,
                        program_name: student.current_academic?.program_name,
                        section: student.current_academic?.section,
                        batch: student.batch,
                        shift: student.shift,
                        stream: student.stream,
                        part_five: student.current_academic?.part_five ? [student.current_academic.part_five] : []
                    }
                });
                if (result.modifiedCount > 0) {
                    updatedStudents.push(rollNo);
                    console.log(`✅ Updated: ${rollNo} - ${student.name}`);
                }
            }
            catch (error) {
                errors.push(`${rollNo}: ${error}`);
                console.log(`❌ Error updating ${rollNo}:`, error);
            }
        }
        console.log("\n📈 Sync Complete:");
        console.log(`   Updated: ${updatedStudents.length} students`);
        console.log(`   Errors: ${errors.length}`);
        return res.status(200).json({
            message: "Data sync completed",
            updated: updatedStudents.length,
            errors: errors.length,
            updatedStudents
        });
    }
    catch (error) {
        console.error("❌ Sync failed:", error);
        return res.status(500).json({
            message: "Sync failed",
            error: error
        });
    }
};
exports.syncStudentAttendanceData = syncStudentAttendanceData;
const syncSemesterDatesFromCalendar = async (req, res) => {
    console.log("📅 Syncing semester dates from academic calendar");
    try {
        const { academicYear } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                message: `Academic calendar not found for year: ${academicYear}`
            });
        }
        console.log(`✅ Calendar found for ${academicYear}`);
        const result = await StudentAttendance_model_1.StudentAttendance.updateMany({ 'attendanceRecords.academicYear': { $regex: `^${academicYear}$`, $options: 'i' } }, // FIXED
        {
            $set: {
                'attendanceRecords.$[record].sem_odd.startDate': academicCalendar.sem_odd.startDate,
                'attendanceRecords.$[record].sem_odd.endDate': academicCalendar.sem_odd.endDate,
                'attendanceRecords.$[record].sem_even.startDate': academicCalendar.sem_even.startDate,
                'attendanceRecords.$[record].sem_even.endDate': academicCalendar.sem_even.endDate
            }
        }, {
            arrayFilters: [
                { 'record.academicYear': { $regex: `^${academicYear}$`, $options: 'i' } } // FIXED
            ]
        });
        return res.status(200).json({
            message: "Semester dates synced successfully",
            academicYear,
            updated: {
                matched: result.matchedCount,
                modified: result.modifiedCount
            }
        });
    }
    catch (error) {
        console.error("❌ Error syncing semester dates:", error);
        return res.status(500).json({
            message: "Error syncing semester dates",
            error
        });
    }
};
exports.syncSemesterDatesFromCalendar = syncSemesterDatesFromCalendar;
// GET attendance by program and section
const getClassAttendance = async (req, res) => {
    try {
        const { program_id, section, batch, date } = req.params;
        console.log("📥 Received request:", { program_id, section, batch, date });
        if (!program_id || !section || !batch || !date) {
            return res.status(400).json({
                message: "program_id, section, batch and date are required"
            });
        }
        // Use the date string directly as key (YYYY-MM-DD format)
        const dateKey = date; // "2025-12-20"
        // Create a Date object for semester calculations
        const attendanceDate = new Date(date + 'T00:00:00.000Z'); // Force UTC timezone
        // OR for local timezone:
        // const attendanceDate = new Date(date);
        // attendanceDate.setHours(0, 0, 0, 0);
        console.log(`📅 Looking for date: ${dateKey}, Date object: ${attendanceDate.toISOString()}`);
        // Get semester info
        const semesterInfo = await (0, util_1.getCurrentSemester)(attendanceDate);
        if (!semesterInfo) {
            return res.status(400).json({
                message: "Date does not fall within an academic semester"
            });
        }
        // Find all students in class ordered by roll_no
        const students = await StudentAttendance_model_1.StudentAttendance.find({
            program_id,
            batch,
            section
        })
            .select("roll_no name attendanceRecords")
            .sort({ roll_no: 1 });
        if (!students.length) {
            return res.status(404).json({
                message: `No students found in program ${program_id}, section ${section}, batch ${batch}`
            });
        }
        const attendanceData = students.map(student => {
            // find academic year entry
            const academicRecord = student.attendanceRecords.find((rec) => rec.academicYear === semesterInfo.academicYear);
            let attendanceStatus = Studentattendance_types_1.AttendanceStatus.NOT_MARKED;
            let dayOrder = null;
            let hours = [];
            let attendanceType = null;
            let updatedBy = null;
            let updatedAt = null;
            let foundDateKey = null;
            if (academicRecord) {
                // choose semester
                const sem = semesterInfo.semester === Studentattendance_types_1.Semester.ODD
                    ? academicRecord.sem_odd
                    : academicRecord.sem_even;
                console.log(`  🔍 Searching for student ${student.roll_no} in semester ${semesterInfo.semester}`);
                console.log(`  📊 Total attendance entries: ${sem.attendance.length}`);
                // SIMPLE SOLUTION: Direct key matching
                // Find entry by exact date string key
                let attendanceEntry = null;
                let actualEntryKey = null;
                for (const item of sem.attendance) {
                    if (item && typeof item === 'object') {
                        const keys = Object.keys(item);
                        if (keys.length > 0) {
                            const key = keys[0];
                            console.log(`    Checking key: ${key} against ${dateKey}`);
                            // Direct string comparison
                            if (key === dateKey) {
                                attendanceEntry = item;
                                actualEntryKey = key;
                                break;
                            }
                            // Also try date object comparison
                            try {
                                const entryDate = new Date(key);
                                if (!isNaN(entryDate.getTime())) {
                                    const entryDateStr = entryDate.toISOString().split('T')[0];
                                    console.log(`    Also as date: ${entryDateStr}`);
                                    // Compare normalized dates
                                    const normalizedRequestDate = new Date(date + 'T00:00:00.000Z').toISOString().split('T')[0];
                                    if (entryDateStr === normalizedRequestDate) {
                                        attendanceEntry = item;
                                        actualEntryKey = key;
                                        break;
                                    }
                                }
                            }
                            catch (e) {
                                // Ignore parsing errors
                            }
                        }
                    }
                }
                if (attendanceEntry && actualEntryKey) {
                    console.log(`  ✅ Found attendance entry for ${actualEntryKey}`);
                    const dayAttendance = attendanceEntry[actualEntryKey];
                    attendanceStatus = dayAttendance.status || Studentattendance_types_1.AttendanceStatus.NOT_MARKED;
                    dayOrder = dayAttendance.dayOrder || null;
                    attendanceType = dayAttendance.attendanceType || null;
                    updatedBy = dayAttendance.updatedBy || null;
                    updatedAt = dayAttendance.updatedAt || null;
                    foundDateKey = actualEntryKey;
                    // Extract hours if attendanceType is "hourly"
                    if (attendanceType === "hourly" && dayAttendance.hours && Array.isArray(dayAttendance.hours)) {
                        hours = dayAttendance.hours.map((hourEntry) => ({
                            hour: hourEntry.hour,
                            status: hourEntry.status,
                            staffId: hourEntry.staffId,
                            updatedAt: new Date(hourEntry.updatedAt)
                        }));
                    }
                }
                else {
                    console.log(`  ❌ No attendance entry found for date ${dateKey}`);
                }
            }
            else {
                console.log(`  ⚠️  No academic record found for year ${semesterInfo.academicYear}`);
            }
            return {
                roll_no: student.roll_no,
                name: student.name,
                attendance: {
                    date: foundDateKey || dateKey,
                    status: attendanceStatus,
                    dayOrder: dayOrder,
                    attendanceType: attendanceType,
                    hours: hours,
                    updatedBy: updatedBy,
                    updatedAt: updatedAt,
                    semester: semesterInfo.semester,
                    academicYear: semesterInfo.academicYear
                }
            };
        });
        // Count students with attendance marked
        const markedAttendance = attendanceData.filter(s => s.attendance.status !== Studentattendance_types_1.AttendanceStatus.NOT_MARKED);
        return res.status(200).json({
            message: "Attendance fetched successfully",
            program_id,
            section,
            batch,
            date: dateKey,
            semester: semesterInfo.semester,
            academicYear: semesterInfo.academicYear,
            totalStudents: students.length,
            markedCount: markedAttendance.length,
            notMarkedCount: students.length - markedAttendance.length,
            attendanceData
        });
    }
    catch (error) {
        console.error("❌ Error fetching attendance:", error);
        return res.status(500).json({
            message: "Server error",
            error: error.message
        });
    }
};
exports.getClassAttendance = getClassAttendance;
/* ============================================================
   MARK ATTENDANCE BY ROLL NUMBERS (HOURLY)
   ============================================================ */
const defaultSummary = () => ({
    totalWorkingDays: 0,
    presentDays: 0,
    absentDays: 0,
    lateDays: 0,
    onDutyDays: 0,
    leaveDays: 0,
    medicalLeaveDays: 0,
    halfDays: 0,
    holidayDays: 0,
    attendancePercentage: 0,
    casualLeaves: 0,
    medicalLeaves: 0,
    odLeaves: 0,
    lastUpdated: new Date()
});
const markAttendanceByRollNumbers = async (req, res) => {
    try {
        const { staff_id, date, dayOrder, attendanceType, // "hourly" | "daily"
        hours = [], attendance_record } = req.body;
        // ───────────────── VALIDATION ─────────────────
        if (!staff_id || !date || !attendanceType || !attendance_record) {
            return res.status(400).json({ message: "Missing required fields" });
        }
        if (!Array.isArray(attendance_record)) {
            return res.status(400).json({ message: "attendance_record must be an array" });
        }
        if (attendanceType === "hourly" && (!Array.isArray(hours) || hours.length === 0)) {
            return res.status(400).json({
                message: "Hours array required for hourly attendance"
            });
        }
        const attendanceDate = new Date(`${date}T00:00:00.000Z`);
        const semesterInfo = await (0, util_1.getCurrentSemester)(attendanceDate);
        if (!semesterInfo) {
            return res.status(400).json({ message: "Invalid semester date" });
        }
        const results = {
            updated: 0,
            failed: 0,
            details: []
        };
        // ───────────────── PROCESS EACH STUDENT ─────────────────
        for (const record of attendance_record) {
            const { roll_no, status } = record;
            if (!roll_no || !status) {
                results.failed++;
                results.details.push({
                    roll_no: roll_no || "unknown",
                    reason: "Missing roll_no or status"
                });
                continue;
            }
            const enumStatus = Studentattendance_types_1.AttendanceStatus[status.toUpperCase()];
            if (!enumStatus) {
                results.failed++;
                results.details.push({
                    roll_no,
                    reason: `Invalid status: ${status}`
                });
                continue;
            }
            const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no });
            if (!student) {
                results.failed++;
                results.details.push({
                    roll_no,
                    reason: "Student not found"
                });
                continue;
            }
            // ─────────────── ACADEMIC YEAR ───────────────
            let academicYearRecord = student.attendanceRecords.find(r => r.academicYear === semesterInfo.academicYear);
            if (!academicYearRecord) {
                academicYearRecord = {
                    academicYear: semesterInfo.academicYear,
                    sem_odd: {
                        semesterType: Studentattendance_types_1.Semester.ODD,
                        startDate: new Date(),
                        endDate: new Date(),
                        attendance: [],
                        leaves: [],
                        summary: defaultSummary()
                    },
                    sem_even: {
                        semesterType: Studentattendance_types_1.Semester.EVEN,
                        startDate: new Date(),
                        endDate: new Date(),
                        attendance: [],
                        leaves: [],
                        summary: defaultSummary()
                    }
                };
                student.attendanceRecords.push(academicYearRecord);
            }
            const semesterRecord = semesterInfo.semester === Studentattendance_types_1.Semester.ODD
                ? academicYearRecord.sem_odd
                : academicYearRecord.sem_even;
            const dateKey = date; // Use the date string as key
            // Find existing attendance for this date
            const existingEntryIndex = semesterRecord.attendance.findIndex(a => a[dateKey]);
            let dailyAttendance;
            if (existingEntryIndex === -1) {
                // Create new attendance entry
                dailyAttendance = {
                    date: attendanceDate,
                    dayOrder: dayOrder || 0,
                    attendanceType,
                    status: Studentattendance_types_1.AttendanceStatus.NOT_MARKED,
                    hours: [],
                    updatedBy: staff_id,
                    updatedAt: new Date()
                };
                semesterRecord.attendance.push({ [dateKey]: dailyAttendance });
            }
            else {
                // Use existing attendance
                dailyAttendance = semesterRecord.attendance[existingEntryIndex][dateKey];
                // For existing entries, update dayOrder if provided
                if (dayOrder !== undefined) {
                    dailyAttendance.dayOrder = dayOrder;
                }
                // Update attendance type if different
                if (dailyAttendance.attendanceType !== attendanceType) {
                    dailyAttendance.attendanceType = attendanceType;
                }
            }
            // ───────────────── HOURLY ATTENDANCE ─────────────────
            if (attendanceType === "hourly") {
                // Convert all hours to string for consistency
                const hoursToMark = hours.map((h) => h.toString());
                // Process each hour
                for (const hourStr of hoursToMark) {
                    // Check if this specific hour already exists
                    const existingHourIndex = dailyAttendance.hours.findIndex(h => h.hour === hourStr);
                    if (existingHourIndex === -1) {
                        // Add new hour entry
                        dailyAttendance.hours.push({
                            hour: hourStr,
                            status: enumStatus,
                            staffId: staff_id,
                            updatedAt: new Date()
                        });
                    }
                    else {
                        // Update existing hour entry
                        dailyAttendance.hours[existingHourIndex] = {
                            hour: hourStr,
                            status: enumStatus,
                            staffId: staff_id,
                            updatedAt: new Date()
                        };
                    }
                }
                // Calculate overall daily status from hours
                const allHours = dailyAttendance.hours;
                if (allHours.length === 0) {
                    dailyAttendance.status = Studentattendance_types_1.AttendanceStatus.NOT_MARKED;
                }
                else if (allHours.some(h => h.status === Studentattendance_types_1.AttendanceStatus.ABSENT)) {
                    dailyAttendance.status = Studentattendance_types_1.AttendanceStatus.ABSENT;
                }
                else if (allHours.some(h => h.status === Studentattendance_types_1.AttendanceStatus.LATE)) {
                    dailyAttendance.status = Studentattendance_types_1.AttendanceStatus.LATE;
                }
                else if (allHours.some(h => h.status === Studentattendance_types_1.AttendanceStatus.PRESENT)) {
                    dailyAttendance.status = Studentattendance_types_1.AttendanceStatus.PRESENT;
                }
                else {
                    dailyAttendance.status = Studentattendance_types_1.AttendanceStatus.NOT_MARKED;
                }
            }
            // ───────────────── DAILY ATTENDANCE ─────────────────
            else if (attendanceType === "daily") {
                dailyAttendance.status = enumStatus;
                // Clear hours for daily attendance
                dailyAttendance.hours = [];
            }
            // Update metadata
            dailyAttendance.updatedBy = staff_id;
            dailyAttendance.updatedAt = new Date();
            // Save the student document
            try {
                student.markModified("attendanceRecords");
                await student.save();
                // ───────────── UPDATE SUMMARY ─────────────
                await (0, exports.updateAttendanceSummary)(student, semesterInfo.academicYear, semesterInfo.semester);
                results.updated++;
                results.details.push({
                    roll_no,
                    status: "UPDATED",
                    details: {
                        date,
                        attendanceType,
                        status: dailyAttendance.status,
                        dayOrder: dailyAttendance.dayOrder
                    }
                });
            }
            catch (saveError) {
                console.error(`Save error for ${roll_no}:`, saveError);
                results.failed++;
                results.details.push({
                    roll_no,
                    reason: `Save failed: ${saveError.message}`
                });
            }
        }
        return res.status(200).json({
            message: "Attendance processed",
            results: {
                total: attendance_record.length,
                ...results
            }
        });
    }
    catch (error) {
        console.error("Attendance Error:", error);
        return res.status(500).json({
            message: "Server error",
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
};
exports.markAttendanceByRollNumbers = markAttendanceByRollNumbers;
/* ============================================================
   Fetch Student attendance based on the roll_no
   ============================================================ */
const getSingleStudentFullAttendance = async (req, res) => {
    try {
        const { roll_no } = req.params;
        if (!roll_no) {
            return res.status(400).json({
                message: "roll_no is required"
            });
        }
        // 🔍 Find student ONLY by roll number
        const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no })
            .select("roll_no name attendanceRecords");
        if (!student) {
            return res.status(404).json({
                message: `Student with roll_no ${roll_no} not found`
            });
        }
        // Format attendance cleanly
        const formattedAttendance = student.attendanceRecords.map(record => ({
            academicYear: record.academicYear,
            sem_odd: record.sem_odd ? record.sem_odd.attendance : [],
            sem_even: record.sem_even ? record.sem_even.attendance : []
        }));
        return res.status(200).json({
            message: "Student attendance fetched successfully",
            roll_no: student.roll_no,
            name: student.name,
            attendance: formattedAttendance
        });
    }
    catch (error) {
        console.error("❌ Error fetching student attendance:", error);
        return res.status(500).json({
            message: "Server error",
            error: error.message
        });
    }
};
exports.getSingleStudentFullAttendance = getSingleStudentFullAttendance;
/* ============================================================
   SUMMARY UPDATE FUNCTION
   ============================================================ */
const updateAttendanceSummary = async (student, academicYear, semesterKey) => {
    const academicYearRecord = student.attendanceRecords.find((r) => r.academicYear === academicYear);
    if (!academicYearRecord)
        return;
    const semesterRecord = semesterKey === Studentattendance_types_1.Semester.ODD ? academicYearRecord.sem_odd : academicYearRecord.sem_even;
    const summary = semesterRecord.summary;
    summary.totalWorkingDays = semesterRecord.attendance.length;
    summary.presentDays = 0;
    summary.absentDays = 0;
    summary.lateDays = 0;
    summary.onDutyDays = 0;
    summary.leaveDays = 0;
    summary.medicalLeaveDays = 0;
    summary.halfDays = 0;
    summary.holidayDays = 0;
    for (const entry of semesterRecord.attendance) {
        const dateKey = Object.keys(entry)[0];
        const daily = entry[dateKey];
        switch (daily.status) {
            case Studentattendance_types_1.AttendanceStatus.PRESENT:
                summary.presentDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.LATE:
                summary.lateDays++;
                summary.presentDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.ABSENT:
                summary.absentDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.ON_DUTY:
                summary.onDutyDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.LEAVE:
                summary.leaveDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.MEDICAL_LEAVE:
                summary.medicalLeaveDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.HALF_DAY:
                summary.halfDays++;
                break;
            case Studentattendance_types_1.AttendanceStatus.HOLIDAY:
                summary.holidayDays++;
                break;
        }
    }
    const effectiveDays = summary.totalWorkingDays - summary.holidayDays;
    summary.attendancePercentage =
        effectiveDays > 0 ? (summary.presentDays / effectiveDays) * 100 : 0;
    summary.lastUpdated = new Date();
    student.markModified("attendanceRecords");
    await student.save();
};
exports.updateAttendanceSummary = updateAttendanceSummary;
