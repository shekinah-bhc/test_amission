"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCourse = exports.updateCourse = exports.createCourse = exports.getCourseBycourse_code = exports.getCourses = void 0;
const CourseMaster_1 = require("../../models/admin/CourseMaster");
const getCourses = async (req, res) => {
    try {
        const courses = await CourseMaster_1.CourseModel.find()
            .sort({ course_code: 1 });
        const totalCourses = await CourseMaster_1.CourseModel.countDocuments();
        return res.json({
            courses, "total course ": totalCourses
        });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getCourses = getCourses;
const getCourseBycourse_code = async (req, res) => {
    try {
        const course = await CourseMaster_1.CourseModel.findById(req.params.course_code);
        if (!course)
            return res.status(404).json({ message: "Course not found" });
        return res.json(course);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getCourseBycourse_code = getCourseBycourse_code;
const createCourse = async (req, res) => {
    try {
        const { course_code, course_title, course_type, language_type } = req.body;
        const course = new CourseMaster_1.CourseModel({ course_code, course_title, course_type, language_type });
        await course.save();
        return res.status(201).json(course);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.createCourse = createCourse;
const updateCourse = async (req, res) => {
    try {
        const course = await CourseMaster_1.CourseModel.findByIdAndUpdate(req.params.course_code, req.body, { new: true });
        if (!course)
            return res.status(404).json({ message: "Course not found" });
        return res.json(course);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.updateCourse = updateCourse;
const deleteCourse = async (req, res) => {
    try {
        const course = await CourseMaster_1.CourseModel.findByIdAndDelete(req.params.course_code);
        if (!course)
            return res.status(404).json({ message: "Course not found" });
        return res.json({ message: "Course deleted successfully" });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.deleteCourse = deleteCourse;
