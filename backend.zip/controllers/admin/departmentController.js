"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSection = exports.updateTimetableHour = exports.updateTimetable = exports.addProgram = exports.getProgramById = exports.getProgramsByDepartment = exports.deleteDepartment = exports.updateDepartment = exports.createDepartment = exports.getDepartmentByCode = exports.getDepartmentById = exports.getDepartments = void 0;
const Departments_1 = require("../../models/admin/Departments");
// Get all departments
const getDepartments = async (req, res) => {
    try {
        const departments = await Departments_1.DepartmentModel.find()
            .sort({ department_name: 1 });
        const totalDepartments = await Departments_1.DepartmentModel.countDocuments();
        return res.json({
            departments,
            "Total Department": totalDepartments
        });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getDepartments = getDepartments;
// Get department by ID
const getDepartmentById = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findById(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getDepartmentById = getDepartmentById;
// Get department by code
const getDepartmentByCode = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findOne({ department_code: req.params.code });
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getDepartmentByCode = getDepartmentByCode;
// Create a new department
const createDepartment = async (req, res) => {
    try {
        const { department_code, department_name, programs } = req.body;
        // Check if department already exists
        const existingDepartment = await Departments_1.DepartmentModel.findOne({ department_code });
        if (existingDepartment) {
            return res.status(400).json({ message: "Department with this code already exists" });
        }
        const department = new Departments_1.DepartmentModel({ department_code, department_name, programs });
        await department.save();
        return res.status(201).json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.createDepartment = createDepartment;
// Update a department
const updateDepartment = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.updateDepartment = updateDepartment;
// Delete a department
const deleteDepartment = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findByIdAndDelete(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json({ message: "Department deleted successfully" });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.deleteDepartment = deleteDepartment;
// Get programs by department ID
const getProgramsByDepartment = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findById(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department.programs);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getProgramsByDepartment = getProgramsByDepartment;
// Get specific program by ID
const getProgramById = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findOne({
            "programs.program_id": req.params.programId
        });
        if (!department)
            return res.status(404).json({ message: "Program not found" });
        const program = department.programs.find(p => p.program_id === req.params.programId);
        if (!program)
            return res.status(404).json({ message: "Program not found" });
        return res.json(program);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getProgramById = getProgramById;
// Add program to department - FIXED
const addProgram = async (req, res) => {
    try {
        const department = await Departments_1.DepartmentModel.findById(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        const { program_id, program_name, years } = req.body;
        // Check if program already exists
        const existingProgram = department.programs.find(p => p.program_id === program_id);
        if (existingProgram) {
            return res.status(400).json({ message: "Program with this ID already exists" });
        }
        // Use type assertion to avoid TypeScript errors
        department.programs.push({
            program_id,
            program_name,
            years: years || []
        });
        await department.save();
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.addProgram = addProgram;
// Update timetable for a specific section
const updateTimetable = async (req, res) => {
    try {
        const { departmentId, programId, year, sectionName } = req.params;
        const { TimeTable } = req.body;
        const department = await Departments_1.DepartmentModel.findById(departmentId);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        const program = department.programs.find(p => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: "Program not found" });
        const yearData = program.years.find(y => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: "Year not found" });
        const section = yearData.sections.find(s => s.section_name === sectionName);
        if (!section)
            return res.status(404).json({ message: "Section not found" });
        // Update the timetable
        section.TimeTable = TimeTable;
        await department.save();
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.updateTimetable = updateTimetable;
// Update specific hour in timetable
const updateTimetableHour = async (req, res) => {
    try {
        const { departmentId, programId, year, sectionName, dayOrder, hour } = req.params;
        const hourData = req.body;
        const department = await Departments_1.DepartmentModel.findById(departmentId);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        const program = department.programs.find(p => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: "Program not found" });
        const yearData = program.years.find(y => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: "Year not found" });
        const section = yearData.sections.find(s => s.section_name === sectionName);
        if (!section)
            return res.status(404).json({ message: "Section not found" });
        const day = section.TimeTable.find(d => d.dayOrder === parseInt(dayOrder));
        if (!day)
            return res.status(404).json({ message: "Day not found" });
        const hourToUpdate = day.hours.find(h => h.hour === parseInt(hour));
        if (!hourToUpdate)
            return res.status(404).json({ message: "Hour not found" });
        // Update the hour data
        Object.assign(hourToUpdate, hourData);
        await department.save();
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.updateTimetableHour = updateTimetableHour;
// Add a new section to a year - FIXED
const addSection = async (req, res) => {
    try {
        const { departmentId, programId, year } = req.params;
        const { section_name, section_shift, TimeTable } = req.body;
        const department = await Departments_1.DepartmentModel.findById(departmentId);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        const program = department.programs.find(p => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: "Program not found" });
        const yearData = program.years.find(y => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: "Year not found" });
        // Check if section already exists
        const existingSection = yearData.sections.find(s => s.section_name === section_name);
        if (existingSection) {
            return res.status(400).json({ message: "Section already exists" });
        }
        // Use type assertion to avoid TypeScript errors
        yearData.sections.push({
            section_name,
            section_shift,
            TimeTable: TimeTable || Array(6).fill(null).map((_, i) => ({
                dayOrder: i + 1,
                hours: Array(8).fill(null).map((_, j) => ({
                    hour: j + 1,
                    staff_id: "",
                    staffName: "",
                    course_code: "",
                    course_title: "",
                    course_type: "",
                    language_type: "",
                    room: "",
                    isScheduled: false
                }))
            }))
        });
        await department.save();
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.addSection = addSection;
