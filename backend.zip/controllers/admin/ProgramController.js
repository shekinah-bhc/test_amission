"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addCoursesToSemester = exports.getProgramById = exports.getProgramsByDepartment = exports.getDepartmentById = exports.getDepartments = void 0;
const Programs_1 = require("../../models/admin/Programs");
const getDepartments = async (req, res) => {
    try {
        const departments = await Programs_1.ProgramsModel.find()
            .sort({ department_name: 1 });
        const totalDepartments = await Programs_1.ProgramsModel.countDocuments();
        return res.json({
            departments, "totalDepartments": totalDepartments
        });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getDepartments = getDepartments;
const getDepartmentById = async (req, res) => {
    try {
        const department = await Programs_1.ProgramsModel.findById(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getDepartmentById = getDepartmentById;
const getProgramsByDepartment = async (req, res) => {
    try {
        const department = await Programs_1.ProgramsModel.findById(req.params.id);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        return res.json(department.program_Types);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getProgramsByDepartment = getProgramsByDepartment;
const getProgramById = async (req, res) => {
    try {
        const department = await Programs_1.ProgramsModel.findOne({
            "program_Types.programs.program_id": req.params.programId
        });
        if (!department)
            return res.status(404).json({ message: "Program not found" });
        let foundProgram = null;
        for (const programType of department.program_Types) {
            for (const program of programType.programs) {
                if (program.program_id === req.params.programId) {
                    foundProgram = program;
                    break;
                }
            }
            if (foundProgram)
                break;
        }
        if (!foundProgram)
            return res.status(404).json({ message: "Program not found" });
        return res.json(foundProgram);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.getProgramById = getProgramById;
const addCoursesToSemester = async (req, res) => {
    try {
        const { departmentId, programId, year, semester } = req.params;
        const { courses } = req.body;
        const department = await Programs_1.ProgramsModel.findById(departmentId);
        if (!department)
            return res.status(404).json({ message: "Department not found" });
        let programFound = false;
        const departmentObj = department.toObject();
        for (const programType of departmentObj.program_Types) {
            for (const program of programType.programs) {
                if (program.program_id === programId) {
                    programFound = true;
                    if (!program.years[year]) {
                        program.years[year] = { "semester-1": [], "semester-2": [] };
                    }
                    if (!program.years[year][semester]) {
                        program.years[year][semester] = [];
                    }
                    // Add courses
                    program.years[year][semester].push(...courses);
                    break;
                }
            }
            if (programFound)
                break;
        }
        if (!programFound)
            return res.status(404).json({ message: "Program not found" });
        // Mark the modified path and save
        department.markModified('program_Types');
        await department.save();
        return res.json(department);
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.addCoursesToSemester = addCoursesToSemester;
