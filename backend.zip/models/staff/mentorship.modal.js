"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.MentorshipModel = void 0;
const mongoose_1 = __importStar(require("mongoose"));
// ========== SESSION SCHEMA ==========
const sessionSchema = new mongoose_1.Schema({
    session_date: { type: Date, required: true },
    // 🔥 new field
    next_session_date: { type: Date, required: false },
    details_matters: [{ type: Object, trim: true, maxlength: 200 }],
    mentor_feedback: { type: String, trim: true, maxlength: 1000, default: '' },
    positive_traits: { type: String, trim: true, maxlength: 500, default: '' },
    corrective_measures: { type: String, trim: true, maxlength: 500, default: '' },
    status: {
        type: String,
        enum: ['scheduled', 'completed', 'cancelled', 'rescheduled'],
        default: 'scheduled'
    }
}, { timestamps: true });
// ========== MENTEE SCHEMA ==========
const menteeSchema = new mongoose_1.Schema({
    student_id: { type: Number, required: true, index: true },
    student_name: { type: String, required: true, trim: true, maxlength: 100 },
    student_email: {
        type: String,
        trim: true,
        lowercase: true,
        match: [/^[a-zA-Z0-9._%+-]+@bhc\.edu\.in$/, 'Invalid BHC email'],
        maxlength: 150
    },
    assigned_at: { type: Date, required: true },
    active_status: { type: Boolean, default: true, index: true },
    sessions: [sessionSchema]
}, { timestamps: true });
// ========== BATCH SCHEMAS ==========
// ⛔ No shared batchFields object – define inline to keep TS happy.
const assignedBatchSchema = new mongoose_1.Schema({
    batch: {
        type: String,
        required: true,
        match: [/^\d{4}-\d{4}$/, 'Batch must be in format YYYY-YYYY'],
        index: true
    },
    program_code: { type: String, required: true, uppercase: true, index: true },
    program_type: { type: String, enum: ['UG', 'PG'], required: true, index: true },
    students: [menteeSchema]
});
const unassignedBatchSchema = new mongoose_1.Schema({
    batch: {
        type: String,
        required: true,
        match: [/^\d{4}-\d{4}$/, 'Batch must be in format YYYY-YYYY'],
        index: true
    },
    program_code: { type: String, required: true, uppercase: true, index: true },
    program_type: { type: String, enum: ['UG', 'PG'], required: true, index: true },
    students: [menteeSchema]
});
// ========== STAFF MENTOR SCHEMA ==========
const staffMentorSchema = new mongoose_1.Schema({
    staff_id: { type: String, required: true, trim: true, index: true },
    staff_name: { type: String, required: true, trim: true, maxlength: 100 },
    staff_email: {
        type: String, required: true,
        trim: true,
        lowercase: true,
        match: [/^[a-zA-Z0-9._%+-]+@bhc\.edu\.in$/, 'Invalid BHC email'],
        index: true
    },
    designation: { type: String, trim: true, maxlength: 100 },
    max_students: { type: Number, default: 50, min: 1, max: 50 },
    assigned_students: {
        batches: [assignedBatchSchema]
    },
    active_status: { type: Boolean, default: true, index: true }
}, { timestamps: true });
// ========== DEPARTMENT MENTORSHIP SCHEMA (ROOT) ==========
const departmentMentorshipSchema = new mongoose_1.Schema({
    department_name: { type: String, required: true, trim: true, maxlength: 100 },
    department_code: {
        type: String,
        required: true,
        trim: true,
        uppercase: true,
        unique: true,
        index: true
    },
    streams: [{
            name: { type: String, enum: ['Aided', 'Self-Finance'], required: true },
            shifts: [{
                    name: { type: String, enum: ['Shift-1', 'Shift-2'], required: true },
                    staff_mentors: [staffMentorSchema],
                    unassigned_students: {
                        batches: [unassignedBatchSchema]
                    }
                }]
        }],
    active: { type: Boolean, default: true, index: true }
}, {
    timestamps: true,
    collection: 'department_mentorships'
});
// ========== VIRTUALS ==========
departmentMentorshipSchema.virtual('total_students').get(function () {
    let count = 0;
    this.streams.forEach((s) => s.shifts.forEach((sh) => {
        count += sh.staff_mentors.reduce((sum, m) => sum + m.assigned_students.batches.reduce((bSum, b) => bSum + b.students.length, 0), 0);
        count += sh.unassigned_students.batches.reduce((bSum, b) => bSum + b.students.length, 0);
    }));
    return count;
});
departmentMentorshipSchema.virtual('total_mentors').get(function () {
    return this.streams.reduce((total, s) => total + s.shifts.reduce((shiftTotal, sh) => shiftTotal + sh.staff_mentors.length, 0), 0);
});
departmentMentorshipSchema.virtual('unassigned_students_count').get(function () {
    return this.streams.reduce((total, s) => total + s.shifts.reduce((shiftTotal, sh) => shiftTotal + sh.unassigned_students.batches.reduce((bSum, b) => bSum + b.students.length, 0), 0), 0);
});
// ========== EXPORT MODEL ==========
exports.MentorshipModel = mongoose_1.default.model('DepartmentMentorship', departmentMentorshipSchema);
