"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffModel = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const IStaff_1 = require("../../interfaces/IStaff");
const StaffSchema = new mongoose_1.Schema({
    category: { type: String },
    staff_id: { type: String, required: true, unique: true },
    bio_id: { type: Number, unique: true },
    alt_staffid: { type: String, required: true },
    salute: { type: String, required: true },
    name: { type: String, required: true },
    gender: { type: String, enum: ["Male", "Female", "Other"], required: true },
    dob: { type: String, required: true },
    marital_status: String,
    college_email: { type: String, required: true },
    email: { type: String },
    phone: { type: String },
    alternate_phone: String,
    blood_group: String,
    nationality: String,
    religion: String,
    mother_tongue: String,
    community: String,
    address: {
        present: {
            street: String,
            city: String,
            state: String,
            pincode: String
        },
        permanent: {
            street: String,
            city: String,
            state: String,
            pincode: String
        }
    },
    designation: { type: String, required: true },
    // 🔹 Department section
    department: { type: mongoose_1.default.Schema.Types.ObjectId, ref: "Departments" },
    department_code: { type: String },
    department_name: { type: String, required: true },
    shift: { type: String, enum: ["Shift-1", "Shift-2"], default: "Shift-1" },
    stream: { type: String, enum: ["Aided", "Self-Finance"], default: "Self-Finance" },
    aadhar_number: Number,
    pan_number: String,
    joining_date: { type: String, required: true },
    employee_type: {
        type: String,
        enum: ["teaching", "non-teaching", 'gardener', 'security'],
        default: "teaching"
    },
    isActive: { type: Boolean, default: true },
    qualifications: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            degree: String,
            specialization: String,
            institution: String,
            year_of_passing: String,
            percentage_cgpa: String,
            certificate: String
        }],
    experience: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            type: { type: String, enum: ["teaching", "industry"] },
            organization: String,
            role: String,
            from: Date,
            to: Date,
            years: Number
        }],
    class_attend: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            department_name: String,
            program_id: String,
            year: String,
            section_name: String,
            dayOrder: Number,
            hour: Number,
            incharge: Boolean,
        }],
    research_expertise: {
        broad_area: [String],
        specialization: [String]
    },
    isDoctorate: { type: Boolean, default: false },
    phd_details: {
        thesis_title: String,
        guide_name: String,
        co_guide_name: String,
        university: String,
        registration_year: Number,
        awarded_year: Number,
        status: { type: String, enum: ["awarded", "submitted", "pursuing"] }
    },
    research_guidance: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            scholar_name: String,
            register_no: String,
            degree: { type: String, enum: ["PhD", "M.Phil"] },
            university_name: String,
            status: { type: String, enum: ["ongoing", "completed"] },
            joining_year: Number,
            awarded_year: Number
        }],
    publications: {
        journal_articles: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                journal_name: String,
                issn: String,
                volume: String,
                issue: String,
                pages: String,
                doi: String,
                year: String,
                level: { type: String, enum: ["International", "National", "Regional", "Institutional"] },
                indexing: { type: String, enum: ["Scopus", "Web of Science", "UGC Care", "Others"] },
                impact_factor: Number,
                citation_count: Number,
                author_position: String,
                link: String,
                authors: [{ type: String }], // Array of authors (max 5)
                co_authors: [{ type: String }] // Array of co-authors (max 5)
            }],
        conference_papers: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                conference_name: String,
                isbn: String,
                location: String,
                year: String,
                level: { type: String, enum: ["International", "National", "Regional", "Institutional"] },
                publisher: String,
                indexing: String,
                authors: [{ type: String }],
                co_authors: [{ type: String }]
            }],
        book_chapters: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                book_title: String,
                publisher: String,
                isbn: String,
                year: String,
                chapter_no: String,
                level: { type: String, enum: ["International", "National", "Regional", "Institutional"] },
                authors: [{ type: String }],
                co_authors: [{ type: String }]
            }],
        books_authored: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                publisher: String,
                isbn: String,
                year: String,
                level: { type: String, enum: ["International", "National", "Regional", "Institutional"] },
                authors: [{ type: String }],
                co_authors: [{ type: String }]
            }],
        edited_volume: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                publisher: String,
                isbn: String,
                year: String,
                level: { type: String, enum: ["International", "National", "Regional", "Institutional"] },
                authors: [{ type: String }],
                co_authors: [{ type: String }]
            }],
        patent: [{
                _id: { type: mongoose_1.Schema.Types.ObjectId },
                title: String,
                country: String,
                patent_no: String,
                application_no: String,
                date: String,
                inventors: [{ type: String }] // Already using array for inventors
            }]
    },
    intellectual_property: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            type: { type: String, enum: ["Patent", "Copyright", "Trademark"] },
            title: String,
            app_no: String,
            country: String,
            filed_year: Number,
            granted_year: Number,
            status: { type: String, enum: ["filed", "published", "granted"] }
        }],
    funded_projects: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            title: String,
            funding_agency: String,
            scheme: String,
            amount: Number,
            sanction_year: Number,
            status: { type: String, enum: ["ongoing", "completed"] },
            role: { type: String, enum: ["PI", "Co-PI"] }
        }],
    consultancy: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            industry_partner: String,
            description: String,
            revenue_generated: Number,
            year: Number
        }],
    collaborations: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            organization: String,
            country: String,
            type: { type: String, enum: ["MoU", "Joint Project", "Student Support"] },
            start_year: Number,
            end_year: Number
        }],
    memberships: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            body_name: String,
            membership_id: String,
            role: String,
            valid_till: Date
        }],
    editorial_roles: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            journal_name: String,
            role: { type: String, enum: ["Reviewer", "Editorial Board Member"] },
            indexing: String,
            since_year: Number
        }],
    awards: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            title: String,
            organization: String,
            year: Number
        }],
    events_participated: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            type: { type: String, enum: ["workshop", "seminar", "FDP", "webinar"] },
            title: String,
            duration: String,
            mode: { type: String, enum: ["online", "offline"] },
            organized_by: String,
            year: Number
        }],
    innovation_activities: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            type: { type: String, enum: ["Startup", "Prototype", "Technology Transfer", "Innovation"] },
            title: String,
            description: String,
            year: Number,
            funding_support: String
        }],
    research_profiles: {
        orcid: String,
        scopus_id: String,
        researcher_id: String,
        google_scholar: String,
        publons: String,
        linkedin: String
    },
    disciplinary_actions: [{
            _id: { type: mongoose_1.Schema.Types.ObjectId },
            action_type: String,
            description: String,
            date: Date,
            remarks: String
        }],
    username: String,
    password: String,
    role: {
        type: [String],
        enum: IStaff_1.RoleEnum,
        default: [],
    },
    profile_pic: String,
    otpVerify: String
}, {
    timestamps: true
});
// 🔹 Auto Sync Department Name & Code
StaffSchema.pre("save", async function (next) {
    if (this.isModified("department")) {
        const dept = await mongoose_1.default.model("Departments").findById(this.department);
        if (dept) {
            // @ts-ignore
            this.department_code = dept.department_code;
            // @ts-ignore
            this.department_name = dept.department_name;
        }
    }
    next();
});
exports.StaffModel = mongoose_1.default.models.StaffMaster || mongoose_1.default.model("StaffMaster", StaffSchema, 'staffmasters');
