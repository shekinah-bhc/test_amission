"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateCsvToTimeTable = exports.resetAllDepartmentTimetables = exports.resetDepartmentTimetable = exports.getAllStaffWithAssignments = exports.getStaffTimetable = exports.getStudentTimetable = exports.getSectionsByDepartmentProgramAndYear = exports.getYearsByDepartmentAndProgram = exports.getProgramsByDepartment = exports.getSectionTimetable = exports.getOneDepartments = exports.bulkUpdateTimetable = exports.clearTimetableHour = exports.updateTimetableHour = exports.getTimetableByFilters = void 0;
const Departments_1 = require("../../models/admin/Departments");
const Staff_1 = require("../../models/staff/Staff");
const csvtojson_1 = __importDefault(require("csvtojson"));
const generateDefaultTimeTable = () => {
    return Array.from({ length: 6 }, (_, dayIndex) => ({
        dayOrder: dayIndex + 1, // 1–6
        hours: Array.from({ length: 5 }, (_, hourIndex) => ({
            hour: hourIndex + 1, // 1–5
            staffid: "",
            staffName: "",
            paperCode: "",
            paperTitle: "",
            paperType: "",
        })),
    }));
};
const romanToNumber = (value) => {
    const map = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6 };
    const num = parseInt(value);
    if (!isNaN(num))
        return num;
    return map[value.toUpperCase()] ?? 0;
};
const getTimetableByFilters = async (req, res) => {
    try {
        const { departmentName, programId, year, sectionName } = req.query;
        if (!departmentName || !programId || !year || !sectionName) {
            return res.status(400).json({
                message: 'Missing required parameters: departmentName, programId, year, sectionName'
            });
        }
        const department = await Departments_1.DepartmentModel.findOne({
            department_name: departmentName
        });
        if (!department) {
            return res.status(404).json({ message: 'Department not found' });
        }
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program) {
            return res.status(404).json({ message: 'Program not found' });
        }
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData) {
            return res.status(404).json({ message: 'Year not found' });
        }
        const section = yearData.sections.find((s) => s.section_name.toLowerCase() === sectionName.toLowerCase());
        if (!section) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.status(200).json({
            message: 'Timetable retrieved successfully',
            data: {
                department: {
                    _id: department._id,
                    department_code: department.department_code,
                    department_name: department.department_name
                },
                program: {
                    program_id: program.program_id,
                    program_name: program.program_name
                },
                year: yearData.year,
                section: {
                    section_name: section.section_name,
                    section_shift: section.section_shift,
                    TimeTable: section.TimeTable
                }
            }
        });
    }
    catch (error) {
        console.error('Error getting timetable by filters:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getTimetableByFilters = getTimetableByFilters;
const updateTimetableHour = async (req, res) => {
    try {
        const { departmentName, programId, year, sectionName, dayOrder, hour } = req.params;
        // Extract data from request body
        const bodyData = req.body || {};
        const updateData = {};
        // Map payload fields to database fields
        if (bodyData.staffid) {
            updateData.staff_id = bodyData.staffid;
        }
        if (bodyData.staffName) {
            updateData.staffName = bodyData.staffName;
        }
        if (bodyData.paperCode) {
            updateData.course_code = bodyData.paperCode;
        }
        if (bodyData.paperTitle) {
            updateData.course_title = bodyData.paperTitle;
        }
        if (bodyData.paperType) {
            updateData.course_type = bodyData.paperType;
        }
        // Set isScheduled based on whether any data is being added
        if (Object.keys(updateData).length > 0) {
            updateData.isScheduled = true;
        }
        if (!departmentName || !programId || !year || !sectionName || !dayOrder || !hour) {
            return res.status(400).json({
                message: 'Missing required params: departmentName, programId, year, sectionName, dayOrder, hour'
            });
        }
        // Validate allowed update fields
        const allowedFields = ['staff_id', 'staffName', 'course_code', 'course_title', 'course_type', 'language_type', 'room', 'isScheduled'];
        const invalidFields = Object.keys(updateData).filter(f => !allowedFields.includes(f));
        if (invalidFields.length > 0) {
            return res.status(400).json({ message: `Invalid fields: ${invalidFields.join(', ')}` });
        }
        // Find and update the department
        const department = await Departments_1.DepartmentModel.findOne({ department_name: departmentName });
        if (!department)
            return res.status(404).json({ message: 'Department not found' });
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: 'Program not found' });
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: 'Year not found' });
        const section = yearData.sections.find((s) => s.section_name.toLowerCase() === sectionName.toLowerCase());
        if (!section)
            return res.status(404).json({ message: 'Section not found' });
        const day = section.TimeTable.find((d) => d.dayOrder === parseInt(dayOrder));
        if (!day)
            return res.status(404).json({ message: 'Day not found' });
        const hourSlot = day.hours.find((h) => h.hour === parseInt(hour));
        if (!hourSlot)
            return res.status(404).json({ message: 'Hour slot not found' });
        // Get the old values before updating
        const oldStaffId = hourSlot.staffid;
        const oldCourseCode = hourSlot.paperCode;
        // Prepare subject data for StaffModel
        const subjectDataForStaff = {
            course_code: bodyData.paperCode || oldCourseCode || '',
            course_title: bodyData.paperTitle || '',
            course_type: bodyData.paperType || '',
            department_name: departmentName,
            program_id: programId,
            year: year.toString(), // Convert to string as per schema
            section_name: sectionName,
            dayOrder: dayOrder,
            hour: hour
        };
        // Update hour slot with new data
        Object.assign(hourSlot, updateData);
        // Save department changes first
        await department.save();
        // Now handle StaffModel updates
        const newStaffId = bodyData.staffid;
        // Case 1: Remove from old staff if staff is changing or being cleared
        if (oldStaffId && oldCourseCode && (oldStaffId !== newStaffId || !newStaffId)) {
            await Staff_1.StaffModel.findOneAndUpdate({ staff_id: oldStaffId }, {
                $pull: {
                    class_attend: {
                        course_code: oldCourseCode,
                        department_name: departmentName,
                        program_id: programId,
                        year: year.toString(),
                        section_name: sectionName
                    }
                }
            });
        }
        // Case 2: Add to new staff if staff is assigned
        if (newStaffId && subjectDataForStaff.course_code && subjectDataForStaff.course_title) {
            const staff = await Staff_1.StaffModel.findOne({ staff_id: newStaffId });
            if (staff) {
                // Check if this exact subject already exists for this staff
                const subjectExists = staff.class_attend.some((subject) => subject.course_code === subjectDataForStaff.course_code &&
                    subject.department_name === subjectDataForStaff.department_name &&
                    subject.program_id === subjectDataForStaff.program_id &&
                    subject.year === subjectDataForStaff.year &&
                    subject.section_name === subjectDataForStaff.section_name);
                if (!subjectExists) {
                    // Add new subject
                    const newSubject = {
                        ...subjectDataForStaff,
                        added_date: new Date()
                    };
                    await Staff_1.StaffModel.findOneAndUpdate({ staff_id: newStaffId }, {
                        $addToSet: { class_attend: newSubject }
                    }, { new: true });
                }
                else {
                    // Update existing subject with new details
                    await Staff_1.StaffModel.findOneAndUpdate({
                        staff_id: newStaffId,
                        "class_attend.course_code": subjectDataForStaff.course_code,
                        "class_attend.department_name": subjectDataForStaff.department_name,
                        "class_attend.program_id": subjectDataForStaff.program_id,
                        "class_attend.year": subjectDataForStaff.year,
                        "class_attend.section_name": subjectDataForStaff.section_name
                    }, {
                        $set: {
                            "class_attend.$.course_title": subjectDataForStaff.course_title,
                            "class_attend.$.course_type": subjectDataForStaff.course_type,
                            "class_attend.$.updated_date": new Date()
                        }
                    });
                }
            }
        }
        res.status(200).json({
            message: 'Timetable updated successfully',
            data: {
                department: department.department_name,
                program: program.program_id,
                year: yearData.year,
                section: section.section_name,
                dayOrder: parseInt(dayOrder),
                hour: parseInt(hour),
                updatedData: hourSlot,
                subjectUpdated: !!newStaffId
            }
        });
    }
    catch (err) {
        console.error('Error updating timetable hour:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.updateTimetableHour = updateTimetableHour;
const clearTimetableHour = async (req, res) => {
    try {
        const { departmentName, programId, year, sectionName, dayOrder, hour } = req.params;
        if (!departmentName || !programId || !year || !sectionName || !dayOrder || !hour) {
            return res.status(400).json({
                message: 'Missing required parameters: departmentName, programId, year, sectionName, dayOrder, hour'
            });
        }
        // Clear data according to new schema
        const clearData = {
            staff_id: '',
            staffName: '',
            course_code: '',
            course_title: '',
            course_type: '',
            language_type: '',
            room: '',
            isScheduled: false
        };
        const department = await Departments_1.DepartmentModel.findOne({ department_name: departmentName });
        if (!department)
            return res.status(404).json({ message: 'Department not found' });
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: 'Program not found' });
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: 'Year not found' });
        const section = yearData.sections.find((s) => s.section_name.toLowerCase() === sectionName.toLowerCase());
        if (!section)
            return res.status(404).json({ message: 'Section not found' });
        const day = section.TimeTable.find((d) => d.dayOrder === parseInt(dayOrder));
        if (!day)
            return res.status(404).json({ message: 'Day not found' });
        const hourSlot = day.hours.find((h) => h.hour === parseInt(hour));
        if (!hourSlot)
            return res.status(404).json({ message: 'Hour slot not found' });
        Object.assign(hourSlot, clearData);
        await department.save();
        res.status(200).json({
            message: 'Timetable hour cleared successfully',
            data: {
                department: department.department_name,
                program: program.program_id,
                year: yearData.year,
                section: section.section_name,
                dayOrder: parseInt(dayOrder),
                hour: parseInt(hour),
                clearedData: hourSlot
            }
        });
    }
    catch (error) {
        console.error('Error clearing timetable hour:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.clearTimetableHour = clearTimetableHour;
const bulkUpdateTimetable = async (req, res) => {
    try {
        const { departmentName, programId, year, sectionName, updates } = req.body;
        if (!departmentName || !programId || !year || !sectionName || !updates || !Array.isArray(updates)) {
            return res.status(400).json({
                message: 'Missing required parameters: departmentName, programId, year, sectionName, updates array'
            });
        }
        const department = await Departments_1.DepartmentModel.findOne({ department_name: departmentName });
        if (!department)
            return res.status(404).json({ message: 'Department not found' });
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program)
            return res.status(404).json({ message: 'Program not found' });
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData)
            return res.status(404).json({ message: 'Year not found' });
        const section = yearData.sections.find((s) => s.section_name.toLowerCase() === sectionName.toLowerCase());
        if (!section)
            return res.status(404).json({ message: 'Section not found' });
        let updatedCount = 0;
        for (const update of updates) {
            const { dayOrder, hour, updateData } = update;
            const day = section.TimeTable.find((d) => d.dayOrder === parseInt(dayOrder));
            if (day) {
                const hourSlot = day.hours.find((h) => h.hour === parseInt(hour));
                if (hourSlot) {
                    // Set isScheduled based on whether any data is being added
                    if (Object.keys(updateData).length > 0) {
                        updateData.isScheduled = true;
                    }
                    Object.assign(hourSlot, updateData);
                    updatedCount++;
                }
            }
        }
        await department.save();
        res.status(200).json({
            message: `Timetable bulk updated successfully. ${updatedCount} hours updated.`,
            data: {
                department: department.department_name,
                program: program.program_id,
                year: yearData.year,
                section: section.section_name,
                updatedCount
            }
        });
    }
    catch (error) {
        console.error('Error in bulk update timetable:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.bulkUpdateTimetable = bulkUpdateTimetable;
const getOneDepartments = async (req, res) => {
    try {
        const dept_name = req.params.departmentName;
        let departments;
        if (dept_name) {
            departments = await Departments_1.DepartmentModel.find({ department_name: dept_name }, 'department_code department_name');
        }
        else {
            departments = await Departments_1.DepartmentModel.find({}, 'department_code department_name');
        }
        res.status(200).json({
            message: 'Departments retrieved successfully',
            data: departments
        });
    }
    catch (error) {
        console.error('Error getting departments:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getOneDepartments = getOneDepartments;
const getSectionTimetable = async (req, res) => {
    try {
        const program_code = req.params.programCode;
        const section_name = req.params.sectionName;
        const currentYear = req.params.currentYear;
        if (!program_code || !section_name || !currentYear) {
            return res.status(400).json({
                message: 'Program name, section name, and current year are required'
            });
        }
        const result = await Departments_1.DepartmentModel.aggregate([
            { $unwind: "$programs" },
            { $match: { "programs.program_id": decodeURIComponent(program_code) } },
            { $unwind: "$programs.years" },
            { $match: { "programs.years.year": parseInt(currentYear, 10) } },
            { $unwind: "$programs.years.sections" },
            { $match: { "programs.years.sections.section_name": section_name } },
            {
                $project: {
                    department_code: 1,
                    department_name: 1,
                    program_id: "$programs.program_id",
                    program_code: "$programs.program_name",
                    year: "$programs.years.year",
                    section_name: "$programs.years.sections.section_name",
                    section_shift: "$programs.years.sections.section_shift",
                    timetable: "$programs.years.sections.TimeTable"
                }
            }
        ]);
        if (result.length === 0) {
            return res.status(404).json({
                message: `Section timetable not found for program: ${program_code} and section: ${section_name}`
            });
        }
        res.status(200).json({
            message: 'Section timetable retrieved successfully',
            data: result[0]
        });
    }
    catch (error) {
        console.error('Error getting section timetable:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getSectionTimetable = getSectionTimetable;
const getProgramsByDepartment = async (req, res) => {
    try {
        const { departmentName } = req.query;
        if (!departmentName) {
            return res.status(400).json({ message: 'Department name is required' });
        }
        const department = await Departments_1.DepartmentModel.findOne({
            department_name: departmentName
        }, 'programs.program_id programs.program_name');
        if (!department) {
            return res.status(404).json({ message: 'Department not found' });
        }
        const programs = department.programs.map((program) => ({
            program_id: program.program_id,
            program_name: program.program_name
        }));
        res.status(200).json({
            message: 'Programs retrieved successfully',
            data: programs
        });
    }
    catch (error) {
        console.error('Error getting programs:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getProgramsByDepartment = getProgramsByDepartment;
const getYearsByDepartmentAndProgram = async (req, res) => {
    try {
        const { departmentName, programId } = req.query;
        if (!departmentName || !programId) {
            return res.status(400).json({
                message: 'Department name and program ID are required'
            });
        }
        const department = await Departments_1.DepartmentModel.findOne({
            department_name: departmentName
        });
        if (!department) {
            return res.status(404).json({ message: 'Department not found' });
        }
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program) {
            return res.status(404).json({ message: 'Program not found' });
        }
        const years = program.years.map((year) => year.year);
        res.status(200).json({
            message: 'Years retrieved successfully',
            data: years
        });
    }
    catch (error) {
        console.error('Error getting years:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getYearsByDepartmentAndProgram = getYearsByDepartmentAndProgram;
const getSectionsByDepartmentProgramAndYear = async (req, res) => {
    try {
        const { departmentName, programId, year } = req.query;
        if (!departmentName || !programId || !year) {
            return res.status(400).json({
                message: 'Department name, program ID, and year are required'
            });
        }
        const department = await Departments_1.DepartmentModel.findOne({
            department_name: departmentName
        });
        if (!department) {
            return res.status(404).json({ message: 'Department not found' });
        }
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program) {
            return res.status(404).json({ message: 'Program not found' });
        }
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData) {
            return res.status(404).json({ message: 'Year not found' });
        }
        const sections = yearData.sections.map((section) => ({
            section_name: section.section_name,
            section_shift: section.section_shift
        }));
        res.status(200).json({
            message: 'Sections retrieved successfully',
            data: sections
        });
    }
    catch (error) {
        console.error('Error getting sections:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getSectionsByDepartmentProgramAndYear = getSectionsByDepartmentProgramAndYear;
// NEW: Get student timetable by section
const getStudentTimetable = async (req, res) => {
    try {
        const { departmentCode, programId, year, sectionName } = req.query;
        if (!departmentCode || !programId || !year || !sectionName) {
            return res.status(400).json({
                message: 'Missing required parameters: departmentCode, programId, year, sectionName'
            });
        }
        const department = await Departments_1.DepartmentModel.findOne({
            department_code: departmentCode
        });
        if (!department) {
            return res.status(404).json({ message: 'Department not found' });
        }
        const program = department.programs.find((p) => p.program_id === programId);
        if (!program) {
            return res.status(404).json({ message: 'Program not found' });
        }
        const yearData = program.years.find((y) => y.year === parseInt(year));
        if (!yearData) {
            return res.status(404).json({ message: 'Year not found' });
        }
        const section = yearData.sections.find((s) => s.section_name.toLowerCase() === sectionName.toLowerCase());
        if (!section) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.status(200).json({
            message: 'Student timetable retrieved successfully',
            data: {
                department: {
                    department_code: department.department_code,
                    department_name: department.department_name
                },
                program: {
                    program_id: program.program_id,
                    program_name: program.program_name
                },
                year: yearData.year,
                section: {
                    section_name: section.section_name,
                    section_shift: section.section_shift,
                    TimeTable: section.TimeTable
                }
            }
        });
    }
    catch (error) {
        console.error('Error getting student timetable:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getStudentTimetable = getStudentTimetable;
// NEW: Get staff timetable by staff ID across all departments
const getStaffTimetable = async (req, res) => {
    try {
        const { staffId } = req.params;
        if (!staffId) {
            return res.status(400).json({ message: 'Staff ID is required' });
        }
        const departments = await Departments_1.DepartmentModel.find();
        const staffTimetable = [];
        departments.forEach(department => {
            department.programs.forEach(program => {
                program.years.forEach(year => {
                    year.sections.forEach(section => {
                        section.TimeTable.forEach(day => {
                            day.hours.forEach(hour => {
                                if (hour.staffid === staffId) {
                                    staffTimetable.push({
                                        department: {
                                            department_code: department.department_code,
                                            department_name: department.department_name
                                        },
                                        program: {
                                            program_id: program.program_id,
                                            program_name: program.program_name
                                        },
                                        year: year.year,
                                        section: {
                                            section_name: section.section_name,
                                            section_shift: section.section_shift
                                        },
                                        day: {
                                            dayOrder: day.dayOrder,
                                            hour: hour.hour
                                        },
                                        course: {
                                            course_code: hour.paperCode,
                                            course_title: hour.paperTitle,
                                            course_type: hour.paperType,
                                        }
                                    });
                                }
                            });
                        });
                    });
                });
            });
        });
        if (staffTimetable.length === 0) {
            return res.status(404).json({
                message: 'No timetable entries found for this staff member',
                data: []
            });
        }
        res.status(200).json({
            message: 'Staff timetable retrieved successfully',
            data: staffTimetable
        });
    }
    catch (error) {
        console.error('Error getting staff timetable:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getStaffTimetable = getStaffTimetable;
// NEW: Get all staff members with their assigned courses
const getAllStaffWithAssignments = async (req, res) => {
    try {
        const departments = await Departments_1.DepartmentModel.find();
        const staffMap = new Map();
        departments.forEach(department => {
            department.programs.forEach(program => {
                program.years.forEach(year => {
                    year.sections.forEach(section => {
                        section.TimeTable.forEach(day => {
                            day.hours.forEach(hour => {
                                if (hour.staffid === null) {
                                    const staffKey = `${hour.staffid}-${hour.staffName}`;
                                    if (!staffMap.has(staffKey)) {
                                        staffMap.set(staffKey, {
                                            staff_id: hour.staffid,
                                            staffName: hour.staffName,
                                            assignments: []
                                        });
                                    }
                                    const staff = staffMap.get(staffKey);
                                    staff.assignments.push({
                                        department: department.department_name,
                                        program: program.program_name,
                                        year: year.year,
                                        section: section.section_name,
                                        dayOrder: day.dayOrder,
                                        hour: hour.hour,
                                        course_code: hour.paperCode,
                                        course_title: hour.paperTitle,
                                        course_type: hour.paperType,
                                    });
                                }
                            });
                        });
                    });
                });
            });
        });
        const staffList = Array.from(staffMap.values());
        res.status(200).json({
            message: 'Staff assignments retrieved successfully',
            data: staffList
        });
    }
    catch (error) {
        console.error('Error getting staff assignments:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getAllStaffWithAssignments = getAllStaffWithAssignments;
const resetDepartmentTimetable = async (req, res) => {
    try {
        const { department_code } = req.params;
        const dept = await Departments_1.DepartmentModel.findOne({ department_code });
        if (!dept) {
            return res.status(404).json({ message: "Department not found" });
        }
        const defaultTT = generateDefaultTimeTable();
        // Reset timetable for all sections inside department
        dept.programs.forEach(program => {
            program.years.forEach(year => {
                year.sections.forEach(section => {
                    section.TimeTable = defaultTT;
                });
            });
        });
        await dept.save();
        return res.status(200).json({
            message: `Timetable reset successfully for department: ${department_code}`,
            department: department_code
        });
    }
    catch (error) {
        console.error("Error resetting timetable:", error);
        return res.status(500).json({
            message: "Failed to reset department timetable",
            error: String(error)
        });
    }
};
exports.resetDepartmentTimetable = resetDepartmentTimetable;
const resetAllDepartmentTimetables = async (req, res) => {
    try {
        const departments = await Departments_1.DepartmentModel.find();
        const defaultTT = generateDefaultTimeTable();
        for (const dept of departments) {
            dept.programs.forEach(program => {
                program.years.forEach(year => {
                    year.sections.forEach(section => {
                        section.TimeTable = defaultTT;
                    });
                });
            });
            await dept.save();
        }
        return res.status(200).json({
            message: "All department timetables reset successfully"
        });
    }
    catch (error) {
        console.error("Error resetting timetable for all departments:", error);
        return res.status(500).json({
            message: "Failed to reset all timetables",
            error: String(error)
        });
    }
};
exports.resetAllDepartmentTimetables = resetAllDepartmentTimetables;
const migrateCsvToTimeTable = async (req, res) => {
    try {
        if (!req.file?.path) {
            return res.status(400).json({ message: "CSV file is required" });
        }
        const rows = await (0, csvtojson_1.default)().fromFile(req.file.path);
        const missingStaff = [];
        const updatedRows = [];
        for (const row of rows) {
            const { staff_id_new, department, course, cyear, section, shift, papertype, papertitle, papercode, day, hour } = row;
            // Validate staff
            const staff = await Staff_1.StaffModel.findOne({
                $or: [
                    { staff_id: staff_id_new },
                    { alt_staffid: staff_id_new }
                ]
            });
            if (!staff) {
                console.log("❌ Staff not found:", staff_id_new);
                missingStaff.push(staff_id_new);
                continue;
            }
            // Prepare values
            const yearNumber = Number(cyear);
            const dayOrder = romanToNumber(day);
            const hourNumber = romanToNumber(hour);
            // Find department
            let dept = await Departments_1.DepartmentModel.findOne({ department_name: department });
            if (!dept) {
                dept = new Departments_1.DepartmentModel({
                    department_code: department.slice(0, 3).toUpperCase(),
                    department_name: department,
                    programs: []
                });
            }
            // Find or add program
            let program = dept.programs.find(p => p.program_name === course);
            if (!program) {
                program = {
                    program_id: `${course}-${Date.now()}`,
                    program_name: course,
                    years: []
                };
                dept.programs.push(program);
            }
            // Find or add year
            let yearObj = program.years.find(y => y.year === yearNumber);
            if (!yearObj) {
                yearObj = { year: yearNumber, sections: [] };
                program.years.push(yearObj);
            }
            // Find or add section
            let sectionObj = yearObj.sections.find(s => s.section_name === section &&
                s.section_shift === shift);
            if (!sectionObj) {
                sectionObj = {
                    section_name: section,
                    section_shift: shift,
                    TimeTable: []
                };
                yearObj.sections.push(sectionObj);
            }
            // Find or add dayOrder
            let dayObj = sectionObj.TimeTable.find(d => d.dayOrder === dayOrder);
            if (!dayObj) {
                dayObj = {
                    dayOrder,
                    hours: []
                };
                sectionObj.TimeTable.push(dayObj);
            }
            // Replace or add hour
            const hourIndex = dayObj.hours.findIndex(h => h.hour === hourNumber);
            const hourPayload = {
                hour: hourNumber,
                staffid: staff.staff_id,
                staffName: staff.name,
                paperCode: papercode,
                paperTitle: papertitle,
                paperType: papertype,
            };
            // Replace or add hour
            if (hourIndex >= 0) {
                dayObj.hours[hourIndex] = hourPayload; // FIX
            }
            else {
                dayObj.hours.push(hourPayload); // FIX
            }
            await dept.save();
            updatedRows.push(row);
        }
        return res.status(200).json({
            message: "CSV Migration Completed",
            updatedRecords: updatedRows.length,
            missingStaff: [...new Set(missingStaff)]
        });
    }
    catch (error) {
        console.error("Migration Error:", error);
        return res.status(500).json({
            message: "Migration failed",
            error: error instanceof Error ? error.message : String(error)
        });
    }
};
exports.migrateCsvToTimeTable = migrateCsvToTimeTable;
