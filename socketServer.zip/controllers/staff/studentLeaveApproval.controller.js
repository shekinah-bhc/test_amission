"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateLeaveStatus = exports.getStaffDashboard = exports.getClubCoordinatorLeaveApplications = exports.getHODLeaveApplications = exports.getStaffLeaveApplications = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const StudentAttendance_model_1 = require("../../models/students/StudentAttendance.model");
const Staff_1 = require("../../models/staff/Staff");
const util_1 = require("../../services/util");
/**
 * Utility: Get student leaves based on various criteria
 */
const getStudentLeaves = async (filters, options = {}) => {
    const { page = 1, limit = 20, status = 'pending', currentSemesterInfo } = options;
    const skip = (page - 1) * limit;
    const pipeline = [
        // Match students based on filters
        {
            $match: filters
        },
        // Unwind attendance records
        {
            $unwind: "$attendanceRecords"
        },
        // Match current academic year
        {
            $match: {
                "attendanceRecords.academicYear": currentSemesterInfo.academicYear
            }
        },
        // Determine which semester to check
        {
            $addFields: {
                targetSemester: {
                    $cond: {
                        if: { $eq: [currentSemesterInfo.semester, 'ODD'] },
                        then: "$attendanceRecords.sem_odd",
                        else: "$attendanceRecords.sem_even"
                    }
                }
            }
        },
        // Unwind leaves
        {
            $unwind: "$targetSemester.leaves"
        },
        // Filter by leave status if not 'all'
        ...(status !== 'all' ? [{
                $match: {
                    "targetSemester.leaves.status": status
                }
            }] : []),
        // Lookup staff details for approvals
        {
            $lookup: {
                from: "staffmasters",
                localField: "targetSemester.leaves.approvals.approvedBy",
                foreignField: "staff_id",
                as: "approverDetails"
            }
        },
        // Add sorting
        {
            $sort: {
                "targetSemester.leaves.appliedAt": -1
            }
        },
        // Skip and limit for pagination
        {
            $skip: skip
        },
        {
            $limit: limit
        },
        // Project required fields
        {
            $project: {
                roll_no: 1,
                name: 1,
                gender: 1,
                department_name: 1,
                program_name: 1,
                section: 1,
                batch: 1,
                shift: 1,
                stream: 1,
                leaveDetails: "$targetSemester.leaves",
                semester: currentSemesterInfo.semester,
                academicYear: currentSemesterInfo.academicYear,
                approverDetails: {
                    $map: {
                        input: "$approverDetails",
                        as: "approver",
                        in: {
                            staff_id: "$$approver.staff_id",
                            name: "$$approver.name",
                            designation: "$$approver.designation",
                            department_name: "$$approver.department_name"
                        }
                    }
                }
            }
        }
    ];
    // Get total count
    const countPipeline = [
        ...pipeline.slice(0, -5), // Exclude skip, limit, and project
        { $count: "total" }
    ];
    const [studentsWithLeaves, totalCount] = await Promise.all([
        StudentAttendance_model_1.StudentAttendance.aggregate(pipeline),
        StudentAttendance_model_1.StudentAttendance.aggregate(countPipeline)
    ]);
    const total = totalCount[0]?.total || 0;
    // Format the response
    const formattedLeaves = studentsWithLeaves.map(leave => {
        const leaveDetails = leave.leaveDetails;
        return {
            studentInfo: {
                roll_no: leave.roll_no,
                name: leave.name,
                gender: leave.gender,
                department: leave.department_name,
                program: leave.program_name,
                batch: leave.batch,
                section: leave.section,
                shift: leave.shift,
                stream: leave.stream
            },
            leaveInfo: {
                leaveId: leaveDetails._id,
                leaveType: leaveDetails.leaveType,
                status: leaveDetails.status,
                startDate: leaveDetails.startDate,
                endDate: leaveDetails.endDate,
                duration: Math.ceil((new Date(leaveDetails.endDate).getTime() -
                    new Date(leaveDetails.startDate).getTime()) /
                    (1000 * 60 * 60 * 24)) + 1,
                reason: leaveDetails.reason,
                remarks: leaveDetails.remarks,
                appliedAt: leaveDetails.appliedAt,
                supportingDocuments: leaveDetails.supportingDocument || []
            },
            approvals: (leaveDetails.approvals || []).map((approval) => {
                const approverDetail = leave.approverDetails.find((ad) => ad.staff_id === approval.approvedBy);
                return {
                    approverRole: approval.approver,
                    status: approval.status,
                    approvedBy: approval.approvedBy,
                    approverName: approverDetail?.name || 'Unknown',
                    approverDesignation: approverDetail?.designation || 'Unknown',
                    approverDepartment: approverDetail?.department_name || 'Unknown',
                    documentVerified: approval.documentVerified || false,
                    remarks: approval.remarks,
                    updatedAt: approval.updatedAt
                };
            }),
            currentStage: determineCurrentStage(leaveDetails.approvals)
        };
    });
    return {
        leaves: formattedLeaves,
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
    };
};
/**
 * Determine current approval stage
 */
const determineCurrentStage = (approvals) => {
    if (!approvals || approvals.length === 0) {
        return 'SUBMITTED';
    }
    // Find the last pending approval
    const pendingApproval = approvals.find(a => a.status === 'pending');
    if (pendingApproval) {
        return pendingApproval.approver;
    }
    // If all approved, return last approval stage
    const lastApproval = approvals[approvals.length - 1];
    return lastApproval.approver;
};
/**
 * 1. STAFF: Get leave applications (Class Incharge/Mentor)
 */
const getStaffLeaveApplications = async (req, res) => {
    try {
        const { staffId } = req.params;
        const { status = 'pending', page = '1', limit = '20' } = req.query;
        // 1. Find staff and get their role and in-charge classes
        const staff = await Staff_1.StaffModel.findOne({ staff_id: staffId });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'Staff not found'
            });
        }
        // 2. Get current semester
        const currentDate = new Date();
        const currentSemesterInfo = await (0, util_1.getCurrentSemester)(currentDate);
        if (!currentSemesterInfo) {
            return res.status(400).json({
                success: false,
                message: 'No active semester found'
            });
        }
        // 3. Determine filters based on staff role
        let filters = {};
        // If staff is class incharge
        const inchargeClasses = staff.class_attend?.filter(cls => cls.incharge === true) || [];
        if (inchargeClasses.length > 0) {
            const classConditions = inchargeClasses.map(cls => ({
                department_name: cls.department_name,
                program_id: cls.program_id,
                batch: cls.year,
                section: cls.section_name
            }));
            filters = { $or: classConditions };
        }
        else {
            // If not class incharge, show only leaves where they are approver
            filters = {
                'attendanceRecords.sem_odd.leaves.approvals.approvedBy': staffId,
                'attendanceRecords.sem_even.leaves.approvals.approvedBy': staffId
            };
        }
        // 4. Get leaves
        const result = await getStudentLeaves(filters, {
            page: parseInt(page),
            limit: parseInt(limit),
            status: status,
            currentSemesterInfo
        });
        // 5. Filter based on approval workflow
        let filteredLeaves = result.leaves;
        // If staff has 'staff' role, show only submitted leaves
        if (staff.role?.includes('staff') && !staff.role?.includes('hod')) {
            filteredLeaves = result.leaves.filter(leave => leave.currentStage === 'CLASS_INCHARGE' ||
                leave.leaveInfo.status === 'submitted');
        }
        // If staff has 'mentor' role, show leaves where class incharge is approved
        if (staff.role?.includes('mentor')) {
            filteredLeaves = result.leaves.filter(leave => {
                const classInchargeApproval = leave.approvals.find((a) => a.approverRole === 'CLASS_INCHARGE');
                return classInchargeApproval?.status === 'approved' &&
                    leave.currentStage === 'MENTOR';
            });
        }
        return res.status(200).json({
            success: true,
            message: 'Leave applications fetched successfully',
            data: {
                staffInfo: {
                    staff_id: staff.staff_id,
                    name: staff.name,
                    designation: staff.designation,
                    department: staff.department_name,
                    roles: staff.role,
                    inchargeClasses: inchargeClasses.map(cls => ({
                        department: cls.department_name,
                        program: cls.program_id,
                        year: cls.year,
                        section: cls.section_name,
                        dayOrder: cls.dayOrder,
                        hour: cls.hour
                    }))
                },
                currentSemester: currentSemesterInfo,
                leaveApplications: filteredLeaves
            },
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: filteredLeaves.length,
                pages: Math.ceil(filteredLeaves.length / parseInt(limit))
            }
        });
    }
    catch (error) {
        console.error('Error in getStaffLeaveApplications:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};
exports.getStaffLeaveApplications = getStaffLeaveApplications;
/**
 * 2. HOD: Get leave applications by department and shift
 */
const getHODLeaveApplications = async (req, res) => {
    try {
        const { staffId } = req.params;
        const { department, shift, status = 'pending', page = '1', limit = '20' } = req.query;
        // 1. Verify staff is HOD
        const staff = await Staff_1.StaffModel.findOne({
            staff_id: staffId,
            role: { $in: ['hod'] }
        });
        if (!staff) {
            return res.status(403).json({
                success: false,
                message: 'Access denied: Staff is not HOD'
            });
        }
        // 2. Get current semester
        const currentDate = new Date();
        const currentSemesterInfo = await (0, util_1.getCurrentSemester)(currentDate);
        if (!currentSemesterInfo) {
            return res.status(400).json({
                success: false,
                message: 'No active semester found'
            });
        }
        // 3. Build filters
        const filters = {
            department_name: department,
            shift: shift
        };
        // 4. Get leaves
        const result = await getStudentLeaves(filters, {
            page: parseInt(page),
            limit: parseInt(limit),
            status: status,
            currentSemesterInfo
        });
        // 5. Filter for HOD: Show leaves where mentor is approved
        let filteredLeaves = result.leaves.filter(leave => {
            const mentorApproval = leave.approvals.find((a) => a.approverRole === 'MENTOR');
            return mentorApproval?.status === 'approved' &&
                leave.currentStage === 'HOD';
        });
        // If HOD also has staff role, include submitted leaves
        if (staff.role?.includes('staff')) {
            const submittedLeaves = result.leaves.filter(leave => leave.currentStage === 'CLASS_INCHARGE' ||
                leave.leaveInfo.status === 'submitted');
            filteredLeaves = [...filteredLeaves, ...submittedLeaves];
        }
        return res.status(200).json({
            success: true,
            message: 'HOD leave applications fetched successfully',
            data: {
                hodInfo: {
                    staff_id: staff.staff_id,
                    name: staff.name,
                    designation: staff.designation,
                    department: staff.department_name,
                    roles: staff.role
                },
                department: department,
                shift: shift,
                currentSemester: currentSemesterInfo,
                leaveApplications: filteredLeaves
            },
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: filteredLeaves.length,
                pages: Math.ceil(filteredLeaves.length / parseInt(limit))
            }
        });
    }
    catch (error) {
        console.error('Error in getHODLeaveApplications:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};
exports.getHODLeaveApplications = getHODLeaveApplications;
/**
 * 3. CLUB COORDINATOR: Get leave applications by club
 */
const getClubCoordinatorLeaveApplications = async (req, res) => {
    try {
        const { staffId } = req.params;
        const { clubName, status = 'pending', page = '1', limit = '20' } = req.query;
        // 1. Verify staff is club coordinator (you might have this in staff model)
        const staff = await Staff_1.StaffModel.findOne({
            staff_id: staffId,
            // Assuming you have club coordinator role or club assignments
            $or: [
                { role: { $in: ['club-coordinator'] } },
                { designation: { $regex: 'club', $options: 'i' } }
            ]
        });
        if (!staff) {
            return res.status(403).json({
                success: false,
                message: 'Access denied: Staff is not a club coordinator'
            });
        }
        // 2. Get current semester
        const currentDate = new Date();
        const currentSemesterInfo = await (0, util_1.getCurrentSemester)(currentDate);
        if (!currentSemesterInfo) {
            return res.status(400).json({
                success: false,
                message: 'No active semester found'
            });
        }
        // 3. Build filters - students registered in the club
        const filters = {
            'registredClubs.club_name': clubName
        };
        // 4. Get leaves
        const result = await getStudentLeaves(filters, {
            page: parseInt(page),
            limit: parseInt(limit),
            status: status,
            currentSemesterInfo
        });
        // 5. Filter club coordinator leaves: Show all leaves for club members
        // (Adjust based on your approval workflow)
        let filteredLeaves = result.leaves;
        return res.status(200).json({
            success: true,
            message: 'Club coordinator leave applications fetched successfully',
            data: {
                coordinatorInfo: {
                    staff_id: staff.staff_id,
                    name: staff.name,
                    designation: staff.designation,
                    department: staff.department_name,
                    roles: staff.role
                },
                clubName: clubName,
                currentSemester: currentSemesterInfo,
                leaveApplications: filteredLeaves
            },
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: filteredLeaves.length,
                pages: Math.ceil(filteredLeaves.length / parseInt(limit))
            }
        });
    }
    catch (error) {
        console.error('Error in getClubCoordinatorLeaveApplications:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};
exports.getClubCoordinatorLeaveApplications = getClubCoordinatorLeaveApplications;
/**
 * 4. STAFF Dashboard
 */
const getStaffDashboard = async (req, res) => {
    try {
        const { staffId } = req.params;
        const staff = await Staff_1.StaffModel.findOne({ staff_id: staffId });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'Staff not found'
            });
        }
        const currentDate = new Date();
        const currentSemesterInfo = await (0, util_1.getCurrentSemester)(currentDate);
        // Get dashboard data based on role
        let dashboardData = {};
        if (staff.role?.includes('hod')) {
            dashboardData = await getHODDashboardData(staff);
        }
        else if (staff.role?.some(r => r.includes('club'))) {
            dashboardData = await getClubCoordinatorDashboardData(staff);
        }
        else {
            dashboardData = await getRegularStaffDashboardData(staff, currentSemesterInfo);
        }
        return res.status(200).json({
            success: true,
            data: {
                staffInfo: {
                    staff_id: staff.staff_id,
                    name: staff.name,
                    designation: staff.designation,
                    department: staff.department_name,
                    roles: staff.role
                },
                ...dashboardData
            }
        });
    }
    catch (error) {
        console.error('Error in getStaffDashboard:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};
exports.getStaffDashboard = getStaffDashboard;
/**
 * 5. Common: Update leave status
 */
const updateLeaveStatus = async (req, res) => {
    try {
        const { leaveId, staffId, action, remarks, approverRole } = req.body;
        // Verify staff exists
        const staff = await Staff_1.StaffModel.findOne({ staff_id: staffId });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: 'Staff not found'
            });
        }
        // Verify staff has required role
        if (!staff.role || !staff.role.some(r => (approverRole === 'HOD' && r === 'hod') ||
            (approverRole === 'MENTOR' && r === 'mentor') ||
            (approverRole === 'CLASS_INCHARGE' && (r === 'teaching staff' || r === 'faculty')))) {
            return res.status(403).json({
                success: false,
                message: 'Unauthorized: Invalid approver role'
            });
        }
        // Update leave status
        const result = await updateLeaveApproval(leaveId, staffId, approverRole, action, remarks);
        return res.status(200).json({
            success: true,
            message: `Leave ${action === 'approve' ? 'approved' : 'rejected'} successfully`,
            data: result
        });
    }
    catch (error) {
        console.error('Error in updateLeaveStatus:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};
exports.updateLeaveStatus = updateLeaveStatus;
// Helper functions
const getHODDashboardData = async (staff) => {
    // Get department statistics
    const department = staff.department_name;
    const [totalStudents, pendingLeaves] = await Promise.all([
        StudentAttendance_model_1.StudentAttendance.countDocuments({ department_name: department }),
        StudentAttendance_model_1.StudentAttendance.aggregate([
            { $match: { department_name: department } },
            { $unwind: "$attendanceRecords" },
            {
                $addFields: {
                    targetSemester: {
                        $cond: {
                            if: { $eq: ["$semester", "ODD"] },
                            then: "$attendanceRecords.sem_odd",
                            else: "$attendanceRecords.sem_even"
                        }
                    }
                }
            },
            { $unwind: "$targetSemester.leaves" },
            { $match: { "targetSemester.leaves.status": "pending" } },
            { $count: "count" }
        ]),
        // Today's attendance logic
    ]);
    return {
        dashboardType: 'hod',
        department: department,
        statistics: {
            totalStudents: totalStudents,
            pendingLeaves: pendingLeaves[0]?.count || 0,
            todayAbsent: 0 // Implement based on your logic
        }
    };
};
const getClubCoordinatorDashboardData = async (staff) => {
    // Get club statistics
    // This depends on how you store club coordinator assignments
    return {
        dashboardType: 'club_coordinator',
        statistics: {
            totalClubMembers: 0,
            pendingRequests: 0
        }
    };
};
const getRegularStaffDashboardData = async (staff, currentSemesterInfo) => {
    // Get in-charge classes statistics
    const inchargeClasses = staff.class_attend?.filter(cls => cls.incharge === true) || [];
    const classStats = await Promise.all(inchargeClasses.map(async (cls) => {
        const studentCount = await StudentAttendance_model_1.StudentAttendance.countDocuments({
            department_name: cls.department_name,
            program_id: cls.program_id,
            batch: cls.year,
            section: cls.section_name
        });
        const pendingLeaves = await StudentAttendance_model_1.StudentAttendance.aggregate([
            {
                $match: {
                    department_name: cls.department_name,
                    program_id: cls.program_id,
                    batch: cls.year,
                    section: cls.section_name
                }
            },
            { $unwind: "$attendanceRecords" },
            {
                $match: {
                    "attendanceRecords.academicYear": currentSemesterInfo.academicYear
                }
            },
            {
                $addFields: {
                    targetSemester: {
                        $cond: {
                            if: { $eq: [currentSemesterInfo.semester, 'ODD'] },
                            then: "$attendanceRecords.sem_odd",
                            else: "$attendanceRecords.sem_even"
                        }
                    }
                }
            },
            { $unwind: "$targetSemester.leaves" },
            { $match: { "targetSemester.leaves.status": "pending" } },
            { $count: "count" }
        ]);
        return {
            department: cls.department_name,
            program: cls.program_id,
            year: cls.year,
            section: cls.section_name,
            studentCount,
            pendingLeaves: pendingLeaves[0]?.count || 0
        };
    }));
    return {
        dashboardType: 'staff',
        inchargeClasses: classStats,
        totalPendingLeaves: classStats.reduce((sum, cls) => sum + cls.pendingLeaves, 0)
    };
};
const updateLeaveApproval = async (leaveId, staffId, approverRole, action, remarks) => {
    const status = action === 'approve' ? 'approved' : 'rejected';
    // Update in odd semester
    let result = await StudentAttendance_model_1.StudentAttendance.updateOne({
        'attendanceRecords.sem_odd.leaves._id': new mongoose_1.default.Types.ObjectId(leaveId)
    }, {
        $set: {
            'attendanceRecords.$[record].sem_odd.leaves.$[leave].approvals.$[approval].status': status,
            'attendanceRecords.$[record].sem_odd.leaves.$[leave].approvals.$[approval].updatedAt': new Date(),
            'attendanceRecords.$[record].sem_odd.leaves.$[leave].approvals.$[approval].remarks': remarks || '',
            'attendanceRecords.$[record].sem_odd.leaves.$[leave].status': status,
            'attendanceRecords.$[record].sem_odd.leaves.$[leave].updatedAt': new Date()
        }
    }, {
        arrayFilters: [
            { 'record.sem_odd.leaves._id': new mongoose_1.default.Types.ObjectId(leaveId) },
            { 'leave._id': new mongoose_1.default.Types.ObjectId(leaveId) },
            {
                'approval.approvedBy': staffId,
                'approval.approver': approverRole
            }
        ]
    });
    // If not found in odd, try even semester
    if (result.modifiedCount === 0) {
        result = await StudentAttendance_model_1.StudentAttendance.updateOne({
            'attendanceRecords.sem_even.leaves._id': new mongoose_1.default.Types.ObjectId(leaveId)
        }, {
            $set: {
                'attendanceRecords.$[record].sem_even.leaves.$[leave].approvals.$[approval].status': status,
                'attendanceRecords.$[record].sem_even.leaves.$[leave].approvals.$[approval].updatedAt': new Date(),
                'attendanceRecords.$[record].sem_even.leaves.$[leave].approvals.$[approval].remarks': remarks || '',
                'attendanceRecords.$[record].sem_even.leaves.$[leave].status': status,
                'attendanceRecords.$[record].sem_even.leaves.$[leave].updatedAt': new Date()
            }
        }, {
            arrayFilters: [
                { 'record.sem_even.leaves._id': new mongoose_1.default.Types.ObjectId(leaveId) },
                { 'leave._id': new mongoose_1.default.Types.ObjectId(leaveId) },
                {
                    'approval.approvedBy': staffId,
                    'approval.approver': approverRole
                }
            ]
        });
    }
    return result;
};
