"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStaffTimingByBioId = exports.getAllAttendanceStatusByBioId = exports.fixAllStaffDepartmentCodes = exports.uploadStaffCSV = exports.deletePublicationItem = exports.addPublicationItem = exports.updatePublicationItem = exports.getPublications = exports.deleteStaff = exports.updateStaff = exports.getStaffById = exports.getAllStaff = exports.createStaff = void 0;
const Staff_1 = require("../../models/staff/Staff");
const fs_1 = __importDefault(require("fs"));
const csv_parser_1 = __importDefault(require("csv-parser"));
const path_1 = __importDefault(require("path"));
const mongoose_1 = __importDefault(require("mongoose"));
const Departments_1 = require("../../models/admin/Departments");
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const dbmsql_1 = require("../../config/dbmsql");
//import { DepartmentModel } from "../../models/admin/Departments.js";
/**
 * CREATE STAFF
 */
const createStaff = async (req, res) => {
    try {
        const { staff_id, alt_staffid, salute, name, gender, dob, college_email, designation, department_code, department_name, joining_date } = req.body;
        // 🔹 Basic validation
        if (!staff_id ||
            !alt_staffid ||
            !salute ||
            !name ||
            !gender ||
            !dob ||
            !college_email ||
            !designation ||
            !department_code ||
            !department_name ||
            !joining_date) {
            return res.status(400).json({
                success: false,
                message: "Required fields are missing"
            });
        }
        // 🔹 Check duplicate staff_id
        const existingStaff = await Staff_1.StaffModel.findOne({ staff_id });
        if (existingStaff) {
            return res.status(409).json({
                success: false,
                message: "Staff ID already exists"
            });
        }
        // 🔹 Check duplicate bio_id (if provided)
        if (req.body.bio_id) {
            const bioExists = await Staff_1.StaffModel.findOne({
                bio_id: req.body.bio_id
            });
            if (bioExists) {
                return res.status(409).json({
                    success: false,
                    message: "BIO ID already exists"
                });
            }
        }
        // 🔹 Create staff
        const staff = new Staff_1.StaffModel(req.body);
        const savedStaff = await staff.save();
        return res.status(201).json({
            success: true,
            message: "Staff created successfully",
            data: savedStaff
        });
    }
    catch (error) {
        console.error("Create Staff Error:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};
exports.createStaff = createStaff;
/**
 * GET ALL STAFF
 */
const getAllStaff = async (_req, res) => {
    try {
        const staffList = await Staff_1.StaffModel.find().populate("department_name");
        res.status(200).json(staffList);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.getAllStaff = getAllStaff;
/**
 * GET STAFF BY ID (Mongo _id or staff_id)
 */
const getStaffById = async (req, res) => {
    try {
        const { id } = req.params;
        const staff = (await Staff_1.StaffModel.findOne({ staff_id: id }));
        if (!staff) {
            return res.status(404).json({ message: "Staff not found" });
        }
        res.status(200).json(staff);
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.getStaffById = getStaffById;
/**
 * UPDATE STAFF
 */
const updateStaff = async (req, res) => {
    try {
        const { id } = req.params;
        const staff = await Staff_1.StaffModel.findByIdAndUpdate(id, req.body, {
            new: true,
            runValidators: true
        });
        if (!staff) {
            return res.status(404).json({ message: "Staff not found" });
        }
        res.status(200).json({
            message: "Staff updated successfully",
            data: staff,
            success: true
        });
    }
    catch (error) {
        res.status(400).json({ message: error.message });
    }
};
exports.updateStaff = updateStaff;
/**
 * DELETE STAFF
 */
const deleteStaff = async (req, res) => {
    try {
        const { id } = req.params;
        const staff = await Staff_1.StaffModel.findByIdAndDelete(id);
        if (!staff) {
            return res.status(404).json({ message: "Staff not found" });
        }
        res.status(200).json({
            message: "Staff deleted successfully"
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.deleteStaff = deleteStaff;
/**
 * GET STAFF
 */
const getPublications = async (req, res) => {
    try {
        const { staff_id } = req.params;
        const staff = await Staff_1.StaffModel.findOne({ staff_id }).select("publications");
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: "Staff member not found"
            });
        }
        return res.status(200).json({
            success: true,
            data: staff.publications || {}
        });
    }
    catch (error) {
        console.error("Error fetching publications:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};
exports.getPublications = getPublications;
/**
 * UPDATE SPECIFIC PUBLICATION TYPE
 */
/**
 * UPDATE SPECIFIC PUBLICATION ITEM BY ID
 */
const updatePublicationItem = async (req, res) => {
    try {
        const { staff_id, publication_type, publication_id } = req.params;
        const publicationData = req.body;
        const validPublicationTypes = [
            'journal_articles',
            'conference_papers',
            'book_chapters',
            'books_authored',
            'edited_volume',
            'patent'
        ];
        if (!validPublicationTypes.includes(publication_type)) {
            return res.status(400).json({
                success: false,
                message: "Invalid publication type"
            });
        }
        // Validate if publication_id is a valid ObjectId
        if (!mongoose_1.default.Types.ObjectId.isValid(publication_id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid publication ID format"
            });
        }
        const staff = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: "Staff member not found"
            });
        }
        // Check if the publication item exists
        const publicationArray = staff.publications?.[publication_type];
        if (!publicationArray || !Array.isArray(publicationArray)) {
            return res.status(404).json({
                success: false,
                message: "Publication type not found or empty"
            });
        }
        const publicationExists = publicationArray.some((item) => item._id?.toString() === publication_id);
        if (!publicationExists) {
            return res.status(404).json({
                success: false,
                message: "Publication item not found"
            });
        }
        // Update the specific publication item using positional operator with _id
        const updatedStaff = await Staff_1.StaffModel.findOneAndUpdate({
            staff_id,
            [`publications.${publication_type}._id`]: new mongoose_1.default.Types.ObjectId(publication_id)
        }, {
            $set: {
                [`publications.${publication_type}.$`]: {
                    ...publicationData,
                    _id: new mongoose_1.default.Types.ObjectId(publication_id) // Preserve the original _id
                }
            }
        }, { new: true, runValidators: true });
        if (!updatedStaff) {
            return res.status(404).json({
                success: false,
                message: "Failed to update publication item"
            });
        }
        // Find the updated publication item
        const updatedPublicationArray = updatedStaff.publications?.[publication_type];
        const updatedItem = updatedPublicationArray?.find((item) => item._id?.toString() === publication_id);
        return res.status(200).json({
            success: true,
            message: "Publication item updated successfully",
            data: updatedItem
        });
    }
    catch (error) {
        console.error("Error updating publication item:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};
exports.updatePublicationItem = updatePublicationItem;
/**
 * ADD SINGLE PUBLICATION ITEM
 */
/**
 * ADD SINGLE PUBLICATION ITEM
 */
const addPublicationItem = async (req, res) => {
    try {
        const { staff_id, publication_type } = req.params;
        const publicationItem = req.body;
        const validPublicationTypes = [
            'journal_articles',
            'conference_papers',
            'book_chapters',
            'books_authored',
            'edited_volume',
            'patent'
        ];
        if (!validPublicationTypes.includes(publication_type)) {
            return res.status(400).json({
                success: false,
                message: "Invalid publication type"
            });
        }
        const staff = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: "Staff member not found"
            });
        }
        // Generate new ObjectId for the publication item
        const newPublicationItem = {
            ...publicationItem,
            _id: new mongoose_1.default.Types.ObjectId() // Generate new _id
        };
        const updatedStaff = await Staff_1.StaffModel.findOneAndUpdate({ staff_id }, {
            $push: {
                [`publications.${publication_type}`]: newPublicationItem
            }
        }, { new: true, runValidators: true });
        // Get the newly added item (last item in the array)
        const publicationArray = updatedStaff?.publications?.[publication_type];
        const newItem = publicationArray?.[publicationArray.length - 1];
        return res.status(201).json({
            success: true,
            message: "Publication item added successfully",
            data: newItem
        });
    }
    catch (error) {
        console.error("Error adding publication item:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};
exports.addPublicationItem = addPublicationItem;
/**
 * DELETE SINGLE PUBLICATION ITEM
 */
/**
 * DELETE SINGLE PUBLICATION ITEM BY ID
 */
const deletePublicationItem = async (req, res) => {
    try {
        const { staff_id, publication_type, publication_id } = req.params;
        console.log('Delete request received:', { staff_id, publication_type, publication_id });
        const validPublicationTypes = [
            'journal_articles',
            'conference_papers',
            'book_chapters',
            'books_authored',
            'edited_volume',
            'patent'
        ];
        if (!validPublicationTypes.includes(publication_type)) {
            return res.status(400).json({
                success: false,
                message: "Invalid publication type"
            });
        }
        // Validate if publication_id is a valid ObjectId
        if (!mongoose_1.default.Types.ObjectId.isValid(publication_id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid publication ID format"
            });
        }
        const staff = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staff) {
            return res.status(404).json({
                success: false,
                message: "Staff member not found"
            });
        }
        // Check if the publication item exists with better debugging
        const publicationArray = staff.publications?.[publication_type];
        console.log('Existing publications:', publicationArray?.map((item) => item._id?.toString()));
        if (!publicationArray || !Array.isArray(publicationArray)) {
            return res.status(404).json({
                success: false,
                message: "Publication type not found or empty"
            });
        }
        const publicationItem = publicationArray.find((item) => item._id?.toString() === publication_id);
        if (!publicationItem) {
            console.log('Publication not found. Available IDs:', publicationArray.map((item) => item._id?.toString()));
            return res.status(404).json({
                success: false,
                message: "Publication item not found",
                availableIds: publicationArray.map((item) => item._id?.toString())
            });
        }
        console.log('Found publication to delete:', publicationItem);
        // Remove the specific publication item using _id
        const updatedStaff = await Staff_1.StaffModel.findOneAndUpdate({ staff_id }, {
            $pull: {
                [`publications.${publication_type}`]: { _id: new mongoose_1.default.Types.ObjectId(publication_id) }
            }
        }, { new: true, runValidators: true });
        if (!updatedStaff) {
            return res.status(500).json({
                success: false,
                message: "Failed to delete publication item"
            });
        }
        console.log('Publication deleted successfully');
        return res.status(200).json({
            success: true,
            message: "Publication item deleted successfully",
            data: updatedStaff.publications?.[publication_type]
        });
    }
    catch (error) {
        console.error("Error deleting publication item:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};
exports.deletePublicationItem = deletePublicationItem;
// ===========================
// CSV UPLOAD (NO MIDDLEWARE)
// ===========================
const uploadStaffCSV = async (req, res) => {
    try {
        if (!req.files || !req.files.file) {
            return res.status(400).json({ message: "CSV file is required" });
        }
        const csvFile = req.files.file;
        // Ensure uploads folder exists
        const uploadPath = path_1.default.join("uploads", "csv");
        if (!fs_1.default.existsSync(uploadPath)) {
            fs_1.default.mkdirSync(uploadPath, { recursive: true });
        }
        const filePath = path_1.default.join(uploadPath, `${Date.now()}-${csvFile.name}`);
        // Save file to server
        await csvFile.mv(filePath);
        const results = [];
        fs_1.default.createReadStream(filePath)
            .pipe((0, csv_parser_1.default)())
            .on("data", (row) => {
            results.push(row);
        })
            .on("end", async () => {
            try {
                let inserted = 0;
                let skipped = 0;
                for (const row of results) {
                    const exists = await Staff_1.StaffModel.findOne({
                        $or: [{ staff_id: row.staff_id }, { email: row.email }],
                    });
                    if (exists) {
                        skipped++;
                        continue;
                    }
                    await Staff_1.StaffModel.create({
                        category: row.category,
                        staff_id: row.staff_id,
                        alt_staffid: row.alt_staffid,
                        bio_id: row.bio_id,
                        salute: row.salute,
                        name: row.name,
                        gender: row.gender,
                        dob: row.dob,
                        marital_status: row.marital_status,
                        college_email: row.college_email || '',
                        email: row.email || '',
                        phone: row.phone,
                        alternate_phone: row.alternate_phone || '',
                        blood_group: row.blood_group || '',
                        nationality: row.nationality || 'Indian',
                        religion: row.religion,
                        mother_tongue: row.mother_tongue || '',
                        community: row.community,
                        address: {
                            present: {
                                street: row.present_street || '',
                                city: row.present_city || '',
                                state: row.present_state || '',
                                pincode: row.present_pincode || '',
                            },
                            permanent: {
                                street: row.permanent_street || '',
                                city: row.permanent_city || '',
                                state: row.permanent_state || '',
                                pincode: row.permanent_pincode || '',
                            },
                        },
                        designation: row.designation,
                        department_code: row.department_code || '',
                        department_name: row.department_name,
                        shift: row.shift,
                        stream: row.stream,
                        aadhar_number: row.aadhar_number || 0,
                        pan_number: row.pan_number || '',
                        joining_date: row.joining_date,
                        employee_type: row.category.toLowerCase(),
                        isActive: "true",
                        qualifications: JSON.parse(row.qualifications || "[]"),
                        experience: JSON.parse(row.experience || "[]"),
                        class_attend: JSON.parse(row.class_attend || "[]"),
                        research_expertise: JSON.parse(row.research_expertise || "{}"),
                        isDoctorate: row.isDoctorate === "true" || false,
                        phd_details: JSON.parse(row.phd_details || "{}"),
                        research_guidance: JSON.parse(row.research_guidance || "[]"),
                        publications: JSON.parse(row.publications || "{}"),
                        intellectual_property: JSON.parse(row.intellectual_property || "[]"),
                        funded_projects: JSON.parse(row.funded_projects || "[]"),
                        consultancy: JSON.parse(row.consultancy || "[]"),
                        collaborations: JSON.parse(row.collaborations || "[]"),
                        memberships: JSON.parse(row.memberships || "[]"),
                        editorial_roles: JSON.parse(row.editorial_roles || "[]"),
                        awards: JSON.parse(row.awards || "[]"),
                        events_participated: JSON.parse(row.events_participated || "[]"),
                        innovation_activities: JSON.parse(row.innovation_activities || "[]"),
                        research_profiles: JSON.parse(row.research_profiles || "{}"),
                        disciplinary_actions: JSON.parse(row.disciplinary_actions || "[]"),
                        username: row.staff_id,
                        password: row.password || 'bhcstaff',
                        role: row.role || 'staff',
                        profile_pic: row.profile_pic || '',
                    });
                    inserted++;
                }
                fs_1.default.unlinkSync(filePath);
                return res.status(200).json({
                    message: "CSV processed successfully",
                    inserted,
                    skipped,
                    total: results.length,
                });
            }
            catch (err) {
                return res.status(500).json({ message: err.message, "error": "enna eeror" });
            }
        });
    }
    catch (error) {
        return res.status(500).json({ message: error.message });
    }
};
exports.uploadStaffCSV = uploadStaffCSV;
//=============================================== SET STAFF DEPARTMENT CODE FOR ALL STAFFS USING THE DEPARTMENT MODEL ============================
const fixAllStaffDepartmentCodes = async (req, res) => {
    try {
        console.log("Starting bulk department code fix...");
        // Get statistics before fix
        const beforeStats = await getDepartmentCodeStats();
        // Perform the fix
        const fixResults = await performBulkDepartmentCodeFix();
        // Get statistics after fix
        const afterStats = await getDepartmentCodeStats();
        return res.status(200).json({
            success: true,
            message: "Bulk department code fix completed successfully",
            summary: {
                totalStaffProcessed: fixResults.totalStaff,
                successfullyFixed: fixResults.fixed,
                failed: fixResults.failed,
                skipped: fixResults.skipped,
                noChange: fixResults.noChange
            },
            stats: {
                before: beforeStats,
                after: afterStats,
                improvement: {
                    emptyCodesBefore: beforeStats.emptyCodes,
                    emptyCodesAfter: afterStats.emptyCodes,
                    mismatchBefore: beforeStats.mismatchCount,
                    mismatchAfter: afterStats.mismatchCount
                }
            },
            details: fixResults.details.slice(0, 50), // Return first 50 details only
            fullReportAvailable: fixResults.details.length > 50,
            timestamp: new Date().toISOString()
        });
    }
    catch (error) {
        console.error("Error in bulk department code fix:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to fix department codes",
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
};
exports.fixAllStaffDepartmentCodes = fixAllStaffDepartmentCodes;
// Main function to perform bulk fix
const performBulkDepartmentCodeFix = async () => {
    // Get all staff with department_name (excluding those without department_name)
    const allStaff = await Staff_1.StaffModel.find({
        department_name: { $exists: true, $ne: "" }
    }).select('staff_id name department_code department_name department');
    console.log(`Found ${allStaff.length} staff with department names`);
    const results = {
        totalStaff: allStaff.length,
        fixed: 0,
        failed: 0,
        skipped: 0,
        noChange: 0,
        details: []
    };
    // Get all departments for efficient lookup
    const allDepartments = await Departments_1.DepartmentModel.find({});
    const deptMap = new Map();
    // Create a map of department_name (lowercase) to department data
    allDepartments.forEach(dept => {
        const normalizedName = dept.department_name.toLowerCase().trim();
        deptMap.set(normalizedName, {
            id: dept._id,
            code: dept.department_code,
            name: dept.department_name
        });
    });
    console.log(`Loaded ${allDepartments.length} departments for lookup`);
    for (const staff of allStaff) {
        const staffDeptName = staff.department_name;
        try {
            // Check if department name is valid
            if (!staffDeptName || staffDeptName.trim() === "") {
                results.details.push({
                    staff_id: staff.staff_id,
                    name: staff.name,
                    department_name: "",
                    old_code: staff.department_code || "",
                    new_code: "",
                    status: 'SKIPPED',
                    message: 'Empty department name'
                });
                results.skipped++;
                continue;
            }
            // Normalize department name for comparison
            const normalizedDeptName = staffDeptName.toLowerCase().trim();
            const department = deptMap.get(normalizedDeptName);
            if (!department) {
                // Try partial match if exact match fails
                const foundDept = allDepartments.find(dept => dept.department_name.toLowerCase().includes(normalizedDeptName) ||
                    normalizedDeptName.includes(dept.department_name.toLowerCase()));
                if (!foundDept) {
                    results.details.push({
                        staff_id: staff.staff_id,
                        name: staff.name,
                        department_name: staffDeptName,
                        old_code: staff.department_code || "",
                        new_code: "",
                        status: 'DEPARTMENT_NOT_FOUND',
                        message: `No department found for: ${staffDeptName}`
                    });
                    results.failed++;
                    continue;
                }
                // Use the found department
                const foundDeptData = {
                    id: foundDept._id,
                    code: foundDept.department_code,
                    name: foundDept.department_name
                };
                await updateStaffDepartment(staff, foundDeptData, results);
            }
            else {
                await updateStaffDepartment(staff, department, results);
            }
        }
        catch (error) {
            results.details.push({
                staff_id: staff.staff_id,
                name: staff.name,
                department_name: staffDeptName,
                old_code: staff.department_code || "",
                new_code: "",
                status: 'FAILED',
                message: `Error: ${error.message}`
            });
            results.failed++;
        }
    }
    console.log(`Fix completed: ${results.fixed} fixed, ${results.noChange} no change, ${results.failed} failed, ${results.skipped} skipped`);
    return results;
};
// Helper function to update staff department
const updateStaffDepartment = async (staff, department, results) => {
    const oldCode = staff.department_code || "";
    const newCode = department.code;
    if (oldCode === newCode && staff.department?.toString() === department.id.toString()) {
        // No change needed
        results.details.push({
            staff_id: staff.staff_id,
            name: staff.name,
            department_name: department.name,
            old_code: oldCode,
            new_code: newCode,
            status: 'NO_CHANGE',
            message: 'Department code already correct'
        });
        results.noChange++;
        return;
    }
    try {
        // Update staff record
        const updateData = {
            department_code: newCode,
            department_name: department.name // Ensure consistency
        };
        // Update department reference if needed
        if (!staff.department || staff.department.toString() !== department.id.toString()) {
            updateData.department = department.id;
        }
        await Staff_1.StaffModel.updateOne({ _id: staff._id }, { $set: updateData });
        results.details.push({
            staff_id: staff.staff_id,
            name: staff.name,
            department_name: department.name,
            old_code: oldCode,
            new_code: newCode,
            status: 'FIXED',
            message: oldCode ? `Updated from ${oldCode} to ${newCode}` : `Set code to ${newCode}`
        });
        results.fixed++;
    }
    catch (error) {
        throw new Error(`Failed to update staff: ${error.message}`);
    }
};
// Get statistics about department codes
const getDepartmentCodeStats = async () => {
    const totalStaff = await Staff_1.StaffModel.countDocuments();
    const staffWithDeptName = await Staff_1.StaffModel.countDocuments({
        department_name: { $exists: true, $ne: "" }
    });
    const emptyCodes = await Staff_1.StaffModel.countDocuments({
        department_code: { $in: ["", null, undefined] },
        department_name: { $exists: true, $ne: "" }
    });
    // Get all departments for mismatch checking
    const allDepartments = await Departments_1.DepartmentModel.find({});
    const deptNameToCodeMap = new Map();
    allDepartments.forEach(dept => {
        const normalizedName = dept.department_name.toLowerCase().trim();
        deptNameToCodeMap.set(normalizedName, dept.department_code);
    });
    // Get staff with potential mismatches
    const allStaffWithDept = await Staff_1.StaffModel.find({
        department_name: { $exists: true, $ne: "" },
        department_code: { $exists: true, $ne: "" }
    }).select('department_name department_code');
    let mismatchCount = 0;
    allStaffWithDept.forEach(staff => {
        const normalizedName = staff.department_name.toLowerCase().trim();
        const expectedCode = deptNameToCodeMap.get(normalizedName);
        if (expectedCode && staff.department_code !== expectedCode) {
            mismatchCount++;
        }
    });
    return {
        totalStaff,
        staffWithDepartmentName: staffWithDeptName,
        staffWithoutDepartmentName: totalStaff - staffWithDeptName,
        emptyCodes,
        mismatchCount,
        percentageWithCodes: staffWithDeptName > 0
            ? ((staffWithDeptName - emptyCodes) / staffWithDeptName * 100).toFixed(2) + '%'
            : '0%'
    };
};
function convertTimeString(timeStr) {
    if (!timeStr)
        return "00:00";
    const parts = timeStr.split(".");
    if (parts.length !== 2)
        return "00:00";
    const hour = parts[0].padStart(2, "0");
    const minute = parts[1].padStart(2, "0");
    return `${hour}:${minute}`;
}
exports.getAllAttendanceStatusByBioId = (0, express_async_handler_1.default)(async (req, res) => {
    const { bio_id } = req.params;
    const pool = await (0, dbmsql_1.getPool)();
    // ===================================
    // 1) FETCH STAFF TIMING
    // ===================================
    const staffResult = await pool.request()
        .input("bio_id", dbmsql_1.sql.VarChar, bio_id)
        .query(`
            SELECT staff_id, staff_name, department, in_time, out_time
            FROM dbo.Staff_timing
            WHERE TRY_CAST(bio_id AS VARCHAR(50)) = @bio_id
        `);
    if (staffResult.recordset.length === 0) {
        res.status(404).json({ message: "bio_id not found in Staff_timing" });
        return;
    }
    const staff = staffResult.recordset[0];
    // Convert schedule IN time "9.30" → "09:30"
    const scheduledInHHMM = convertTimeString(staff.in_time);
    // ===================================
    // 2) FETCH ALL LOGS FOR THIS BIO ID
    // ===================================
    const logsResult = await pool.request()
        .input("bio_id", dbmsql_1.sql.VarChar, bio_id)
        .query(`
            SELECT 
                LogDate,
                Status AS log_status,      -- CIN / COUT
                status_ AS log_place       -- Log place
            FROM dbo.Paralleltable1
            WHERE TRY_CAST(UserId AS VARCHAR(50)) = @bio_id
            ORDER BY LogDate ASC
        `);
    const logs = logsResult.recordset;
    if (logs.length === 0) {
        res.json({
            bio_id,
            staff_id: staff.staff_id,
            staff_name: staff.staff_name,
            records: []
        });
        return;
    }
    // ===================================
    // 3) GROUP LOGS BY DATE
    // ===================================
    const grouped = {};
    logs.forEach(log => {
        const date = log.LogDate.toISOString().split("T")[0];
        if (!grouped[date])
            grouped[date] = [];
        grouped[date].push(log);
    });
    const finalRecords = [];
    // ===================================
    // 4) BUILD DAILY ATTENDANCE DETAILS
    // ===================================
    for (const date in grouped) {
        const dayLogs = grouped[date].sort((a, b) => new Date(a.LogDate).getTime() - new Date(b.LogDate).getTime());
        const first = dayLogs[0];
        const last = dayLogs[dayLogs.length - 1];
        // FIRST IN DETAILS
        const first_in = first.LogDate;
        const first_in_status = first.log_status; // CIN / COUT
        const first_in_place = first.log_place;
        // LAST OUT DETAILS
        const last_out = last.LogDate;
        const last_out_status = last.log_status;
        const last_out_place = last.log_place;
        // ===================================
        // LATE CHECK (simple comparison)
        // ===================================
        const scheduled_in = new Date(`${date}T${scheduledInHHMM}:00`);
        const actual_first_in = new Date(first_in);
        let first_in_late = "";
        if (actual_first_in > scheduled_in) {
            first_in_late = "Late";
        }
        // Main status (same as first_in_late)
        const status = first_in_late || "Present";
        finalRecords.push({
            date,
            first_in,
            first_in_status,
            first_in_place,
            first_in_late,
            last_out,
            last_out_status,
            last_out_place,
            status
        });
    }
    // ===================================
    // 5) SEND RESPONSE
    // ===================================
    res.json({
        bio_id,
        staff_id: staff.staff_id,
        staff_name: staff.staff_name,
        department: staff.department,
        records: finalRecords
    });
});
exports.getStaffTimingByBioId = (0, express_async_handler_1.default)(async (req, res) => {
    const { bio_id } = req.params;
    const pool = await (0, dbmsql_1.getPool)();
    const result = await pool.request()
        .input("bio_id", dbmsql_1.sql.VarChar, bio_id)
        .query(`
            SELECT 
                staff_id,
                staff_name,
                bio_id,
                department,
                category,
                in_time,
                out_time
            FROM dbo.Staff_timing
            WHERE TRY_CAST(bio_id AS VARCHAR(50)) = @bio_id
        `);
    if (result.recordset.length === 0) {
        res.status(404).json({
            message: "No staff timing found for this bio_id"
        });
        return;
    }
    res.json({
        success: true,
        data: result.recordset[0]
    });
});
