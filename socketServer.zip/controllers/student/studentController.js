"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.studentLogin = exports.getStudentByRollno = exports.getAllStudents = exports.getStudentStats = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const Student_1 = require("../../models/students/Student");
const ERROR_MESSAGES = {
    STUDENT_NOT_FOUND: "Student not found",
    INVALID_ROLL_NO: (roll_no) => `No student with roll_no ${roll_no}`,
};
exports.getStudentStats = (0, express_async_handler_1.default)(async (req, res) => {
    try {
        // Aggregate statistics
        const totalStudents = await Student_1.Student.countDocuments();
        // Count by department
        const byDepartment = await Student_1.Student.aggregate([
            { $group: { _id: "$department", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
        ]);
        // Count by course
        const byCourse = await Student_1.Student.aggregate([
            { $group: { _id: "$course", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
        ]);
        // Count by year (if applicable)
        const byYear = await Student_1.Student.aggregate([
            { $group: { _id: "$curr_year", count: { $sum: 1 } } },
            { $sort: { _id: 1 } },
        ]);
        res.json({
            success: true,
            stats: {
                totalStudents,
                byDepartment,
                byCourse,
                byYear,
            },
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch student statistics",
            error: error.message,
        });
    }
});
exports.getAllStudents = (0, express_async_handler_1.default)(async (req, res) => {
    try {
        const students = await Student_1.Student.find().sort({ createdAt: -1 }).lean();
        const count = students.length;
        res.json({
            success: true,
            data: students,
            count,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch students",
            error: error.message,
        });
    }
});
exports.getStudentByRollno = (0, express_async_handler_1.default)(async (req, res) => {
    try {
        const roll_no = Number(req.params.roll_no);
        const student = await Student_1.Student.findOne({ roll_no }).lean();
        if (!student) {
            res.status(404).json({
                success: false,
                message: ERROR_MESSAGES.INVALID_ROLL_NO(roll_no),
            });
            return;
        }
        res.status(200).json({
            success: true,
            data: student
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch student",
            error: error.message,
        });
    }
});
exports.studentLogin = (0, express_async_handler_1.default)(async (req, res) => {
    const { roll_no, dob } = req.body;
    if (!roll_no || !dob) {
        res.status(400).json({
            success: false,
            message: "Roll number and DOB are required",
        });
        return;
    }
    const inputDob = new Date(dob).toISOString().split("T")[0];
    const student = await Student_1.Student.findOne({ roll_no });
    if (!student) {
        res.status(404).json({
            success: false,
            message: "Invalid roll number",
        });
        return;
    }
    const storedDob = new Date(student.personal_info?.dob)
        .toISOString()
        .split("T")[0];
    if (inputDob !== storedDob) {
        res.status(401).json({
            success: false,
            message: "Invalid date of birth",
        });
        return;
    }
    // SUCCESS (NO JWT)
    res.status(200).json({
        success: true,
        message: "Login successful",
        data: student
    });
});
