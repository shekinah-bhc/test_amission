"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEsMarksByExamNo = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const EseMarks_1 = require("../../models/students/EseMarks");
const ERROR_MESSAGES = {
    MARK_NOT_FOUND: "Mark record not found",
    INVALID_EXAMNO: (EXAMNO) => `No record found for exam number '${EXAMNO}'`,
};
exports.getEsMarksByExamNo = (0, express_async_handler_1.default)(async (req, res) => {
    try {
        const exam_no = req.params.exam_no;
        if (!exam_no) {
            res.status(400).json({
                success: false,
                message: "Missing required parameter: exam_no",
            });
            return;
        }
        const marks = await EseMarks_1.EsMarks.find({ EXAMNO: exam_no }).lean();
        if (!marks || marks.length === 0) {
            res.status(404).json({
                success: false,
                message: ERROR_MESSAGES.INVALID_EXAMNO(exam_no),
            });
            return;
        }
        res.status(200).json({
            success: true,
            data: marks,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch marks data",
            error: error.message,
        });
    }
});
