"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSeatAllocationByRollNo = void 0;
const Seating_1 = __importDefault(require("../../models/students/Seating"));
// Get seat allocation by Roll Number
const getSeatAllocationByRollNo = async (req, res) => {
    try {
        const { rollno } = req.params;
        if (!rollno) {
            return res.status(400).json({
                success: false,
                message: 'Roll number is required'
            });
        }
        const seatAllocation = await Seating_1.default.find({ Roll_No: rollno });
        if (!seatAllocation) {
            return res.status(404).json({
                success: false,
                message: `No seat allocation found for roll number: ${rollno}`
            });
        }
        res.status(200).json({
            success: true,
            message: 'Seat allocation retrieved successfully',
            data: seatAllocation
        });
    }
    catch (error) {
        console.error('Error fetching seat allocation:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error instanceof Error ? error.message : 'Unknown error occurred'
        });
    }
};
exports.getSeatAllocationByRollNo = getSeatAllocationByRollNo;
