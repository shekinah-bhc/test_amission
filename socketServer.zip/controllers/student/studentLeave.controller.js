"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkLeaveEligibility = exports.getLeaveStatistics = exports.cancelLeave = exports.getStudentLeaves = exports.applyLeave = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const StudentAttendance_model_1 = require("../../models/students/StudentAttendance.model");
const util_1 = require("../../services/util");
const Studentattendance_types_1 = require("../../interfaces/Studentattendance.types");
// Define leave type specific limits
const LEAVE_TYPE_LIMITS = {
    [Studentattendance_types_1.LeaveType.CASUAL]: 5,
    [Studentattendance_types_1.LeaveType.MEDICAL]: 30,
    [Studentattendance_types_1.LeaveType.ON_DUTY]: 7,
};
const applyLeave = async (req, res) => {
    try {
        const { roll_no, leaveType, startDate, endDate, reason, supportingDocument } = req.body;
        // Validate required fields
        if (!roll_no || !leaveType || !startDate || !endDate || !reason) {
            return res.status(400).json({
                message: "roll_no, leaveType, startDate, endDate, reason are required",
                code: "MISSING_REQUIRED_FIELDS"
            });
        }
        // Validate leave type
        if (!Object.values(Studentattendance_types_1.LeaveType).includes(leaveType)) {
            return res.status(400).json({
                message: `Invalid leave type. Must be one of: ${Object.values(Studentattendance_types_1.LeaveType).join(', ')}`,
                code: "INVALID_LEAVE_TYPE"
            });
        }
        // Validate dates
        const requestedStart = new Date(startDate);
        const requestedEnd = new Date(endDate);
        // Check if dates are valid
        if (isNaN(requestedStart.getTime()) || isNaN(requestedEnd.getTime())) {
            return res.status(400).json({
                message: "Invalid date format provided. Use ISO format (YYYY-MM-DD)",
                code: "INVALID_DATE_FORMAT"
            });
        }
        // Check that end date is not before start date
        if (requestedEnd < requestedStart) {
            return res.status(400).json({
                message: "End date cannot be earlier than start date",
                code: "INVALID_DATE_RANGE"
            });
        }
        // Check that dates are not in the past
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        requestedStart.setHours(0, 0, 0, 0);
        requestedEnd.setHours(0, 0, 0, 0);
        if (requestedStart < today) {
            return res.status(400).json({
                message: "Start date cannot be in the past",
                code: "PAST_START_DATE"
            });
        }
        // Check if end date is in the past
        if (requestedEnd < today) {
            return res.status(400).json({
                message: "End date cannot be in the past",
                code: "PAST_END_DATE"
            });
        }
        // Calculate leave duration
        const leaveDuration = Math.ceil((requestedEnd.getTime() - requestedStart.getTime()) / (1000 * 60 * 60 * 24)) + 1;
        // Check minimum leave duration
        if (leaveDuration <= 0) {
            return res.status(400).json({
                message: "Leave duration must be at least 1 day",
                code: "INVALID_DURATION"
            });
        }
        // Check leave type specific limits
        const maxDuration = LEAVE_TYPE_LIMITS[leaveType] || 30;
        if (leaveDuration > maxDuration) {
            return res.status(400).json({
                message: `${leaveType} leave cannot exceed ${maxDuration} days`,
                code: "EXCEEDS_MAX_DURATION"
            });
        }
        // Find student
        const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no });
        if (!student) {
            return res.status(404).json({
                message: "Student not found",
                code: "STUDENT_NOT_FOUND"
            });
        }
        // Get semester information
        const leaveDate = new Date(startDate);
        const semesterInfo = await (0, util_1.getCurrentSemester)(leaveDate);
        if (!semesterInfo) {
            return res.status(400).json({
                message: "Leave date does not fall within any academic semester",
                code: "INVALID_SEMESTER"
            });
        }
        // Find academic record
        const academicRecord = student.attendanceRecords.find((r) => r.academicYear === semesterInfo.academicYear);
        if (!academicRecord) {
            return res.status(400).json({
                message: `No academic record found for academic year ${semesterInfo.academicYear}`,
                code: "NO_ACADEMIC_RECORD"
            });
        }
        // Get semester object
        const semesterObj = semesterInfo.semester === Studentattendance_types_1.Semester.ODD
            ? academicRecord.sem_odd
            : academicRecord.sem_even;
        // Check if semesterObj exists
        if (!semesterObj) {
            return res.status(400).json({
                message: `Semester data not found for ${semesterInfo.semester === Studentattendance_types_1.Semester.ODD ? 'odd' : 'even'} semester`,
                code: "SEMESTER_DATA_NOT_FOUND"
            });
        }
        // Check for overlapping leaves
        const conflictingStatuses = [Studentattendance_types_1.LeaveStatus.SUBMITTED, Studentattendance_types_1.LeaveStatus.PENDING, Studentattendance_types_1.LeaveStatus.APPROVED];
        const hasOverlappingLeaveInSemester = semesterObj.leaves.some((existingLeave) => {
            const existingStart = new Date(existingLeave.startDate);
            const existingEnd = new Date(existingLeave.endDate);
            existingStart.setHours(0, 0, 0, 0);
            existingEnd.setHours(0, 0, 0, 0);
            const dateOverlaps = requestedStart <= existingEnd && requestedEnd >= existingStart;
            const statusConflicts = conflictingStatuses.includes(existingLeave.status);
            return dateOverlaps && statusConflicts;
        });
        if (hasOverlappingLeaveInSemester) {
            return res.status(400).json({
                message: "You already have an approved or pending leave application for one or more of the selected dates in this semester.",
                code: "LEAVE_DATE_CONFLICT"
            });
        }
        // Generate approval chain based on leave type
        const generateApprovalChain = (type) => {
            const approvals = [];
            switch (type) {
                case Studentattendance_types_1.LeaveType.CASUAL:
                    approvals.push({
                        approver: Studentattendance_types_1.ApproverRole.CLASS_INCHARGE,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    }, {
                        approver: Studentattendance_types_1.ApproverRole.HOD,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    });
                    break;
                case Studentattendance_types_1.LeaveType.MEDICAL:
                    approvals.push({
                        approver: Studentattendance_types_1.ApproverRole.CLASS_INCHARGE,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    }, {
                        approver: Studentattendance_types_1.ApproverRole.HOD,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    }, {
                        approver: Studentattendance_types_1.ApproverRole.VP,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    });
                    break;
                case Studentattendance_types_1.LeaveType.ON_DUTY:
                    approvals.push({
                        approver: Studentattendance_types_1.ApproverRole.CLUB_COORDINATOR,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    }, {
                        approver: Studentattendance_types_1.ApproverRole.HOD,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    }, {
                        approver: Studentattendance_types_1.ApproverRole.VP,
                        status: 'pending',
                        approvedBy: "",
                        documentVerified: false,
                        remarks: "",
                        updatedAt: new Date()
                    });
                    break;
                default:
                    throw new Error(`Unsupported leave type: ${type}`);
            }
            return approvals;
        };
        // Helper function to get MIME type
        const getMimeType = (extension) => {
            const mimeTypes = {
                'pdf': 'application/pdf',
                'jpg': 'image/jpeg',
                'jpeg': 'image/jpeg',
                'png': 'image/png',
                'doc': 'application/msword',
                'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            };
            return mimeTypes[extension] || 'application/octet-stream';
        };
        // Process supporting documents
        let supportingDocumentArray = [];
        if (supportingDocument) {
            const filePaths = Array.isArray(supportingDocument)
                ? supportingDocument
                : [supportingDocument];
            supportingDocumentArray = await Promise.all(filePaths.map(async (filePath) => {
                const fileName = path_1.default.basename(filePath);
                const fileExtension = path_1.default.extname(fileName).toLowerCase().slice(1);
                // Validate file extension
                const allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
                if (!allowedExtensions.includes(fileExtension)) {
                    throw new Error(`File type ${fileExtension} not allowed. Allowed types: ${allowedExtensions.join(', ')}`);
                }
                // Construct database file path
                const dbFilePath = `uploads/${roll_no}/leave-documents/${fileName}`;
                // Full server path
                const fullPath = path_1.default.join('/var/www/heber-erp/Upload_Student_img', dbFilePath);
                // Check if file exists on server
                try {
                    await fs_1.default.promises.access(fullPath);
                }
                catch (error) {
                    throw new Error(`File not found on server: ${fileName}`);
                }
                // Get file stats
                const stats = await fs_1.default.promises.stat(fullPath);
                return {
                    fileName: fileName,
                    filePath: dbFilePath,
                    originalName: fileName,
                    size: stats.size,
                    mimeType: getMimeType(fileExtension),
                    uploadedAt: new Date()
                };
            }));
        }
        // Create leave entry
        const leaveEntry = {
            leaveType: leaveType,
            startDate: requestedStart,
            endDate: requestedEnd,
            reason,
            supportingDocument: supportingDocumentArray.length > 0 ? supportingDocumentArray : undefined,
            status: Studentattendance_types_1.LeaveStatus.SUBMITTED,
            approvals: generateApprovalChain(leaveType),
            remarks: "",
            appliedAt: new Date(),
            updatedAt: new Date()
        };
        // Add leave to semester
        semesterObj.leaves.push(leaveEntry);
        await student.save();
        // Get the newly created leave ID
        const newLeave = semesterObj.leaves[semesterObj.leaves.length - 1];
        return res.status(200).json({
            message: "Leave applied successfully",
            code: "LEAVE_APPLIED_SUCCESS",
            leave: {
                _id: newLeave._id,
                leaveType: newLeave.leaveType,
                startDate: newLeave.startDate,
                endDate: newLeave.endDate,
                reason: newLeave.reason,
                status: newLeave.status,
                approvals: newLeave.approvals,
                supportingDocument: newLeave.supportingDocument,
                academicYear: semesterInfo.academicYear,
                semester: semesterInfo.semester,
                appliedAt: newLeave.appliedAt,
                updatedAt: newLeave.updatedAt
            }
        });
    }
    catch (error) {
        console.error("❌ Error applying leave:", error);
        if (error.message.includes("File type") || error.message.includes("File not found")) {
            return res.status(400).json({
                message: error.message,
                code: "FILE_VALIDATION_ERROR"
            });
        }
        return res.status(500).json({
            message: "Server error while applying leave",
            code: "SERVER_ERROR",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
exports.applyLeave = applyLeave;
// Helper function to get MIME type
function getMimeType(extension) {
    const mimeTypes = {
        'pdf': 'application/pdf',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'doc': 'application/msword',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    };
    return mimeTypes[extension] || 'application/octet-stream';
}
const getStudentLeaves = async (req, res) => {
    try {
        const { roll_no } = req.params;
        const { academicYear, semester, status, page = 1, limit = 20 } = req.query;
        // Build query
        const query = { roll_no };
        const student = await StudentAttendance_model_1.StudentAttendance
            .findOne(query, {
            roll_no: 1,
            name: 1,
            attendanceRecords: 1
        })
            .lean();
        if (!student) {
            return res.status(404).json({
                message: "Student not found",
                code: "STUDENT_NOT_FOUND"
            });
        }
        // Process and filter leaves
        let allLeaves = [];
        student.attendanceRecords.forEach(record => {
            // Process odd semester leaves
            if (!semester || semester === 'odd' || semester === 'sem_odd' || semester === Studentattendance_types_1.Semester.ODD) {
                const oddLeaves = record.sem_odd?.leaves?.map(leave => ({
                    ...leave,
                    academicYear: record.academicYear,
                    semester: 'sem_odd',
                    semesterName: 'Odd Semester'
                })) || [];
                allLeaves.push(...oddLeaves);
            }
            // Process even semester leaves
            if (!semester || semester === 'even' || semester === 'sem_even' || semester === Studentattendance_types_1.Semester.EVEN) {
                const evenLeaves = record.sem_even?.leaves?.map(leave => ({
                    ...leave,
                    academicYear: record.academicYear,
                    semester: 'sem_even',
                    semesterName: 'Even Semester'
                })) || [];
                allLeaves.push(...evenLeaves);
            }
        });
        // Apply filters
        let filteredLeaves = allLeaves.filter(leave => {
            let matches = true;
            if (academicYear && leave.academicYear !== academicYear) {
                matches = false;
            }
            if (status && leave.status !== status) {
                matches = false;
            }
            return matches;
        });
        // Sort by applied date (newest first)
        filteredLeaves.sort((a, b) => new Date(b.appliedAt).getTime() - new Date(a.appliedAt).getTime());
        // Pagination
        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        const startIndex = (pageNum - 1) * limitNum;
        const endIndex = pageNum * limitNum;
        const paginatedLeaves = filteredLeaves.slice(startIndex, endIndex);
        const totalPages = Math.ceil(filteredLeaves.length / limitNum);
        // Calculate statistics
        const stats = {
            total: allLeaves.length,
            approved: allLeaves.filter(l => l.status === Studentattendance_types_1.LeaveStatus.APPROVED).length,
            pending: allLeaves.filter(l => l.status === Studentattendance_types_1.LeaveStatus.PENDING || l.status === Studentattendance_types_1.LeaveStatus.SUBMITTED).length,
            rejected: allLeaves.filter(l => l.status === Studentattendance_types_1.LeaveStatus.REJECTED).length,
            cancelled: allLeaves.filter(l => l.status === Studentattendance_types_1.LeaveStatus.CANCELLED).length,
            byType: {
                [Studentattendance_types_1.LeaveType.CASUAL]: allLeaves.filter(l => l.leaveType === Studentattendance_types_1.LeaveType.CASUAL).length,
                [Studentattendance_types_1.LeaveType.MEDICAL]: allLeaves.filter(l => l.leaveType === Studentattendance_types_1.LeaveType.MEDICAL).length,
                [Studentattendance_types_1.LeaveType.ON_DUTY]: allLeaves.filter(l => l.leaveType === Studentattendance_types_1.LeaveType.ON_DUTY).length
            }
        };
        return res.status(200).json({
            roll_no: student.roll_no,
            name: student.name,
            statistics: stats,
            pagination: {
                currentPage: pageNum,
                totalPages,
                totalItems: filteredLeaves.length,
                itemsPerPage: limitNum,
                hasNextPage: endIndex < filteredLeaves.length,
                hasPreviousPage: startIndex > 0
            },
            leaves: paginatedLeaves.map(leave => ({
                _id: leave._id,
                leaveType: leave.leaveType,
                startDate: leave.startDate,
                endDate: leave.endDate,
                reason: leave.reason,
                status: leave.status,
                approvals: leave.approvals,
                supportingDocument: leave.supportingDocument,
                academicYear: leave.academicYear,
                semester: leave.semester,
                semesterName: leave.semesterName,
                appliedAt: leave.appliedAt,
                updatedAt: leave.updatedAt,
                remarks: leave.remarks
            }))
        });
    }
    catch (error) {
        console.error("❌ Error fetching leaves:", error);
        return res.status(500).json({
            message: "Server error while fetching leaves",
            code: "SERVER_ERROR",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
exports.getStudentLeaves = getStudentLeaves;
const cancelLeave = async (req, res) => {
    const session = await mongoose_1.default.startSession();
    session.startTransaction();
    try {
        const { roll_no, leaveId, remarks } = req.body;
        if (!roll_no || !leaveId) {
            await session.abortTransaction();
            return res.status(400).json({
                message: 'roll_no and leaveId are required',
                code: "MISSING_REQUIRED_FIELDS"
            });
        }
        const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no }).session(session);
        if (!student) {
            await session.abortTransaction();
            return res.status(404).json({
                message: 'Student not found',
                code: "STUDENT_NOT_FOUND"
            });
        }
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        // Find leave across all semesters
        let targetLeave = null;
        let foundSemester = null;
        let foundAcademicRecord = null;
        let leaveIndex = -1;
        for (const record of student.attendanceRecords) {
            // Check odd semester
            const oddIndex = record.sem_odd.leaves.findIndex((leave) => leave._id && leave._id.toString() === leaveId);
            if (oddIndex !== -1) {
                targetLeave = record.sem_odd.leaves[oddIndex];
                foundSemester = 'sem_odd';
                foundAcademicRecord = record;
                leaveIndex = oddIndex;
                break;
            }
            // Check even semester
            const evenIndex = record.sem_even.leaves.findIndex((leave) => leave._id && leave._id.toString() === leaveId);
            if (evenIndex !== -1) {
                targetLeave = record.sem_even.leaves[evenIndex];
                foundSemester = 'sem_even';
                foundAcademicRecord = record;
                leaveIndex = evenIndex;
                break;
            }
        }
        if (!targetLeave) {
            await session.abortTransaction();
            return res.status(404).json({
                message: 'Leave not found',
                code: "LEAVE_NOT_FOUND"
            });
        }
        // Check if leave can be cancelled
        const canCancelStatuses = [Studentattendance_types_1.LeaveStatus.SUBMITTED, Studentattendance_types_1.LeaveStatus.PENDING];
        if (!canCancelStatuses.includes(targetLeave.status)) {
            await session.abortTransaction();
            return res.status(400).json({
                message: `Cannot cancel leave with status: ${targetLeave.status}`,
                code: "INVALID_STATUS_TRANSITION",
                currentStatus: targetLeave.status,
                allowedStatuses: canCancelStatuses
            });
        }
        // Check if leave has already started
        const leaveStartDate = new Date(targetLeave.startDate);
        leaveStartDate.setHours(0, 0, 0, 0);
        if (leaveStartDate <= today) {
            await session.abortTransaction();
            return res.status(400).json({
                message: "Cannot cancel leave that has already started",
                code: "LEAVE_ALREADY_STARTED"
            });
        }
        // Update leave status
        targetLeave.status = Studentattendance_types_1.LeaveStatus.CANCELLED;
        targetLeave.updatedAt = new Date();
        if (remarks) {
            targetLeave.remarks = remarks;
        }
        // Update all approval stages to cancelled - FIXED: Use IApproval type
        targetLeave.approvals.forEach((approval) => {
            approval.status = 'rejected'; // Use 'rejected' or add 'cancelled' to IApproval['status'] if needed
            approval.updatedAt = new Date();
            if (remarks) {
                approval.remarks = `Leave cancelled by student: ${remarks}`;
            }
        });
        await student.save({ session });
        await session.commitTransaction();
        return res.status(200).json({
            message: 'Leave cancelled successfully',
            code: "LEAVE_CANCELLED",
            leaveId,
            academicYear: foundAcademicRecord?.academicYear,
            semester: foundSemester,
            updates: {
                status: Studentattendance_types_1.LeaveStatus.CANCELLED,
                remarks: remarks || 'Cancelled by student',
                updatedAt: new Date()
            }
        });
    }
    catch (error) {
        await session.abortTransaction();
        console.error('Error cancelling leave:', error);
        return res.status(500).json({
            message: 'Server error while cancelling leave',
            code: "SERVER_ERROR",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
    finally {
        session.endSession();
    }
};
exports.cancelLeave = cancelLeave;
const getLeaveStatistics = async (req, res) => {
    try {
        const { roll_no } = req.params;
        const { academicYear } = req.query;
        const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no });
        if (!student) {
            return res.status(404).json({
                message: 'Student not found',
                code: "STUDENT_NOT_FOUND"
            });
        }
        let totalLeaves = 0;
        let approvedLeaves = 0;
        let pendingLeaves = 0;
        let rejectedLeaves = 0;
        let cancelledLeaves = 0;
        const leaveTypeCounts = {
            [Studentattendance_types_1.LeaveType.CASUAL]: 0,
            [Studentattendance_types_1.LeaveType.MEDICAL]: 0,
            [Studentattendance_types_1.LeaveType.ON_DUTY]: 0
        };
        const semesterStats = {
            odd: { total: 0, approved: 0, pending: 0, rejected: 0, cancelled: 0 },
            even: { total: 0, approved: 0, pending: 0, rejected: 0, cancelled: 0 }
        };
        const academicYearStats = {};
        // Filter academic records if specific year requested
        const filteredRecords = student.attendanceRecords.filter(record => !academicYear || record.academicYear === academicYear);
        filteredRecords.forEach(record => {
            if (!academicYearStats[record.academicYear]) {
                academicYearStats[record.academicYear] = {
                    odd: { total: 0, approved: 0, pending: 0, rejected: 0, cancelled: 0 },
                    even: { total: 0, approved: 0, pending: 0, rejected: 0, cancelled: 0 },
                    total: 0
                };
            }
            // Process odd semester leaves
            record.sem_odd.leaves.forEach((leave) => {
                totalLeaves++;
                academicYearStats[record.academicYear].odd.total++;
                academicYearStats[record.academicYear].total++;
                semesterStats.odd.total++;
                switch (leave.status) {
                    case Studentattendance_types_1.LeaveStatus.APPROVED:
                        approvedLeaves++;
                        academicYearStats[record.academicYear].odd.approved++;
                        semesterStats.odd.approved++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.PENDING:
                    case Studentattendance_types_1.LeaveStatus.SUBMITTED:
                        pendingLeaves++;
                        academicYearStats[record.academicYear].odd.pending++;
                        semesterStats.odd.pending++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.REJECTED:
                        rejectedLeaves++;
                        academicYearStats[record.academicYear].odd.rejected++;
                        semesterStats.odd.rejected++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.CANCELLED:
                        cancelledLeaves++;
                        academicYearStats[record.academicYear].odd.cancelled++;
                        semesterStats.odd.cancelled++;
                        break;
                }
                // Count by leave type
                if (leave.leaveType in leaveTypeCounts) {
                    leaveTypeCounts[leave.leaveType]++;
                }
            });
            // Process even semester leaves
            record.sem_even.leaves.forEach((leave) => {
                totalLeaves++;
                academicYearStats[record.academicYear].even.total++;
                academicYearStats[record.academicYear].total++;
                semesterStats.even.total++;
                switch (leave.status) {
                    case Studentattendance_types_1.LeaveStatus.APPROVED:
                        approvedLeaves++;
                        academicYearStats[record.academicYear].even.approved++;
                        semesterStats.even.approved++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.PENDING:
                    case Studentattendance_types_1.LeaveStatus.SUBMITTED:
                        pendingLeaves++;
                        academicYearStats[record.academicYear].even.pending++;
                        semesterStats.even.pending++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.REJECTED:
                        rejectedLeaves++;
                        academicYearStats[record.academicYear].even.rejected++;
                        semesterStats.even.rejected++;
                        break;
                    case Studentattendance_types_1.LeaveStatus.CANCELLED:
                        cancelledLeaves++;
                        academicYearStats[record.academicYear].even.cancelled++;
                        semesterStats.even.cancelled++;
                        break;
                }
                // Count by leave type
                if (leave.leaveType in leaveTypeCounts) {
                    leaveTypeCounts[leave.leaveType]++;
                }
            });
        });
        // Calculate approval rates
        const approvalRate = totalLeaves > 0 ? (approvedLeaves / totalLeaves) * 100 : 0;
        const pendingRate = totalLeaves > 0 ? (pendingLeaves / totalLeaves) * 100 : 0;
        return res.status(200).json({
            roll_no: student.roll_no,
            name: student.name,
            statistics: {
                summary: {
                    totalLeaves,
                    approvedLeaves,
                    pendingLeaves,
                    rejectedLeaves,
                    cancelledLeaves,
                    approvalRate: parseFloat(approvalRate.toFixed(2)),
                    pendingRate: parseFloat(pendingRate.toFixed(2))
                },
                byType: leaveTypeCounts,
                bySemester: semesterStats,
                byAcademicYear: academicYearStats
            },
            academicYears: Object.keys(academicYearStats)
        });
    }
    catch (error) {
        console.error('Error fetching leave stats:', error);
        return res.status(500).json({
            message: 'Server error while fetching leave statistics',
            code: "SERVER_ERROR",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
exports.getLeaveStatistics = getLeaveStatistics;
// Additional helper function to check leave eligibility
const checkLeaveEligibility = async (req, res) => {
    try {
        const { roll_no, startDate, endDate, leaveType } = req.body;
        if (!roll_no || !startDate || !endDate) {
            return res.status(400).json({
                message: "roll_no, startDate, and endDate are required",
                code: "MISSING_REQUIRED_FIELDS"
            });
        }
        const student = await StudentAttendance_model_1.StudentAttendance.findOne({ roll_no });
        if (!student) {
            return res.status(404).json({
                message: "Student not found",
                code: "STUDENT_NOT_FOUND"
            });
        }
        const requestedStart = new Date(startDate);
        const requestedEnd = new Date(endDate);
        // Basic validation
        if (isNaN(requestedStart.getTime()) || isNaN(requestedEnd.getTime())) {
            return res.status(400).json({
                message: "Invalid date format",
                code: "INVALID_DATE_FORMAT"
            });
        }
        if (requestedEnd < requestedStart) {
            return res.status(400).json({
                message: "End date cannot be earlier than start date",
                code: "INVALID_DATE_RANGE"
            });
        }
        // Get semester info
        const semesterInfo = await (0, util_1.getCurrentSemester)(requestedStart);
        if (!semesterInfo) {
            return res.status(400).json({
                message: "Leave date does not fall within any academic semester",
                code: "INVALID_SEMESTER"
            });
        }
        // Check for overlapping leaves
        const academicRecord = student.attendanceRecords.find((r) => r.academicYear === semesterInfo.academicYear);
        if (!academicRecord) {
            return res.status(400).json({
                message: "No academic record found for this period",
                code: "NO_ACADEMIC_RECORD"
            });
        }
        const semesterObj = semesterInfo.semester === Studentattendance_types_1.Semester.ODD
            ? academicRecord.sem_odd
            : academicRecord.sem_even;
        const conflictingStatuses = [Studentattendance_types_1.LeaveStatus.SUBMITTED, Studentattendance_types_1.LeaveStatus.PENDING, Studentattendance_types_1.LeaveStatus.APPROVED];
        const overlappingLeaves = semesterObj.leaves.filter((existingLeave) => {
            const existingStart = new Date(existingLeave.startDate);
            const existingEnd = new Date(existingLeave.endDate);
            existingStart.setHours(0, 0, 0, 0);
            existingEnd.setHours(0, 0, 0, 0);
            requestedStart.setHours(0, 0, 0, 0);
            requestedEnd.setHours(0, 0, 0, 0);
            const dateOverlaps = requestedStart <= existingEnd && requestedEnd >= existingStart;
            const statusConflicts = conflictingStatuses.includes(existingLeave.status);
            return dateOverlaps && statusConflicts;
        });
        // Calculate leave duration
        const leaveDuration = Math.ceil((requestedEnd.getTime() - requestedStart.getTime()) / (1000 * 60 * 60 * 24)) + 1;
        // Check leave type limit if provided
        let maxDuration = 30;
        if (leaveType && LEAVE_TYPE_LIMITS[leaveType]) {
            maxDuration = LEAVE_TYPE_LIMITS[leaveType];
        }
        return res.status(200).json({
            eligible: overlappingLeaves.length === 0 && leaveDuration <= maxDuration,
            overlappingLeaves: overlappingLeaves.map(leave => ({
                leaveId: leave._id,
                leaveType: leave.leaveType,
                startDate: leave.startDate,
                endDate: leave.endDate,
                status: leave.status,
                reason: leave.reason
            })),
            duration: {
                days: leaveDuration,
                exceedsMax: leaveDuration > maxDuration,
                maxAllowed: maxDuration
            },
            semester: {
                academicYear: semesterInfo.academicYear,
                semester: semesterInfo.semester
            }
        });
    }
    catch (error) {
        console.error('Error checking leave eligibility:', error);
        return res.status(500).json({
            message: 'Server error while checking leave eligibility',
            code: "SERVER_ERROR",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
exports.checkLeaveEligibility = checkLeaveEligibility;
