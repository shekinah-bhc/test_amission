"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFile = exports.uploadMultipleFiles = exports.uploadFile = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const util_1 = require("../../services/util");
const uploadFile = async (req, res) => {
    try {
        const { roll_no, uploadFor } = req.body;
        if (!req.file) {
            return res.status(400).json({ message: "No file uploaded" });
        }
        const finalPath = `uploads/${roll_no}/${uploadFor}/${req.file.filename}`;
        return res.status(200).json({
            message: "File uploaded successfully",
            fileName: req.file.filename,
            filePath: finalPath,
        });
    }
    catch (error) {
        console.error("Upload File Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};
exports.uploadFile = uploadFile;
// ---------- UPLOAD MULTIPLE FILES ----------
const uploadMultipleFiles = async (req, res) => {
    try {
        const { roll_no, uploadFor } = req.body;
        if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
            return res.status(400).json({
                message: "No files uploaded or invalid file format"
            });
        }
        const files = req.files;
        const uploadedFiles = files.map(file => ({
            fileName: file.filename,
            // ✅ Relative path (store in DB / send to frontend)
            filePath: `uploads/${roll_no}/${uploadFor}/${file.filename}`,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            uploadedAt: new Date()
        }));
        return res.status(200).json({
            message: `${files.length} file(s) uploaded successfully`,
            count: files.length,
            files: uploadedFiles
        });
    }
    catch (error) {
        console.error("Upload Multiple Files Error:", error);
        return res.status(500).json({
            message: "Internal server error",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};
exports.uploadMultipleFiles = uploadMultipleFiles;
// ---------- DELETE FILE BY filePath ----------
const deleteFile = async (req, res) => {
    try {
        const { filePath } = req.body;
        if (!filePath) {
            return res.status(400).json({ message: "filePath is required" });
        }
        const absolutePath = path_1.default.join(util_1.__dirname, "../..", filePath);
        fs_1.default.unlink(absolutePath, (err) => {
            if (err) {
                return res.status(404).json({ message: "File not found or already deleted" });
            }
            return res.status(200).json({
                message: "File deleted successfully",
                deletedFile: filePath,
            });
        });
    }
    catch (error) {
        console.error("Delete File Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};
exports.deleteFile = deleteFile;
