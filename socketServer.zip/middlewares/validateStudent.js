"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRequest = exports.validateStudent = void 0;
const express_validator_1 = require("express-validator");
const express_validator_2 = require("express-validator");
exports.validateStudent = [
    (0, express_validator_1.body)('name').notEmpty().withMessage('Name is required'),
    (0, express_validator_1.body)('roll_no').isNumeric().withMessage('Roll number must be a number'),
    (0, express_validator_1.body)('contact.student_email').isEmail().withMessage('Valid student email required'),
];
const validateRequest = (req, res, next) => {
    const errors = (0, express_validator_2.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
    }
    next();
};
exports.validateRequest = validateRequest;
