"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApproverRole = exports.LeaveStatus = exports.LeaveType = exports.Shift = exports.Stream = exports.Gender = exports.Semester = exports.AttendanceStatus = void 0;
/* ===================== ENUMS ===================== */
var AttendanceStatus;
(function (AttendanceStatus) {
    AttendanceStatus["PRESENT"] = "present";
    AttendanceStatus["ABSENT"] = "absent";
    AttendanceStatus["LATE"] = "late";
    AttendanceStatus["ON_DUTY"] = "on_duty";
    AttendanceStatus["LEAVE"] = "leave";
    AttendanceStatus["MEDICAL_LEAVE"] = "medical_leave";
    AttendanceStatus["HALF_DAY"] = "half_day";
    AttendanceStatus["HOLIDAY"] = "holiday";
    AttendanceStatus["NOT_MARKED"] = "not_marked";
})(AttendanceStatus || (exports.AttendanceStatus = AttendanceStatus = {}));
var Semester;
(function (Semester) {
    Semester["ODD"] = "sem_odd";
    Semester["EVEN"] = "sem_even";
})(Semester || (exports.Semester = Semester = {}));
var Gender;
(function (Gender) {
    Gender["MALE"] = "Male";
    Gender["FEMALE"] = "Female";
    Gender["OTHER"] = "Other";
})(Gender || (exports.Gender = Gender = {}));
var Stream;
(function (Stream) {
    Stream["SELF_FINANCE"] = "Self-Finance";
    Stream["AIDED"] = "Aided";
})(Stream || (exports.Stream = Stream = {}));
var Shift;
(function (Shift) {
    Shift["SHIFT_1"] = "Shift-1";
    Shift["SHIFT_2"] = "Shift-2";
})(Shift || (exports.Shift = Shift = {}));
var LeaveType;
(function (LeaveType) {
    LeaveType["CASUAL"] = "casual";
    LeaveType["MEDICAL"] = "medical";
    LeaveType["ON_DUTY"] = "on_duty";
})(LeaveType || (exports.LeaveType = LeaveType = {}));
var LeaveStatus;
(function (LeaveStatus) {
    LeaveStatus["SUBMITTED"] = "submitted";
    LeaveStatus["PENDING"] = "pending";
    LeaveStatus["APPROVED"] = "approved";
    LeaveStatus["REJECTED"] = "rejected";
    LeaveStatus["CANCELLED"] = "cancelled";
})(LeaveStatus || (exports.LeaveStatus = LeaveStatus = {}));
var ApproverRole;
(function (ApproverRole) {
    ApproverRole["CLASS_INCHARGE"] = "class_incharge";
    ApproverRole["HOD"] = "hod";
    ApproverRole["VP"] = "vp";
    ApproverRole["CLUB_COORDINATOR"] = "club_coordinator";
})(ApproverRole || (exports.ApproverRole = ApproverRole = {}));
