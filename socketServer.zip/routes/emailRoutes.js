"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const emailController_1 = require("../controllers/emailController");
const router = (0, express_1.Router)();
// Email service health check
router.get('/health', emailController_1.emailController.emailHealth);
// Get templates information
router.get('/templates', emailController_1.emailController.getTemplatesInfo);
// Send general email
router.post('/send', emailController_1.emailController.sendGeneralEmail);
// Send OTP email
router.post('/send-otp', emailController_1.emailController.sendOTPEmail);
// Send welcome email
router.post('/send-welcome', emailController_1.emailController.sendWelcomeEmail);
// Send confirmation email
router.post('/send-confirmation', emailController_1.emailController.sendConfirmationEmail);
// Send password reset email
router.post('/send-password-reset', emailController_1.emailController.sendPasswordResetEmail);
// Send notification email
router.post('/send-notification', emailController_1.emailController.sendNotificationEmail);
exports.default = router;
