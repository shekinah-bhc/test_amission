"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const departmentController_1 = require("../../controllers/admin/departmentController");
const router = express_1.default.Router();
/**
 * @swagger
 * /admin/departments:
 *   get:
 *     summary: Get all departments
 *     tags: [Departments]
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 departments:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Department'
 *                 Total Department:
 *                   type: number
 *                   example: 5
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/', departmentController_1.getDepartments);
/**
 * @swagger
 * /admin/departments/{id}:
 *   get:
 *     summary: Get department by ID
 *     tags: [Departments]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/:id', departmentController_1.getDepartmentById);
/**
 * @swagger
 * /admin/departments/code/{code}:
 *   get:
 *     summary: Get department by code
 *     tags: [Departments]
 *     parameters:
 *       - name: code
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/code/:code', departmentController_1.getDepartmentByCode);
/**
 * @swagger
 * /admin/departments:
 *   post:
 *     summary: Create a new department
 *     tags: [Departments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateDepartment'
 *     responses:
 *       201:
 *         description: Department created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.post('/', departmentController_1.createDepartment);
/**
 * @swagger
 * /admin/departments/{id}:
 *   put:
 *     summary: Update department
 *     tags: [Departments]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateDepartment'
 *     responses:
 *       200:
 *         description: Department updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.put('/:id', departmentController_1.updateDepartment);
/**
 * @swagger
 * /admin/departments/{id}:
 *   delete:
 *     summary: Delete department
 *     tags: [Departments]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Department deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Department deleted successfully"
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.delete('/:id', departmentController_1.deleteDepartment);
/**
 * @swagger
 * /admin/departments/{id}/programs:
 *   get:
 *     summary: Get all programs in a department
 *     tags: [Programs]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Program'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/:id/programs', departmentController_1.getProgramsByDepartment);
/**
 * @swagger
 * /admin/departments/program/{programId}:
 *   get:
 *     summary: Get specific program by ID
 *     tags: [Programs]
 *     parameters:
 *       - name: programId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Program'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.get('/program/:programId', departmentController_1.getProgramById);
/**
 * @swagger
 * /admin/departments/{id}/programs:
 *   post:
 *     summary: Add program to department
 *     tags: [Programs]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AddProgram'
 *     responses:
 *       200:
 *         description: Program added successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       400:
 *         description: Program already exists
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.post('/:id/programs', departmentController_1.addProgram);
/**
 * @swagger
 * /admin/departments/{departmentId}/timetable/{programId}/{year}/{sectionName}:
 *   put:
 *     summary: Update timetable for a section
 *     tags: [Timetable]
 *     parameters:
 *       - name: departmentId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: programId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: year
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *       - name: sectionName
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateTimetable'
 *     responses:
 *       200:
 *         description: Timetable updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.put('/:departmentId/timetable/:programId/:year/:sectionName', departmentController_1.updateTimetable);
/**
 * @swagger
 * /admin/departments/{departmentId}/timetable/{programId}/{year}/{sectionName}/{dayOrder}/{hour}:
 *   put:
 *     summary: Update specific hour in timetable
 *     tags: [Timetable]
 *     parameters:
 *       - name: departmentId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: programId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: year
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *       - name: sectionName
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: dayOrder
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *       - name: hour
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateHour'
 *     responses:
 *       200:
 *         description: Hour updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.put('/:departmentId/timetable/:programId/:year/:sectionName/:dayOrder/:hour', departmentController_1.updateTimetableHour);
/**
 * @swagger
 * /admin/departments/{departmentId}/sections/{programId}/{year}:
 *   post:
 *     summary: Add section to a year
 *     tags: [Sections]
 *     parameters:
 *       - name: departmentId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: programId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: year
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AddSection'
 *     responses:
 *       200:
 *         description: Section added successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       400:
 *         description: Section already exists
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */
router.post('/:departmentId/sections/:programId/:year', departmentController_1.addSection);
exports.default = router;
