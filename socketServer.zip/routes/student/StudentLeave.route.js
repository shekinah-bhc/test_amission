"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const studentLeave_controller_1 = require("../../controllers/student/studentLeave.controller");
const path_1 = __importDefault(require("path"));
const router = express_1.default.Router();
// ###########################_Mark Attendanec__######################################################
// GET attendance for a class
// router.get('/class/:program_id/:batch/:section/:date', getClassAttendance);
// POST attendance by roll numbers array
router.post('/apply', studentLeave_controller_1.applyLeave);
router.get('/:roll_no', studentLeave_controller_1.getStudentLeaves);
router.put('/cancel', studentLeave_controller_1.cancelLeave);
router.get('/stats/:roll_no', studentLeave_controller_1.getLeaveStatistics);
// Serve uploaded files
router.use('/leave-documents', express_1.default.static(path_1.default.join(process.cwd(), 'uploads/leave-documents')));
exports.default = router;
