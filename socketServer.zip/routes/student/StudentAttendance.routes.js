"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const studentAttendance_controller_1 = require("../../controllers/student/studentAttendance.controller");
const router = express_1.default.Router();
router.post("/initialize/:academicYear", studentAttendance_controller_1.initializeAllStudentsAttendance);
router.post("/sync-student_data", studentAttendance_controller_1.syncStudentAttendanceData);
router.post("/sync-semester_dates/:academicYear", studentAttendance_controller_1.syncSemesterDatesFromCalendar);
// ###########################_Mark Attendanec__######################################################
// GET attendance for a class
router.get('/class/:program_id/:batch/:section/:date', studentAttendance_controller_1.getClassAttendance);
// POST attendance by roll numbers array
router.post('/mark-attendance', studentAttendance_controller_1.markAttendanceByRollNumbers);
router.get("/:roll_no", studentAttendance_controller_1.getSingleStudentFullAttendance);
// router.get("/:roll_no", getSingleStudentFullAttendance);
exports.default = router;
