"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const socket_1 = require("./services/socket");
// Create HTTP server
const socketHttpServer = http_1.default.createServer();
// Attach Socket.IO to THAT server
const io = new socket_io_1.Server(socketHttpServer, {
    cors: {
        origin: ["https://apisocket.bhc.edu.in"], // or "*" for testing
        methods: ["GET", "POST"],
        credentials: true,
    },
});
// Setup your socket handlers
(0, socket_1.setupSocket)(io);
const SOCKET_PORT = process.env.SOCKET_PORT || 3500;
socketHttpServer.listen(SOCKET_PORT, () => {
    console.log(`🔌 Socket.IO server running on port ${SOCKET_PORT}`);
});
// Graceful shutdown
process.on("SIGTERM", () => {
    console.log("SIGTERM received. Closing socket server...");
    io.close(() => {
        console.log("Socket server closed.");
        process.exit(0);
    });
});
