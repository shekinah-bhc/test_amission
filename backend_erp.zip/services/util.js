"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentSemester = exports.__dirname = void 0;
const AcademicCalendar_modal_1 = __importDefault(require("../models/admin/AcademicCalendar.modal"));
const path_1 = __importDefault(require("path"));
const Studentattendance_types_1 = require("../interfaces/Studentattendance.types");
exports.__dirname = path_1.default.dirname(__filename);
const getCurrentSemester = async (date) => {
    // Find calendar where date falls inside ODD or EVEN semester
    const calendar = await AcademicCalendar_modal_1.default.findOne({
        $or: [
            {
                'sem_odd.startDate': { $lte: date },
                'sem_odd.endDate': { $gte: date }
            },
            {
                'sem_even.startDate': { $lte: date },
                'sem_even.endDate': { $gte: date }
            }
        ]
    });
    if (!calendar)
        return null;
    // Check if date matches ODD semester
    if (date >= calendar.sem_odd.startDate && date <= calendar.sem_odd.endDate) {
        return {
            semester: Studentattendance_types_1.Semester.ODD,
            academicYear: calendar.academicYear
        };
    }
    // Check if date matches EVEN semester
    if (date >= calendar.sem_even.startDate && date <= calendar.sem_even.endDate) {
        return {
            semester: Studentattendance_types_1.Semester.EVEN,
            academicYear: calendar.academicYear
        };
    }
    return null;
};
exports.getCurrentSemester = getCurrentSemester;
