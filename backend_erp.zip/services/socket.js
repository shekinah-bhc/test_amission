"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSocket = void 0;
const ChatMessageMentorship_1 = __importDefault(require("../models/staff/ChatMessageMentorship"));
const db_1 = require("../config/db");
const onlineUsers = new Map(); // userId → socketId
const userRooms = new Map(); // userId → [roomIds]
const setupSocket = (io) => {
    io.on("connection", (socket) => {
        console.log("User connected:", socket.id);
        (0, db_1.connectDB)();
        console.log('✅ Database connected successfully');
        /**
         * USER CONNECT - Frontend sends staffId on connect
         */
        socket.on("user-connect", (userId) => {
            console.log(`User ${userId} connected with socket ${socket.id}`);
            onlineUsers.set(userId, socket.id);
            userRooms.set(userId, []);
            io.emit("online-users", Array.from(onlineUsers.keys()));
            socket.emit("connected", true);
        });
        /**
         * JOIN CHAT ROOM
         */
        socket.on("join-chat", async ({ userA, userB }) => {
            try {
                const roomId = [userA, userB].sort().join("-");
                console.log(`User ${userA} joining room ${roomId}`);
                await socket.join(roomId);
                // Track user's rooms
                const userRoomsList = userRooms.get(userA) || [];
                if (!userRoomsList.includes(roomId)) {
                    userRoomsList.push(roomId);
                    userRooms.set(userA, userRoomsList);
                }
                console.log(`User ${userA} now in rooms:`, userRoomsList);
            }
            catch (error) {
                console.error("Error joining room:", error);
            }
        });
        /**
         * LEAVE CHAT ROOM
         */
        socket.on("leave-chat", ({ userA, userB }) => {
            try {
                const roomId = [userA, userB].sort().join("-");
                console.log(`User ${userA} leaving room ${roomId}`);
                socket.leave(roomId);
                // Remove room from user's room list
                const userRoomsList = userRooms.get(userA) || [];
                const filteredRooms = userRoomsList.filter(room => room !== roomId);
                userRooms.set(userA, filteredRooms);
            }
            catch (error) {
                console.error("Error leaving room:", error);
            }
        });
        /**
         * LOAD MESSAGES
         */
        socket.on("load-messages", async ({ userA, userB }) => {
            try {
                if (!userA || !userB) {
                    return socket.emit("chat-history", []);
                }
                console.log(`📩 Loading messages for ${userA} and ${userB}`);
                const messages = await ChatMessageMentorship_1.default.find({
                    $or: [
                        { senderId: userA, receiverId: userB },
                        { senderId: userB, receiverId: userA },
                    ],
                })
                    .sort({ createdAt: 1 })
                    .limit(100)
                    .lean(); // 🚀 VERY IMPORTANT
                console.log(`✅ Found ${messages.length} messages`);
                // Send ONLY to requesting socket
                socket.emit("chat-history", messages);
            }
            catch (error) {
                console.error("❌ Error loading messages:", error);
                socket.emit("chat-history", []);
            }
        });
        /**
         * SEND MESSAGE
         */
        socket.on("send-message", async (data) => {
            try {
                const { senderId, receiverId, message } = data;
                const chat = await ChatMessageMentorship_1.default.create({
                    senderId,
                    receiverId,
                    message,
                    delivered: false,
                    read: false,
                });
                const roomId = [senderId, receiverId].sort().join("-");
                // Send message to room
                io.to(roomId).emit("receive-message", {
                    ...chat.toObject(),
                    delivered: true,
                });
                const receiverSocketId = onlineUsers.get(receiverId);
                if (receiverSocketId) {
                    // Mark delivered
                    await ChatMessageMentorship_1.default.findByIdAndUpdate(chat._id, {
                        delivered: true,
                    });
                    // 🔔 SEND NOTIFICATION TO RECEIVER
                    io.to(receiverSocketId).emit("new-notification", {
                        type: "message",
                        from: senderId,
                        message: message,
                        messageId: chat._id,
                        createdAt: chat.createdAt,
                    });
                    // Delivery status to sender
                    socket.emit("message-status", {
                        messageId: chat._id,
                        delivered: true,
                        read: false,
                    });
                }
            }
            catch (error) {
                console.error("Error sending message:", error);
                socket.emit("message-error", {
                    error: "Failed to send message",
                });
            }
        });
        /**
         * MESSAGE READ
         */
        socket.on("message-read", async (messageId) => {
            try {
                console.log(`Marking message ${messageId} as read`);
                const updatedMessage = await ChatMessageMentorship_1.default.findByIdAndUpdate(messageId, { read: true }, { new: true });
                if (updatedMessage) {
                    // Notify sender that their message was read
                    const senderSocketId = onlineUsers.get(updatedMessage.senderId);
                    if (senderSocketId) {
                        io.to(senderSocketId).emit("message-status", {
                            messageId: updatedMessage._id,
                            delivered: true,
                            read: true,
                        });
                    }
                    // Broadcast to room
                    const roomId = [updatedMessage.senderId, updatedMessage.receiverId].sort().join("-");
                    io.to(roomId).emit("message-read-update", updatedMessage._id);
                }
            }
            catch (error) {
                console.error("Error marking message as read:", error);
            }
        });
        /**
         * TYPING INDICATOR
         */
        socket.on("typing", ({ senderId, receiverId }) => {
            try {
                const roomId = [senderId, receiverId].sort().join("-");
                console.log(`${senderId} is typing in room ${roomId}`);
                // Broadcast typing to room (except sender)
                socket.to(roomId).emit("typing", { senderId, receiverId });
                // Also send direct to receiver if they're not in room
                const receiverSocketId = onlineUsers.get(receiverId);
                if (receiverSocketId && !io.sockets.sockets.get(receiverSocketId)?.rooms.has(roomId)) {
                    io.to(receiverSocketId).emit("typing", { senderId, receiverId });
                }
            }
            catch (error) {
                console.error("Error handling typing:", error);
            }
        });
        /**
         * STOP TYPING
         */
        socket.on("stop-typing", ({ senderId, receiverId }) => {
            try {
                const roomId = [senderId, receiverId].sort().join("-");
                console.log(`${senderId} stopped typing in room ${roomId}`);
                // Broadcast stop typing to room (except sender)
                socket.to(roomId).emit("stop-typing", { senderId, receiverId });
                // Also send direct to receiver if they're not in room
                const receiverSocketId = onlineUsers.get(receiverId);
                if (receiverSocketId && !io.sockets.sockets.get(receiverSocketId)?.rooms.has(roomId)) {
                    io.to(receiverSocketId).emit("stop-typing", { senderId, receiverId });
                }
            }
            catch (error) {
                console.error("Error handling stop typing:", error);
            }
        });
        /**
         * CHECK CONNECTION
         */
        socket.on("check-connection", () => {
            socket.emit("connection-status", { connected: true });
        });
        /**
         * USER DISCONNECT
         */
        socket.on("disconnect", () => {
            console.log("User disconnected:", socket.id);
            // Find and remove user from onlineUsers
            let disconnectedUserId = null;
            for (const [userId, socketId] of onlineUsers.entries()) {
                if (socketId === socket.id) {
                    disconnectedUserId = userId;
                    onlineUsers.delete(userId);
                    userRooms.delete(userId);
                    break;
                }
            }
            if (disconnectedUserId) {
                console.log(`User ${disconnectedUserId} went offline`);
                io.emit("online-users", Array.from(onlineUsers.keys()));
                io.emit("user-offline", disconnectedUserId);
            }
        });
        /**
         * USER OFFLINE (manual)
         */
        socket.on("user-offline", (userId) => {
            console.log(`User ${userId} manually went offline`);
            onlineUsers.delete(userId);
            userRooms.delete(userId);
            io.emit("online-users", Array.from(onlineUsers.keys()));
            io.emit("user-offline", userId);
        });
        /**
         * GET ONLINE USERS
         */
        socket.on("get-online-users", () => {
            socket.emit("online-users", Array.from(onlineUsers.keys()));
        });
    });
};
exports.setupSocket = setupSocket;
