"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.studentSubjectsController = void 0;
const Departments_1 = require("../../models/admin/Departments");
exports.studentSubjectsController = {
    getStudentSubjects: async (req, res) => {
        try {
            const { program_name, year, section_name } = req.body;
            // 🔹 Validation
            if (!program_name || !year || !section_name) {
                return res.status(400).json({
                    success: false,
                    message: "Missing required parameters: program_name, year, section_name",
                });
            }
            // 🔹 Find Department
            const department = await Departments_1.DepartmentModel.findOne({
                "programs.program_name": program_name,
            });
            if (!department) {
                return res.status(404).json({
                    success: false,
                    message: `Program '${program_name}' not found`,
                });
            }
            // 🔹 Find Program
            const program = department.programs.find((p) => p.program_name === program_name);
            if (!program) {
                return res.status(404).json({
                    success: false,
                    message: `Program '${program_name}' not found in department '${department.department_name}'`,
                });
            }
            // 🔹 Find Year
            const yearData = program.years.find((y) => y.year === Number(year));
            if (!yearData) {
                return res.status(404).json({
                    success: false,
                    message: `Year '${year}' not found in program '${program_name}'`,
                });
            }
            // 🔹 Find Section
            const section = yearData.sections.find((s) => s.section_name === section_name);
            if (!section) {
                return res.status(404).json({
                    success: false,
                    message: `Section '${section_name}' not found in year '${year}'`,
                });
            }
            // 🔹 Collect unique subjects
            const subjectsMap = new Map();
            section.TimeTable.forEach((day) => {
                day.hours.forEach((hour) => {
                    if (hour.paperCode?.trim()) {
                        const key = `${hour.paperCode}-${hour.paperTitle}`;
                        if (!subjectsMap.has(key)) {
                            subjectsMap.set(key, {
                                paperCode: hour.paperCode,
                                paperTitle: hour.paperTitle,
                                paperType: hour.paperType,
                                staffid: hour.staffid, // Fixed: staffid → staffid
                                staffName: hour.staffName,
                            });
                        }
                    }
                });
            });
            const subjects = Array.from(subjectsMap.values());
            // 🔹 Return response (no subjects found)
            if (subjects.length === 0) {
                return res.status(200).json({
                    success: true,
                    message: "No subjects found for the specified criteria",
                    data: [],
                });
            }
            // 🔹 Final success response
            return res.status(200).json({
                success: true,
                data: {
                    department_name: department.department_name,
                    department_code: department.department_code,
                    program_name,
                    year,
                    section_name,
                    section_shift: section.section_shift,
                    subjects,
                    totalSubjects: subjects.length,
                },
            });
        }
        catch (error) {
            console.error("Error fetching student subjects:", error);
            return res.status(500).json({
                success: false,
                message: "Failed to fetch student subjects",
                error: error.message,
            });
        }
    },
    // Get subjects with additional timetable information
    getStudentSubjectsWithSchedule: async (req, res) => {
        try {
            const { program_name, year, section_name } = req.query;
            // Validate required parameters
            if (!program_name || !year || !section_name) {
                return res.status(400).json({
                    success: false,
                    message: "Missing required parameters: program_name, year, section_name"
                });
            }
            // Find the department containing the specified program
            const department = await Departments_1.DepartmentModel.findOne({
                "programs.program_name": program_name
            });
            if (!department) {
                return res.status(404).json({
                    success: false,
                    message: "Program not found"
                });
            }
            const program = department.programs.find(p => p.program_name === program_name);
            if (!program) {
                return res.status(404).json({
                    success: false,
                    message: "Program not found"
                });
            }
            const yearData = program.years.find(y => y.year === Number(year));
            if (!yearData) {
                return res.status(404).json({
                    success: false,
                    message: `Year ${year} not found in program ${program_name}`
                });
            }
            const section = yearData.sections.find(s => s.section_name === section_name);
            if (!section) {
                return res.status(404).json({
                    success: false,
                    message: `Section ${section_name} not found in year ${year}`
                });
            }
            // Extract subjects with schedule information
            const subjectsWithSchedule = [];
            section.TimeTable.forEach(day => {
                day.hours.forEach(hour => {
                    if (hour.paperCode && hour.paperCode.trim() !== "") {
                        subjectsWithSchedule.push({
                            dayOrder: day.dayOrder,
                            hour: hour.hour,
                            paperCode: hour.paperCode,
                            paperTitle: hour.paperTitle,
                            paperType: hour.paperType,
                            staffid: hour.staffid, // Fixed: staffid → staffid
                            staffName: hour.staffName,
                        });
                    }
                });
            });
            if (subjectsWithSchedule.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: "No subjects found for the specified criteria"
                });
            }
            return res.status(200).json({
                success: true,
                data: {
                    department_name: department.department_name,
                    department_code: department.department_code,
                    program_name,
                    year,
                    section_name,
                    section_shift: section.section_shift,
                    subjects: subjectsWithSchedule,
                    totalSubjects: subjectsWithSchedule.length
                }
            });
        }
        catch (error) {
            console.error("Error fetching student subjects with schedule:", error);
            return res.status(500).json({
                success: false,
                message: "Internal server error",
                error: error.message
            });
        }
    },
    // Get unique subjects list (without duplicates)
    getUniqueStudentSubjects: async (req, res) => {
        try {
            const { program_name, year, section_name } = req.query;
            if (!program_name || !year || !section_name) {
                return res.status(400).json({
                    success: false,
                    message: "Missing required parameters: program_name, year, section_name"
                });
            }
            const department = await Departments_1.DepartmentModel.findOne({
                "programs.program_name": program_name
            });
            if (!department) {
                return res.status(404).json({
                    success: false,
                    message: "Program not found"
                });
            }
            const program = department.programs.find(p => p.program_name === program_name);
            if (!program) {
                return res.status(404).json({
                    success: false,
                    message: "Program not found"
                });
            }
            const yearData = program.years.find(y => y.year === Number(year));
            if (!yearData) {
                return res.status(404).json({
                    success: false,
                    message: `Year ${year} not found in program ${program_name}`
                });
            }
            const section = yearData.sections.find(s => s.section_name === section_name);
            if (!section) {
                return res.status(404).json({
                    success: false,
                    message: `Section ${section_name} not found in year ${year}`
                });
            }
            // Get unique subjects using Set
            const uniqueSubjects = new Set();
            const subjectsInfo = [];
            section.TimeTable.forEach(day => {
                day.hours.forEach(hour => {
                    if (hour.paperCode && hour.paperCode.trim() !== "" && !uniqueSubjects.has(hour.paperCode)) {
                        uniqueSubjects.add(hour.paperCode);
                        subjectsInfo.push({
                            paperCode: hour.paperCode,
                            paperTitle: hour.paperTitle,
                            paperType: hour.paperType,
                            staffid: hour.staffid, // Fixed: staffid → staffid
                            staffName: hour.staffName,
                        });
                    }
                });
            });
            if (subjectsInfo.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: "No subjects found for the specified criteria"
                });
            }
            return res.status(200).json({
                success: true,
                data: {
                    department_name: department.department_name,
                    department_code: department.department_code,
                    program_name,
                    year,
                    section_name,
                    section_shift: section.section_shift,
                    subjects: subjectsInfo,
                    totalSubjects: subjectsInfo.length
                }
            });
        }
        catch (error) {
            console.error("Error fetching unique student subjects:", error);
            return res.status(500).json({
                success: false,
                message: "Internal server error",
                error: error.message
            });
        }
    }
};
exports.default = exports.studentSubjectsController;
