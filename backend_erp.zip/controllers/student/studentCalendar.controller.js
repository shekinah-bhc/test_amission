"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentStudentCalendar = void 0;
const AcademicCalendar_modal_1 = __importDefault(require("../../models/admin/AcademicCalendar.modal"));
const getCurrentStudentCalendar = async (req, res) => {
    try {
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1; // January is 1
        let academicYear;
        if (currentMonth >= 6) {
            academicYear = `${currentYear}-${currentYear + 1}`;
        }
        else {
            academicYear = `${currentYear - 1}-${currentYear}`;
        }
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({
            academicYear
        });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Current academic calendar not found'
            });
        }
        const currentDate = new Date();
        let currentSemester = null;
        if (currentDate >= academicCalendar.sem_odd.startDate &&
            currentDate <= academicCalendar.sem_odd.endDate) {
            currentSemester = 'odd';
        }
        else if (currentDate >= academicCalendar.sem_even.startDate &&
            currentDate <= academicCalendar.sem_even.endDate) {
            currentSemester = 'even';
        }
        const studentCalendar = {
            academicYear: academicCalendar.academicYear,
            currentSemester,
            semesters: {
                odd: {
                    holidays: academicCalendar.sem_odd.holidays,
                    events: academicCalendar.sem_odd.events,
                    exams: {
                        internal1: academicCalendar.sem_odd.exams.internal1,
                        internal2: academicCalendar.sem_odd.exams.internal2,
                        practical: academicCalendar.sem_odd.exams.practical,
                        ese: academicCalendar.sem_odd.exams.ese
                    },
                    metadata: academicCalendar.sem_odd.metadata,
                    semesterInfo: {
                        startDate: academicCalendar.sem_odd.startDate,
                        endDate: academicCalendar.sem_odd.endDate,
                        semesterName: 'Odd Semester'
                    }
                },
                even: {
                    holidays: academicCalendar.sem_even.holidays,
                    events: academicCalendar.sem_even.events,
                    exams: {
                        internal1: academicCalendar.sem_even.exams.internal1,
                        internal2: academicCalendar.sem_even.exams.internal2,
                        practical: academicCalendar.sem_even.exams.practical,
                        ese: academicCalendar.sem_even.exams.ese
                    },
                    metadata: academicCalendar.sem_even.metadata,
                    semesterInfo: {
                        startDate: academicCalendar.sem_even.startDate,
                        endDate: academicCalendar.sem_even.endDate,
                        semesterName: 'Even Semester'
                    }
                }
            },
            combinedMetadata: {
                totalNationalHolidays: academicCalendar.sem_odd.metadata.nationalHolidays + academicCalendar.sem_even.metadata.nationalHolidays,
                totalCollegeHolidays: academicCalendar.sem_odd.metadata.collegeHolidays + academicCalendar.sem_even.metadata.collegeHolidays,
                totalEvents: {
                    sports: academicCalendar.sem_odd.metadata.sportsEvents + academicCalendar.sem_even.metadata.sportsEvents,
                    department: academicCalendar.sem_odd.metadata.departmentEvents + academicCalendar.sem_even.metadata.departmentEvents,
                    staff: academicCalendar.sem_odd.metadata.staffEvents + academicCalendar.sem_even.metadata.staffEvents,
                    student: academicCalendar.sem_odd.metadata.studentEvents + academicCalendar.sem_even.metadata.studentEvents,
                    common: academicCalendar.sem_odd.metadata.commonEvents + academicCalendar.sem_even.metadata.commonEvents
                },
                totalWorkingDays: academicCalendar.sem_odd.metadata.totalWorkingDays + academicCalendar.sem_even.metadata.totalWorkingDays,
                totalWeeks: academicCalendar.sem_odd.metadata.totalWeeks + academicCalendar.sem_even.metadata.totalWeeks
            }
        };
        return res.status(200).json({
            success: true,
            message: 'Current student calendar fetched successfully',
            data: studentCalendar
        });
    }
    catch (error) {
        console.error('Error fetching current student calendar:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
};
exports.getCurrentStudentCalendar = getCurrentStudentCalendar;
