"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mentorshipController = void 0;
const Departments_1 = require("../../models/admin/Departments");
const mentorship_modal_1 = require("../../models/staff/mentorship.modal");
const Staff_1 = require("../../models/staff/Staff");
const Student_1 = require("../../models/students/Student");
// =============== INTERNAL HELPERS ==================
async function getDepartmentMentorshipOrThrow(department_code) {
    const doc = await mentorship_modal_1.MentorshipModel.findOne({ department_code });
    if (!doc) {
        throw new Error(`Mentorship document not found for department ${department_code}`);
    }
    return doc;
}
function findStreamShift(doc, streamName, shiftName) {
    const stream = doc.streams.find((s) => s.name === streamName);
    if (!stream)
        return { stream: null, shift: null };
    const shift = stream.shifts.find((sh) => sh.name === shiftName);
    if (!shift)
        return { stream, shift: null };
    return { stream, shift };
}
// Remove student from ANYWHERE (assigned or unassigned) in a department
function removeStudentEverywhere(doc, student_id) {
    let removed = null;
    doc.streams.forEach((stream) => {
        stream.shifts.forEach((shift) => {
            // From mentors
            shift.staff_mentors.forEach((mentor) => {
                mentor.assigned_students.batches.forEach((batch) => {
                    const idx = batch.students.findIndex((s) => s.student_id === student_id);
                    if (idx !== -1) {
                        removed = batch.students[idx];
                        batch.students.splice(idx, 1);
                    }
                });
                // remove empty batches
                mentor.assigned_students.batches = mentor.assigned_students.batches.filter((b) => b.students.length > 0);
            });
            // From unassigned
            shift.unassigned_students.batches.forEach((batch) => {
                const idx = batch.students.findIndex((s) => s.student_id === student_id);
                if (idx !== -1) {
                    removed = batch.students[idx];
                    batch.students.splice(idx, 1);
                }
            });
            // remove empty batches
            shift.unassigned_students.batches = shift.unassigned_students.batches.filter((b) => b.students.length > 0);
        });
    });
    return { removed };
}
function addStudentToUnassigned(doc, streamName, shiftName, student, batch, program_code, program_type) {
    const { shift } = findStreamShift(doc, streamName, shiftName);
    if (!shift)
        throw new Error(`Shift ${shiftName} not found in stream ${streamName}`);
    let batchObj = shift.unassigned_students.batches.find((b) => b.batch === batch &&
        b.program_code === program_code &&
        b.program_type === program_type);
    if (!batchObj) {
        batchObj = {
            batch,
            program_code,
            program_type,
            students: []
        };
        shift.unassigned_students.batches.push(batchObj);
    }
    batchObj.students.push(student);
}
function addStudentToMentor(doc, streamName, shiftName, staff_id, student, batch, program_code, program_type) {
    const { shift } = findStreamShift(doc, streamName, shiftName);
    if (!shift)
        throw new Error(`Shift ${shiftName} not found in stream ${streamName}`);
    const mentor = shift.staff_mentors.find((m) => m.staff_id === staff_id);
    if (!mentor)
        throw new Error(`Staff mentor ${staff_id} not found`);
    let batchObj = mentor.assigned_students.batches.find((b) => b.batch === batch &&
        b.program_code === program_code &&
        b.program_type === program_type);
    if (!batchObj) {
        batchObj = {
            batch,
            program_code,
            program_type,
            students: []
        };
        mentor.assigned_students.batches.push(batchObj);
    }
    batchObj.students.push(student);
}
// Move all assigned students of one mentor to unassigned pool
function moveMentorStudentsToUnassigned(doc, streamName, shiftName, mentor) {
    const { shift } = findStreamShift(doc, streamName, shiftName);
    if (!shift)
        throw new Error('Shift not found while moving mentor students');
    mentor.assigned_students.batches.forEach((batch) => {
        let unBatch = shift.unassigned_students.batches.find((b) => b.batch === batch.batch &&
            b.program_code === batch.program_code &&
            b.program_type === batch.program_type);
        if (!unBatch) {
            unBatch = {
                batch: batch.batch,
                program_code: batch.program_code,
                program_type: batch.program_type,
                students: []
            };
            shift.unassigned_students.batches.push(unBatch);
        }
        unBatch.students.push(...batch.students);
    });
    mentor.assigned_students.batches = [];
}
// =============== CONTROLLER ==================
exports.mentorshipController = {
    // -----------------------------------------
    // 1. Initialize all departments
    // -----------------------------------------
    initializeAllDepartments: async (req, res) => {
        try {
            const departments = await Departments_1.DepartmentModel.find({});
            if (!departments.length) {
                return res.status(404).json({
                    success: false,
                    message: "No departments found"
                });
            }
            for (const dept of departments) {
                const staffList = await Staff_1.StaffModel.find({ department_code: dept.department_code });
                const studentList = await Student_1.Student.find({
                    "current_academic.department_code": dept.department_code
                });
                let mentorship = await mentorship_modal_1.MentorshipModel.findOne({ department_code: dept.department_code });
                // =======================
                // FIRST TIME CREATE
                // =======================
                if (!mentorship) {
                    console.log(`🆕 Creating mentorship for ${dept.department_code}`);
                    const streams = ["Aided", "Self-Finance"].map((streamName) => ({
                        name: streamName,
                        shifts: ["Shift-1", "Shift-2"].map((shiftName) => {
                            const shiftStaff = staffList.filter(s => s.stream === streamName && s.shift === shiftName);
                            const shiftStudents = studentList.filter(s => s.stream === streamName && s.shift === shiftName);
                            const staff_mentors = shiftStaff.map(st => ({
                                staff_id: st.staff_id,
                                staff_name: st.name,
                                staff_email: st.college_email ?? `${st.staff_id}@bhc.edu.in`,
                                designation: st.designation ?? "Professor",
                                max_students: 20,
                                assigned_students: { batches: [] },
                                active_status: true
                            }));
                            const unassignedMap = {};
                            shiftStudents.forEach(st => {
                                let program_type = st.current_academic?.program_type;
                                if (program_type !== 'UG' && program_type !== 'PG')
                                    program_type = 'PG';
                                const key = `${st.batch}_${program_type}_${st.current_academic?.program_code}`;
                                if (!unassignedMap[key]) {
                                    unassignedMap[key] = {
                                        batch: st.batch,
                                        program_code: st.current_academic?.program_code,
                                        program_type,
                                        students: []
                                    };
                                }
                                unassignedMap[key].students.push({
                                    student_id: st.roll_no,
                                    student_name: st.name,
                                    student_email: st.college_id ?? `${st.current_academic?.department_code}${st.roll_no}@bhc.edu.in`,
                                    assigned_at: new Date(),
                                    active_status: true,
                                    sessions: []
                                });
                            });
                            return {
                                name: shiftName,
                                staff_mentors,
                                unassigned_students: {
                                    batches: Object.values(unassignedMap)
                                }
                            };
                        })
                    }));
                    mentorship = await mentorship_modal_1.MentorshipModel.create({
                        department_name: dept.department_name,
                        department_code: dept.department_code,
                        streams,
                        active: true
                    });
                    console.log(`✔ Created mentorship for ${dept.department_code}`);
                    continue;
                }
                // =======================
                // SYNC STAFF & STUDENTS
                // =======================
                console.log(`🔄 Syncing mentorship: ${dept.department_code}`);
                for (const streamName of ["Aided", "Self-Finance"]) {
                    const stream = mentorship.streams.find((s) => s.name === streamName);
                    if (!stream)
                        continue;
                    for (const shiftName of ["Shift-1", "Shift-2"]) {
                        const shift = stream.shifts.find((sh) => sh.name === shiftName);
                        if (!shift)
                            continue;
                        // ================= STAFF SYNC =================
                        staffList
                            .filter(st => st.stream === streamName && st.shift === shiftName)
                            .forEach(st => {
                            const exists = shift.staff_mentors.some((m) => m.staff_id === st.staff_id);
                            if (!exists) {
                                console.log(`➕ New Staff Added: ${st.staff_id}`);
                                shift.staff_mentors.push({
                                    staff_id: st.staff_id,
                                    staff_name: st.name,
                                    staff_email: st.college_email ?? st.email ?? `${st.staff_id}@bhc.edu.in`,
                                    designation: st.designation ?? "Professor",
                                    max_students: 20,
                                    assigned_students: { batches: [] },
                                    active_status: true
                                });
                            }
                        });
                        // ================= STUDENT SYNC =================
                        studentList
                            .filter(st => st.stream === streamName && st.shift === shiftName)
                            .forEach(st => {
                            const studentExists = mentorship.streams.some((s) => s.shifts.some((sh) => sh.staff_mentors.some((m) => m.assigned_students.batches.some((b) => b.students.some((u) => u.student_id === st.roll_no))) ||
                                sh.unassigned_students.batches.some((b) => b.students.some((u) => u.student_id === st.roll_no))));
                            if (!studentExists) {
                                console.log(`➕ New Student Added: ${st.roll_no}`);
                                const program_code = st.current_academic?.program_code;
                                let program_type = st.current_academic?.program_type;
                                if (program_type !== 'UG' && program_type !== 'PG')
                                    program_type = 'PG';
                                let batchObj = shift.unassigned_students.batches.find((b) => b.batch === st.batch &&
                                    b.program_code === program_code &&
                                    b.program_type === program_type);
                                if (!batchObj) {
                                    batchObj = {
                                        batch: st.batch,
                                        program_code,
                                        program_type,
                                        students: []
                                    };
                                    shift.unassigned_students.batches.push(batchObj);
                                }
                                batchObj?.students.push({
                                    student_id: st.roll_no,
                                    student_name: st.name,
                                    student_email: st.college_id ?? `${st.current_academic?.department_code}${st.roll_no}@bhc.edu.in`,
                                    assigned_at: new Date(),
                                    active_status: true,
                                    sessions: []
                                });
                            }
                        });
                    }
                }
                await mentorship.save();
            }
            res.json({
                success: true,
                message: "Mentorship sync completed"
            });
        }
        catch (error) {
            console.error("Sync Error:", error);
            res.status(500).json({
                success: false,
                message: "Sync failed",
                error: error.message
            });
        }
    },
    // -----------------------------------------
    // 2. Assign student to staff
    // -----------------------------------------
    // -----------------------------------------
    // 2. Assign students to staff (all or nothing)
    // -----------------------------------------
    // -----------------------------------------
    // 2. Assign students to staff (update existing assignments)
    // -----------------------------------------
    assignStudentToStaff: async (req, res) => {
        try {
            const { department_code } = req.params;
            const { staff_id, student_ids, stream, shift } = req.body;
            // Validate input
            if (!Array.isArray(student_ids) || student_ids.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'student_ids must be a non-empty array'
                });
            }
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            // Fetch all students
            const studentDocs = await Student_1.Student.find({
                roll_no: { $in: student_ids }
            });
            if (studentDocs.length !== student_ids.length) {
                const foundIds = studentDocs.map(s => s.roll_no);
                const missingIds = student_ids.filter(id => !foundIds.includes(id));
                return res.status(404).json({
                    success: false,
                    message: `Students not found: ${missingIds.join(', ')}`
                });
            }
            const results = {
                assigned: [],
                already_assigned: [],
                moved: [],
                errors: []
            };
            // Get target mentor
            const { shift: targetShift } = findStreamShift(mentorship, stream, shift);
            if (!targetShift) {
                return res.status(404).json({
                    success: false,
                    message: `Target stream/shift not found`
                });
            }
            const targetMentor = targetShift.staff_mentors.find((m) => m.staff_id === staff_id);
            if (!targetMentor) {
                return res.status(404).json({
                    success: false,
                    message: `Staff mentor ${staff_id} not found in target stream/shift`,
                });
            }
            // Process each student
            for (const studentDoc of studentDocs) {
                try {
                    const studentId = studentDoc.roll_no;
                    // Check if student is already assigned to this mentor
                    const isAlreadyAssigned = targetMentor.assigned_students.batches.some((batch) => batch.students.some((student) => student.student_id === studentId));
                    if (isAlreadyAssigned) {
                        results.already_assigned.push(studentId);
                        continue;
                    }
                    // Check if student exists elsewhere in mentorship
                    const existingLocation = findStudentLocation(mentorship, studentId);
                    const menteeData = {
                        student_id: studentDoc.roll_no,
                        student_name: studentDoc.name,
                        student_email: studentDoc.college_id,
                        assigned_at: new Date(),
                        active_status: true,
                        sessions: existingLocation?.student.sessions || [] // Preserve existing sessions
                    };
                    const batch = studentDoc.batch;
                    const program_code = studentDoc.current_academic?.program_code;
                    const program_type = studentDoc.current_academic?.program_type;
                    // If student exists elsewhere, remove from current location first
                    if (existingLocation) {
                        removeStudentFromLocation(mentorship, existingLocation.stream, existingLocation.shift, existingLocation.mentorStaffId, studentId);
                        results.moved.push(studentId);
                    }
                    else {
                        results.assigned.push(studentId);
                    }
                    // Add to target mentor
                    addStudentToMentor(mentorship, stream, shift, staff_id, menteeData, batch, program_code, program_type);
                }
                catch (error) {
                    results.errors.push({
                        student_id: studentDoc.roll_no,
                        error: error.message
                    });
                }
            }
            await mentorship.save();
            // Build response message
            let messageParts = [];
            if (results.assigned.length > 0) {
                messageParts.push(`${results.assigned.length} new students assigned`);
            }
            if (results.moved.length > 0) {
                messageParts.push(`${results.moved.length} students moved from other mentors`);
            }
            if (results.already_assigned.length > 0) {
                messageParts.push(`${results.already_assigned.length} students already assigned`);
            }
            return res.json({
                success: true,
                message: messageParts.join(', '),
                data: results
            });
        }
        catch (err) {
            console.error('Assign error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 3. Unassign student (move to unassigned)
    // -----------------------------------------
    unassignStudent: async (req, res) => {
        try {
            const { department_code } = req.params;
            const { student_id, stream, shift, batch, program_code, program_type } = req.body;
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            const { removed } = removeStudentEverywhere(mentorship, student_id);
            if (!removed) {
                return res.status(404).json({ success: false, message: 'Student not found in mentorship' });
            }
            addStudentToUnassigned(mentorship, stream, shift, removed, batch, program_code, program_type);
            await mentorship.save();
            return res.json({ success: true, message: 'Student moved to unassigned' });
        }
        catch (err) {
            console.error('Unassign error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 4. Add new staff to mentorship
    // -----------------------------------------
    addStaff: async (req, res) => {
        try {
            const { department_code } = req.params;
            const { staff_id, stream, shift } = req.body;
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            const staff = await Staff_1.StaffModel.findOne({ staff_id });
            if (!staff) {
                return res.status(404).json({ success: false, message: 'Staff not found' });
            }
            const { shift: shiftObj } = findStreamShift(mentorship, stream, shift);
            if (!shiftObj) {
                return res
                    .status(404)
                    .json({ success: false, message: 'Target stream/shift not found' });
            }
            const existing = shiftObj.staff_mentors.find((m) => m.staff_id === staff_id);
            if (existing) {
                return res.json({ success: true, message: 'Staff already exists in mentorship' });
            }
            shiftObj.staff_mentors.push({
                staff_id: staff.staff_id,
                staff_name: staff.name,
                staff_email: staff.college_email || staff.email,
                designation: staff.designation || 'Professor',
                max_students: 20,
                assigned_students: { batches: [] },
                active_status: true
            });
            await mentorship.save();
            return res.json({ success: true, message: 'Staff added to mentorship' });
        }
        catch (err) {
            console.error('Add staff error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 5. Move staff (between stream/shift or department)
    // -----------------------------------------
    moveStaff: async (req, res) => {
        try {
            const { department_code, staff_id } = req.params;
            const { target_department_code, target_stream, target_shift } = req.body;
            const currentDept = await getDepartmentMentorshipOrThrow(department_code);
            // locate mentor + which stream/shift
            let currentStreamName = null;
            let currentShiftName = null;
            let mentorObj = null;
            currentDept.streams.forEach((s) => {
                s.shifts.forEach((sh) => {
                    const m = sh.staff_mentors.find((x) => x.staff_id === staff_id);
                    if (m) {
                        currentStreamName = s.name;
                        currentShiftName = sh.name;
                        mentorObj = m;
                    }
                });
            });
            if (!mentorObj || !currentStreamName || !currentShiftName) {
                return res
                    .status(404)
                    .json({ success: false, message: 'Staff mentor not found in mentorship' });
            }
            const existingMentorData = mentorObj.toObject ? mentorObj.toObject() : { ...mentorObj };
            // CASE 1: Department changed
            if (target_department_code && target_department_code !== department_code) {
                // Move students -> unassigned in CURRENT dept
                moveMentorStudentsToUnassigned(currentDept, currentStreamName, currentShiftName, mentorObj);
                // Remove mentor from current dept
                currentDept.streams.forEach((s) => s.shifts.forEach((sh) => {
                    sh.staff_mentors = sh.staff_mentors.filter((m) => m.staff_id !== staff_id);
                }));
                await currentDept.save();
                // Add mentor to TARGET dept (empty assigned_students)
                const targetDept = await getDepartmentMentorshipOrThrow(target_department_code);
                const { shift: tShift } = findStreamShift(targetDept, target_stream, target_shift);
                if (!tShift) {
                    return res.status(404).json({
                        success: false,
                        message: 'Target stream/shift not found in new department'
                    });
                }
                existingMentorData.assigned_students = { batches: [] };
                tShift.staff_mentors.push(existingMentorData);
                await targetDept.save();
                return res.json({
                    success: true,
                    message: 'Staff moved to new department. All students moved to unassigned in old department.'
                });
            }
            // CASE 2: Same department, only stream/shift changed
            // Remove from old shift
            currentDept.streams.forEach((s) => s.shifts.forEach((sh) => {
                sh.staff_mentors = sh.staff_mentors.filter((m) => m.staff_id !== staff_id);
            }));
            const { shift: newShift } = findStreamShift(currentDept, target_stream, target_shift);
            if (!newShift) {
                return res
                    .status(404)
                    .json({ success: false, message: 'Target stream/shift not found' });
            }
            // keep all assigned_students as is when shifting within same department
            newShift.staff_mentors.push(mentorObj);
            await currentDept.save();
            return res.json({
                success: true,
                message: 'Staff moved within department successfully (students kept)'
            });
        }
        catch (err) {
            console.error('Move staff error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 6. Delete staff (all students -> unassigned)
    // -----------------------------------------
    deleteStaff: async (req, res) => {
        try {
            const { department_code, staff_id } = req.params;
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            let found = false;
            mentorship.streams.forEach((s) => {
                s.shifts.forEach((sh) => {
                    const mentor = sh.staff_mentors.find((m) => m.staff_id === staff_id);
                    if (mentor) {
                        found = true;
                        // move students to unassigned
                        moveMentorStudentsToUnassigned(mentorship, s.name, sh.name, mentor);
                        // remove mentor
                        sh.staff_mentors = sh.staff_mentors.filter((m) => m.staff_id !== staff_id);
                    }
                });
            });
            if (!found) {
                return res
                    .status(404)
                    .json({ success: false, message: 'Staff mentor not found in mentorship' });
            }
            await mentorship.save();
            return res.json({
                success: true,
                message: 'Staff deleted. All students moved to unassigned.'
            });
        }
        catch (err) {
            console.error('Delete staff error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 7. Move student (stream/shift/department)
    // -----------------------------------------
    moveStudent: async (req, res) => {
        try {
            const { department_code, student_id } = req.params;
            const { target_department_code, target_stream, target_shift } = req.body;
            // Current dept
            const currentDept = await getDepartmentMentorshipOrThrow(department_code);
            const { removed } = removeStudentEverywhere(currentDept, Number(student_id));
            if (!removed) {
                return res
                    .status(404)
                    .json({ success: false, message: 'Student not found in mentorship' });
            }
            // If department changes, we put in target dept's unassigned
            if (target_department_code && target_department_code !== department_code) {
                await currentDept.save();
                const targetDept = await getDepartmentMentorshipOrThrow(target_department_code);
                // we assume Student document already updated to new dept and has correct batch/program_code/type
                const studentDoc = await Student_1.Student.findOne({
                    roll_no: Number(student_id)
                });
                if (!studentDoc) {
                    return res.status(404).json({
                        success: false,
                        message: 'Student document not found in DB'
                    });
                }
                const batch = studentDoc.batch;
                const program_code = studentDoc.current_academic?.program_code;
                const program_type = studentDoc.current_academic?.program_type;
                addStudentToUnassigned(targetDept, target_stream, target_shift, {
                    student_id: studentDoc.roll_no,
                    student_name: studentDoc.name,
                    student_email: studentDoc.college_id,
                    assigned_at: new Date(),
                    active_status: true,
                    sessions: removed.sessions || []
                }, batch, program_code, program_type);
                await targetDept.save();
                return res.json({
                    success: true,
                    message: 'Student moved to another department (placed in unassigned of target dept)'
                });
            }
            // Same department, just stream/shift changed
            const batch = removed.batch || removed._batch || ''; // not strongly typed in mentee
            const program_code = removed.program_code;
            const program_type = removed.program_type;
            addStudentToUnassigned(currentDept, target_stream, target_shift, removed, batch, program_code, program_type);
            await currentDept.save();
            return res.json({
                success: true,
                message: 'Student moved within department (now unassigned in target)'
            });
        }
        catch (err) {
            console.error('Move student error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 8. Create session for student by staff
    // -----------------------------------------
    createSession: async (req, res) => {
        try {
            const { department_code, staff_id, student_id } = req.params;
            const { session_date, next_session_date, details_matters, mentor_feedback, positive_traits, corrective_measures, status } = req.body;
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            let found = false;
            mentorship.streams.forEach((s) => s.shifts.forEach((sh) => sh.staff_mentors.forEach((mentor) => {
                if (mentor.staff_id === staff_id) {
                    mentor.assigned_students.batches.forEach((batch) => {
                        const student = batch.students.find((st) => st.student_id === Number(student_id));
                        if (student) {
                            found = true;
                            student.sessions.push({
                                session_date,
                                next_session_date,
                                details_matters,
                                mentor_feedback,
                                positive_traits,
                                corrective_measures,
                                status
                            });
                        }
                    });
                }
            })));
            if (!found) {
                return res.status(404).json({
                    success: false,
                    message: 'Student under this staff not found in mentorship'
                });
            }
            await mentorship.save();
            return res.json({ success: true, message: 'Session created successfully' });
        }
        catch (err) {
            console.error('Create session error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 9. Update session for student
    // -----------------------------------------
    updateSession: async (req, res) => {
        try {
            const { department_code, staff_id, student_id, session_index } = req.params;
            const updateData = req.body;
            const mentorship = await getDepartmentMentorshipOrThrow(department_code);
            let found = false;
            mentorship.streams.forEach((s) => s.shifts.forEach((sh) => sh.staff_mentors.forEach((mentor) => {
                if (mentor.staff_id === staff_id) {
                    mentor.assigned_students.batches.forEach((batch) => {
                        const student = batch.students.find((st) => st.student_id === Number(student_id));
                        if (student) {
                            const idx = Number(session_index);
                            if (student.sessions[idx]) {
                                Object.assign(student.sessions[idx], updateData);
                                found = true;
                            }
                        }
                    });
                }
            })));
            if (!found) {
                return res.status(404).json({
                    success: false,
                    message: 'Session not found for student under staff'
                });
            }
            await mentorship.save();
            return res.json({ success: true, message: 'Session updated successfully' });
        }
        catch (err) {
            console.error('Update session error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 10. Get department mentorship (for dashboard)
    // -----------------------------------------
    getDepartmentMentorship: async (req, res) => {
        try {
            const { department_code } = req.params;
            const mentorship = await mentorship_modal_1.MentorshipModel.findOne({ department_code });
            if (!mentorship) {
                return res.status(404).json({ success: false, message: 'Not found' });
            }
            res.json({ success: true, data: mentorship });
        }
        catch (err) {
            console.error('Get dept error:', err);
            res.status(500).json({ success: false, message: err.message });
        }
    },
    // -----------------------------------------
    // 10. Get All Sessions (for dashboard)
    // -----------------------------------------
    getAllSessions: async (req, res) => {
        try {
            const docs = await mentorship_modal_1.MentorshipModel.find({});
            if (!docs || docs.length === 0) {
                return res.status(404).json({ success: false, message: "No data found" });
            }
            const sessionList = [];
            docs.forEach((dept) => {
                dept.streams.forEach((stream) => {
                    stream.shifts.forEach((shift) => {
                        shift.staff_mentors.forEach((mentor) => {
                            mentor.assigned_students?.batches?.forEach((batch) => {
                                batch.students.forEach((student) => {
                                    student.sessions.forEach((session) => {
                                        sessionList.push({
                                            session_date: session.session_date,
                                            next_session_date: session.next_session_date,
                                            details_matters: session.details_matters,
                                            mentor_feedback: session.mentor_feedback,
                                            positive_traits: session.positive_traits,
                                            corrective_measures: session.corrective_measures,
                                            status: session.status,
                                            createdAt: session.createdAt,
                                            updatedAt: session.updatedAt
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
            return res.json({
                success: true,
                total_sessions: sessionList.length,
                data: sessionList
            });
        }
        catch (err) {
            console.error("Get All Sessions Error:", err);
            return res.status(500).json({ success: false, message: err.message });
        }
    },
    getDepartmentSession: async (req, res) => {
        try {
            const { department_code } = req.params;
            const docs = await mentorship_modal_1.MentorshipModel.find({ department_code });
            if (!docs || docs.length === 0) {
                return res.status(404).json({ success: false, message: "No data found" });
            }
            const sessionList = [];
            docs.forEach((dept) => {
                dept.streams.forEach((stream) => {
                    stream.shifts.forEach((shift) => {
                        shift.staff_mentors.forEach((mentor) => {
                            mentor.assigned_students?.batches?.forEach((batch) => {
                                batch.students.forEach((student) => {
                                    student.sessions.forEach((session) => {
                                        sessionList.push({
                                            mentor_id: mentor.staff_id,
                                            session_date: session.session_date,
                                            student_id: student.student_id,
                                            student_name: student.student_name,
                                            student_email: student.student_email,
                                            next_session_date: session.next_session_date,
                                            details_matters: session.details_matters,
                                            mentor_feedback: session.mentor_feedback,
                                            positive_traits: session.positive_traits,
                                            corrective_measures: session.corrective_measures,
                                            status: session.status,
                                            createdAt: session.createdAt,
                                            updatedAt: session.updatedAt
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
            return res.json({
                success: true,
                total_sessions: sessionList.length,
                data: sessionList
            });
        }
        catch (err) {
            console.error("Get All Sessions Error:", err);
            return res.status(500).json({ success: false, message: err.message });
        }
    },
    getStudentSession: async (req, res) => {
        try {
            const { roll_no } = req.params;
            const docs = await mentorship_modal_1.MentorshipModel.find({});
            if (!docs || docs.length === 0) {
                return res.status(404).json({ success: false, message: "No data found" });
            }
            let studentSessions = [];
            let mentor_data = [];
            docs.forEach((dept) => {
                dept.streams.forEach((stream) => {
                    stream.shifts.forEach((shift) => {
                        shift.staff_mentors.forEach((mentor) => {
                            mentor.assigned_students?.batches?.forEach((batch) => {
                                batch.students.forEach((student) => {
                                    if (student.student_id === Number(roll_no)) {
                                        // Always push mentor data (even if no session)
                                        if (mentor_data.findIndex(m => m.staff_id === mentor.staff_id) === -1) {
                                            mentor_data.push({
                                                staff_id: mentor.staff_id,
                                                staff_name: mentor.staff_name,
                                                staff_email: mentor.staff_email,
                                                designation: mentor.designation,
                                                department_name: dept.department_name
                                            });
                                        }
                                        // Push session data (if available)
                                        student.sessions?.forEach((session) => {
                                            studentSessions.push({
                                                session_date: session.session_date,
                                                next_session_date: session.next_session_date,
                                                details_matters: session.details_matters,
                                                mentor_feedback: session.mentor_feedback,
                                                positive_traits: session.positive_traits,
                                                corrective_measures: session.corrective_measures,
                                                status: session.status,
                                                createdAt: session.createdAt,
                                                updatedAt: session.updatedAt
                                            });
                                        });
                                    }
                                });
                            });
                        });
                    });
                });
            });
            // ------------------------
            // IF NO SESSION FOUND: return mentor details only
            // ------------------------
            if (studentSessions.length === 0) {
                return res.json({
                    success: true,
                    data: {
                        total_sessions: 0,
                        session_info: [],
                        staff_info: mentor_data, // return mentor details
                    },
                    message: "No sessions found, returning mentor details only.",
                });
            }
            // ------------------------
            // SESSIONS FOUND
            // ------------------------
            return res.json({
                success: true,
                data: {
                    total_sessions: studentSessions.length,
                    session_info: studentSessions,
                    staff_info: mentor_data,
                },
            });
        }
        catch (err) {
            console.error("Get Student Sessions Error:", err);
            return res.status(500).json({ success: false, message: err.message });
        }
    },
};
// Helper function to clean invalid staff_mentors from mentorship document
async function cleanInvalidStaffMentors(mentorship) {
    try {
        // Clean invalid staff mentors from all streams and shifts
        for (const stream of mentorship.streams) {
            for (const shift of stream.shifts) {
                if (shift.staff_mentors && shift.staff_mentors.length > 0) {
                    const validMentors = [];
                    for (const mentor of shift.staff_mentors) {
                        // Check if staff_id exists and staff is valid in database
                        if (mentor && mentor.staff_id && mentor.staff_id.trim() !== "") {
                            // Verify staff exists in database
                            const staffExists = await Staff_1.StaffModel.exists({ staff_id: mentor.staff_id });
                            if (staffExists) {
                                validMentors.push(mentor);
                            }
                            else {
                                console.log(`Removing invalid mentor: ${mentor.staff_id} - Staff not found in database`);
                            }
                        }
                        else {
                            console.log(`Removing invalid mentor with empty staff_id: ${JSON.stringify(mentor)}`);
                        }
                    }
                    shift.staff_mentors = validMentors;
                }
            }
        }
    }
    catch (error) {
        console.error("Error cleaning invalid staff mentors:", error);
        // If there's an error, do a basic cleanup without DB check
        for (const stream of mentorship.streams) {
            for (const shift of stream.shifts) {
                if (shift.staff_mentors && shift.staff_mentors.length > 0) {
                    shift.staff_mentors = shift.staff_mentors.filter((mentor) => mentor && mentor.staff_id && mentor.staff_id.trim() !== "");
                }
            }
        }
    }
}
// Helper function to parse created_at date
function parseCreatedAt(createdAt) {
    // Handle both formats: "2025-07-18 10:56:59" and ISO format
    if (createdAt.includes(' ')) {
        // Convert "YYYY-MM-DD HH:MM:SS" to ISO format
        return new Date(createdAt.replace(' ', 'T') + 'Z');
    }
    return new Date(createdAt);
}
// Helper function to update department summary
function updateDepartmentSummary(summary, deptCode, isSuccess) {
    const deptStats = summary.get(deptCode) || { success: 0, failed: 0 };
    if (isSuccess) {
        deptStats.success++;
    }
    else {
        deptStats.failed++;
    }
    summary.set(deptCode, deptStats);
}
// Helper function to update staff summary
function updateStaffSummary(summary, staffId, isSuccess, isSkipped = false) {
    const staffStats = summary.get(staffId) || { assigned: 0, failed: 0, skipped: 0 };
    if (isSkipped) {
        staffStats.skipped++;
    }
    else if (isSuccess) {
        staffStats.assigned++;
    }
    else {
        staffStats.failed++;
    }
    summary.set(staffId, staffStats);
}
// =============================================================================
// --------------------------Helper Functions-----------------------------------
// =============================================================================
// Find where a student is currently located in the mentorship
function findStudentLocation(doc, student_id) {
    for (const stream of doc.streams) {
        for (const shift of stream.shifts) {
            // Check in staff mentors
            for (const mentor of shift.staff_mentors) {
                for (const batch of mentor.assigned_students.batches) {
                    const student = batch.students.find((s) => s.student_id === student_id);
                    if (student) {
                        return {
                            stream: stream.name,
                            shift: shift.name,
                            mentorStaffId: mentor.staff_id,
                            student
                        };
                    }
                }
            }
            // Check in unassigned
            for (const batch of shift.unassigned_students.batches) {
                const student = batch.students.find((s) => s.student_id === student_id);
                if (student) {
                    return {
                        stream: stream.name,
                        shift: shift.name,
                        mentorStaffId: null, // null means unassigned
                        student
                    };
                }
            }
        }
    }
    return null;
}
// Remove student from specific location
function removeStudentFromLocation(doc, streamName, shiftName, mentorStaffId, student_id) {
    const { shift } = findStreamShift(doc, streamName, shiftName);
    if (!shift)
        return false;
    if (mentorStaffId) {
        // Remove from mentor
        const mentor = shift.staff_mentors.find((m) => m.staff_id === mentorStaffId);
        if (mentor) {
            for (const batch of mentor.assigned_students.batches) {
                const studentIndex = batch.students.findIndex((s) => s.student_id === student_id);
                if (studentIndex !== -1) {
                    batch.students.splice(studentIndex, 1);
                    // Remove empty batch
                    if (batch.students.length === 0) {
                        mentor.assigned_students.batches = mentor.assigned_students.batches.filter((b) => b.students.length > 0);
                    }
                    return true;
                }
            }
        }
    }
    else {
        // Remove from unassigned
        for (const batch of shift.unassigned_students.batches) {
            const studentIndex = batch.students.findIndex((s) => s.student_id === student_id);
            if (studentIndex !== -1) {
                batch.students.splice(studentIndex, 1);
                // Remove empty batch
                if (batch.students.length === 0) {
                    shift.unassigned_students.batches = shift.unassigned_students.batches.filter((b) => b.students.length > 0);
                }
                return true;
            }
        }
    }
    return false;
}
