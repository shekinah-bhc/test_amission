"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyStaffOtp = exports.staffLogin = void 0;
const Staff_1 = require("../../models/staff/Staff");
const emailController_1 = __importDefault(require("../emailController"));
const staffLogin = async (req, res) => {
    try {
        const { staff_id } = req.params;
        const staffData = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staffData) {
            return res.status(404).json({ message: "Staff not found" });
        }
        // Generate 6-digit OTP
        const gen_otp = Math.floor(100000 + Math.random() * 900000).toString();
        // Update OTP in DB
        await staffData.updateOne({ otpVerify: gen_otp });
        // Send OTP email
        await emailController_1.default.sendOTPEmail({
            body: {
                to: staffData.college_email,
                otp: gen_otp,
                purpose: "Heber ERP Staff Login",
                expiresIn: "5 min",
                userName: staffData.name
            }
        }, {
            status: () => ({ json: () => { } }),
            json: () => { }
        });
        // Send response
        return res.json({ success: true, message: "OTP sent to email" });
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal server error" });
    }
};
exports.staffLogin = staffLogin;
const verifyStaffOtp = async (req, res) => {
    try {
        const { staff_id, otp } = req.body;
        if (!staff_id || !otp) {
            return res.status(400).json({ message: "Staff ID and OTP required" });
        }
        const staff = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staff) {
            return res.status(404).json({ message: "Staff not found" });
        }
        // Check OTP exists
        if (!staff.otpVerify) {
            return res.status(400).json({ message: "No OTP generated or expired" });
        }
        // Validate OTP
        if (staff.otpVerify !== otp) {
            return res.status(400).json({ message: "Invalid OTP" });
        }
        // OTP is valid → remove it
        await staff.updateOne({ $unset: { otpVerify: "", otpExpiry: "" } });
        const authData = {
            _id: staff._id,
            bio_id: staff.bio_id,
            staff_id: staff.staff_id,
            alt_Staff_id: staff.alt_staffid,
            salute: staff.salute,
            name: staff.name,
            gender: staff.gender,
            college_email: staff.college_email,
            department_code: staff.department_code,
            department_name: staff.department_name,
            profile_pic: staff.profile_pic,
            role: staff.role,
            designation: staff.designation,
            shift: staff.shift,
            stream: staff.stream,
            employee_type: staff.employee_type
        };
        return res.json({ success: true, message: "OTP verified successfully", data: authData });
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Internal server error" });
    }
};
exports.verifyStaffOtp = verifyStaffOtp;
