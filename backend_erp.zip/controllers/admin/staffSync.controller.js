"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncAllStaffsTimeTable = exports.updateStaffClassAttend = void 0;
const Departments_1 = require("../../models/admin/Departments");
const mongoose_1 = __importDefault(require("mongoose"));
const Staff_1 = require("../../models/staff/Staff");
const updateStaffClassAttend = async (req, res) => {
    try {
        const { staff_id } = req.params;
        const staff = await Staff_1.StaffModel.findOne({ staff_id });
        if (!staff) {
            return res.status(404).json({ message: "Staff not found" });
        }
        staff.class_attend = [];
        const departments = await Departments_1.DepartmentModel.find();
        for (const dept of departments) {
            for (const program of dept.programs) {
                for (const yearData of program.years) {
                    for (const section of yearData.sections) {
                        for (const day of section.TimeTable) {
                            for (const hourData of day.hours) {
                                if (hourData.staffid === staff_id) {
                                    staff.class_attend.push({
                                        _id: new mongoose_1.default.Types.ObjectId(),
                                        department_name: dept.department_name,
                                        program_id: program.program_id,
                                        year: String(yearData.year),
                                        section_name: section.section_name,
                                        dayOrder: day.dayOrder,
                                        hour: hourData.hour,
                                        incharge: false,
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
        await staff.save();
        return res.json({
            message: "Staff class_attend updated successfully",
            class_attend: staff.class_attend
        });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
exports.updateStaffClassAttend = updateStaffClassAttend;
const syncAllStaffsTimeTable = async (req, res) => {
    try {
        console.log("🔄 Starting batch update for all staff class_attend...");
        const staffList = await Staff_1.StaffModel.find({}, { _id: 1, staff_id: 1 });
        if (!staffList.length) {
            return res.status(404).json({ message: "No staff found" });
        }
        console.log(`📊 Total staff in database: ${staffList.length}`);
        const staffMap = new Map();
        staffList.forEach(staff => {
            staffMap.set(staff.staff_id, {
                _id: staff._id,
                staff_id: staff.staff_id,
                class_attend: []
            });
        });
        // 3️⃣ Fetch all departments (populate only needed fields)
        const departments = await Departments_1.DepartmentModel.find();
        console.log(`📊 Total departments: ${departments.length}`);
        // 4️⃣ Build class_attend for ALL staff in one pass
        let timetableEntriesProcessed = 0;
        let staffWithTimetable = new Set();
        for (const dept of departments) {
            for (const program of dept.programs) {
                for (const yearData of program.years) {
                    for (const section of yearData.sections) {
                        for (const day of section.TimeTable) {
                            for (const hourData of day.hours) {
                                timetableEntriesProcessed++;
                                const staffId = hourData.staffid;
                                if (!staffId || !staffMap.has(staffId))
                                    continue;
                                staffWithTimetable.add(staffId);
                                const staffData = staffMap.get(staffId);
                                staffData.class_attend.push({
                                    _id: new mongoose_1.default.Types.ObjectId(),
                                    department_name: dept.department_name,
                                    program_id: program.program_id,
                                    year: String(yearData.year),
                                    section_name: section.section_name,
                                    dayOrder: day.dayOrder,
                                    hour: hourData.hour
                                });
                            }
                        }
                    }
                }
            }
        }
        console.log(`📊 Timetable entries processed: ${timetableEntriesProcessed}`);
        console.log(`📊 Staff with timetable entries: ${staffWithTimetable.size}`);
        console.log(`📊 Staff without timetable entries: ${staffList.length - staffWithTimetable.size}`);
        const bulkOps = [];
        const staffWithoutTimetable = [];
        for (const staff of staffList) {
            const staffData = staffMap.get(staff.staff_id);
            const class_attend = staffData?.class_attend || [];
            if (class_attend.length === 0) {
                staffWithoutTimetable.push(staff.staff_id);
            }
            bulkOps.push({
                updateOne: {
                    filter: { _id: staff._id },
                    update: { $set: { class_attend } }
                }
            });
        }
        console.log("🔄 Executing bulk update...");
        let bulkResult;
        if (bulkOps.length > 0) {
            bulkResult = await Staff_1.StaffModel.bulkWrite(bulkOps);
            console.log(`✅ Bulk write completed. Modified: ${bulkResult.modifiedCount}`);
        }
        if (staffWithoutTimetable.length > 0) {
            console.log(`📋 Sample staff without timetable (${staffWithoutTimetable.length} total):`);
            console.log(staffWithoutTimetable.slice(0, 10).join(', '));
            if (staffWithoutTimetable.length > 10) {
                console.log(`... and ${staffWithoutTimetable.length - 10} more`);
            }
        }
        return res.json({
            message: "All staff class_attend synchronized successfully",
            summary: {
                total_staff: staffList.length,
                staff_with_timetable: staffWithTimetable.size,
                staff_without_timetable: staffWithoutTimetable.length,
                timetable_entries_processed: timetableEntriesProcessed,
                bulk_update_results: bulkResult || { message: "No updates performed" }
            },
            staff_without_timetable_count: staffWithoutTimetable.length,
            sample_without_timetable: staffWithoutTimetable.slice(0, 10)
        });
    }
    catch (err) {
        console.error("🔥 Error in updateAllStaffClassAttend:", err);
        return res.status(500).json({
            error: err.message,
            message: "Failed to synchronize staff class attendance"
        });
    }
};
exports.syncAllStaffsTimeTable = syncAllStaffsTimeTable;
