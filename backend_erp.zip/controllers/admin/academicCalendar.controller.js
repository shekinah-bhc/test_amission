"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteAcademicCalendar = exports.deleteEvent = exports.updateEvent = exports.addEvent = exports.deleteHoliday = exports.updateHoliday = exports.addHoliday = exports.deleteExam = exports.updateExam = exports.addExam = exports.getAllAcademicCalendars = exports.getAcademicCalendar = exports.updateSemesterDates = exports.createAcademicCalendar = void 0;
const AcademicCalendar_modal_1 = __importDefault(require("../../models/admin/AcademicCalendar.modal"));
// Type guards for semester validation
const isValidSemester = (semester) => {
    return ['sem_odd', 'sem_even'].includes(semester);
};
const isValidExamType = (examType) => {
    return ['internal1', 'internal2', 'practical', 'ese'].includes(examType);
};
const createAcademicCalendar = async (req, res) => {
    try {
        const { academicYear } = req.body;
        const existingCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (existingCalendar) {
            return res.status(400).json({
                success: false,
                message: 'Academic calendar for this year already exists'
            });
        }
        const academicCalendar = new AcademicCalendar_modal_1.default({
            academicYear
        });
        await academicCalendar.save();
        res.status(201).json({
            success: true,
            message: 'Academic calendar created successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error creating academic calendar',
            error: error.message
        });
    }
};
exports.createAcademicCalendar = createAcademicCalendar;
const updateSemesterDates = async (req, res) => {
    try {
        const { academicYear, semester } = req.params;
        const { startDate, endDate } = req.body;
        if (!startDate || !endDate) {
            return res.status(400).json({
                success: false,
                message: 'Start date and end date are required'
            });
        }
        if (new Date(startDate) >= new Date(endDate)) {
            return res.status(400).json({
                success: false,
                message: 'Start date must be before end date'
            });
        }
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester. Must be sem_odd or sem_even'
            });
        }
        // Update semester dates
        academicCalendar[semester].startDate = new Date(startDate);
        academicCalendar[semester].endDate = new Date(endDate);
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Semester dates updated successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating semester dates',
            error: error.message
        });
    }
};
exports.updateSemesterDates = updateSemesterDates;
const getAcademicCalendar = async (req, res) => {
    try {
        const { academicYear } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        res.status(200).json({
            success: true,
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching academic calendar',
            error: error.message
        });
    }
};
exports.getAcademicCalendar = getAcademicCalendar;
const getAllAcademicCalendars = async (req, res) => {
    try {
        const academicCalendars = await AcademicCalendar_modal_1.default.find()
            .select('academicYear sem_odd.startDate sem_odd.endDate sem_even.startDate sem_even.endDate')
            .sort({ academicYear: -1 });
        res.status(200).json({
            success: true,
            data: academicCalendars
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching academic calendars',
            error: error.message
        });
    }
};
exports.getAllAcademicCalendars = getAllAcademicCalendars;
const addExam = async (req, res) => {
    try {
        const { academicYear, semester, examType } = req.params;
        const examData = req.body;
        // Validate required fields
        if (!examData.startDate || !examData.endDate || !examData.title) {
            return res.status(400).json({
                success: false,
                message: 'Start date, end date, and title are required for exams'
            });
        }
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester. Must be sem_odd or sem_even'
            });
        }
        if (!isValidExamType(examType)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid exam type. Must be internal1, internal2, practical, or ese'
            });
        }
        const semesterData = academicCalendar[semester];
        if (semesterData.exams[examType]) {
            return res.status(400).json({
                success: false,
                message: `${examType} exam already exists for ${semester}`
            });
        }
        // Add createdBy if not provided
        if (!examData.createdBy) {
            examData.createdBy = 'Admin';
        }
        semesterData.exams[examType] = examData;
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Exam added successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding exam',
            error: error.message
        });
    }
};
exports.addExam = addExam;
const updateExam = async (req, res) => {
    try {
        const { academicYear, semester, examType } = req.params;
        const examData = req.body;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        if (!isValidExamType(examType)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid exam type'
            });
        }
        const semesterData = academicCalendar[semester];
        if (!semesterData.exams[examType]) {
            return res.status(404).json({
                success: false,
                message: `${examType} exam not found for ${semester}`
            });
        }
        semesterData.exams[examType] = {
            ...semesterData.exams[examType]?.toObject?.(),
            ...examData
        };
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Exam updated successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating exam',
            error: error.message
        });
    }
};
exports.updateExam = updateExam;
const deleteExam = async (req, res) => {
    try {
        const { academicYear, semester, examType } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        if (!isValidExamType(examType)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid exam type'
            });
        }
        const semesterData = academicCalendar[semester];
        if (!semesterData.exams[examType]) {
            return res.status(404).json({
                success: false,
                message: `${examType} exam not found for ${semester}`
            });
        }
        semesterData.exams[examType] = null;
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Exam deleted successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting exam',
            error: error.message
        });
    }
};
exports.deleteExam = deleteExam;
const addHoliday = async (req, res) => {
    try {
        const { academicYear, semester } = req.params;
        const holidayData = req.body;
        // Validate required fields
        if (!holidayData.title || !holidayData.startDate || !holidayData.endDate || !holidayData.holidayType) {
            return res.status(400).json({
                success: false,
                message: 'Title, start date, end date, and holiday type are required for holidays'
            });
        }
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        // Add createdBy if not provided
        if (!holidayData.createdBy) {
            holidayData.createdBy = 'Admin';
        }
        academicCalendar[semester].holidays.push(holidayData);
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Holiday added successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding holiday',
            error: error.message
        });
    }
};
exports.addHoliday = addHoliday;
const updateHoliday = async (req, res) => {
    try {
        const { academicYear, semester, holidayId } = req.params;
        const holidayData = req.body;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        const holidayIndex = academicCalendar[semester].holidays.findIndex((h) => h._id.toString() === holidayId);
        if (holidayIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Holiday not found'
            });
        }
        academicCalendar[semester].holidays[holidayIndex] = {
            ...academicCalendar[semester].holidays[holidayIndex].toObject(),
            ...holidayData
        };
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Holiday updated successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating holiday',
            error: error.message
        });
    }
};
exports.updateHoliday = updateHoliday;
const deleteHoliday = async (req, res) => {
    try {
        const { academicYear, semester, holidayId } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        const holidayIndex = academicCalendar[semester].holidays.findIndex((h) => h._id.toString() === holidayId);
        if (holidayIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Holiday not found'
            });
        }
        academicCalendar[semester].holidays.splice(holidayIndex, 1);
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Holiday deleted successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting holiday',
            error: error.message
        });
    }
};
exports.deleteHoliday = deleteHoliday;
const addEvent = async (req, res) => {
    try {
        const { academicYear, semester } = req.params;
        const eventData = req.body;
        // Validate required fields
        if (!eventData.title || !eventData.startDate || !eventData.endDate || !eventData.eventType) {
            return res.status(400).json({
                success: false,
                message: 'Title, start date, end date, and event type are required for events'
            });
        }
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        // Add createdBy if not provided
        if (!eventData.createdBy) {
            eventData.createdBy = 'Admin';
        }
        academicCalendar[semester].events.push(eventData);
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Event added successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding event',
            error: error.message
        });
    }
};
exports.addEvent = addEvent;
const updateEvent = async (req, res) => {
    try {
        const { academicYear, semester, eventId } = req.params;
        const eventData = req.body;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        const eventIndex = academicCalendar[semester].events.findIndex((e) => e._id.toString() === eventId);
        if (eventIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Event not found'
            });
        }
        academicCalendar[semester].events[eventIndex] = {
            ...academicCalendar[semester].events[eventIndex].toObject(),
            ...eventData
        };
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Event updated successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating event',
            error: error.message
        });
    }
};
exports.updateEvent = updateEvent;
const deleteEvent = async (req, res) => {
    try {
        const { academicYear, semester, eventId } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOne({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        if (!isValidSemester(semester)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid semester'
            });
        }
        const eventIndex = academicCalendar[semester].events.findIndex((e) => e._id.toString() === eventId);
        if (eventIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Event not found'
            });
        }
        academicCalendar[semester].events.splice(eventIndex, 1);
        await academicCalendar.save();
        res.status(200).json({
            success: true,
            message: 'Event deleted successfully',
            data: academicCalendar
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting event',
            error: error.message
        });
    }
};
exports.deleteEvent = deleteEvent;
const deleteAcademicCalendar = async (req, res) => {
    try {
        const { academicYear } = req.params;
        const academicCalendar = await AcademicCalendar_modal_1.default.findOneAndDelete({ academicYear });
        if (!academicCalendar) {
            return res.status(404).json({
                success: false,
                message: 'Academic calendar not found'
            });
        }
        res.status(200).json({
            success: true,
            message: 'Academic calendar deleted successfully'
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error deleting academic calendar',
            error: error.message
        });
    }
};
exports.deleteAcademicCalendar = deleteAcademicCalendar;
