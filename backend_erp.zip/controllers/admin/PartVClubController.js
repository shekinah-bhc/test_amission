"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateCSVPartVStudentClub = exports.migrateCSVPartV = exports.deletePartVClub = exports.updatePartVClub = exports.getPartVClubById = exports.getAllPartVClubs = exports.createPartVClub = void 0;
const PartVClub_1 = require("../../models/students/PartVClub");
const fs_1 = __importDefault(require("fs"));
const csv_parser_1 = __importDefault(require("csv-parser"));
const Student_1 = require("../../models/students/Student");
/**
 * CREATE
 */
/**
 * CREATE Part V Club
 */
const createPartVClub = async (req, res) => {
    try {
        const { club_name, club_code, incharges } = req.body;
        // Validation
        if (!club_name || !club_code || !Array.isArray(incharges) || incharges.length === 0) {
            return res.status(400).json({
                message: "club_name, club_code and at least one incharge are required"
            });
        }
        // Validate each incharge
        for (const incharge of incharges) {
            if (!incharge.staff_id || !incharge.position_number || !incharge.staff_name) {
                return res.status(400).json({
                    message: "Each incharge must have staff_id, position_number, and staff_name"
                });
            }
        }
        // Create club
        const club = await PartVClub_1.PartVClubModel.create({
            club_name,
            club_code,
            incharges
        });
        return res.status(201).json({
            message: "Part V Club created successfully",
            data: club
        });
    }
    catch (error) {
        console.error("Create Part V Club Error:", error);
        return res.status(500).json({
            message: "Error creating club",
            error
        });
    }
};
exports.createPartVClub = createPartVClub;
/**
 * READ ALL
 */
const getAllPartVClubs = async (_req, res) => {
    try {
        const clubs = await PartVClub_1.PartVClubModel.find().sort({ createdAt: -1 });
        res.json(clubs);
    }
    catch (error) {
        res.status(500).json({ message: "Error fetching clubs", error });
    }
};
exports.getAllPartVClubs = getAllPartVClubs;
/**
 * READ ONE
 */
const getPartVClubById = async (req, res) => {
    try {
        const club = await PartVClub_1.PartVClubModel.findById(req.params.id);
        if (!club) {
            return res.status(404).json({ message: "Club not found" });
        }
        res.json(club);
    }
    catch (error) {
        res.status(500).json({ message: "Error fetching club", error });
    }
};
exports.getPartVClubById = getPartVClubById;
/**
 * UPDATE
 */
const updatePartVClub = async (req, res) => {
    try {
        const updated = await PartVClub_1.PartVClubModel.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!updated) {
            return res.status(404).json({ message: "Club not found" });
        }
        res.json({
            message: "Part V Club updated successfully",
            data: updated,
        });
    }
    catch (error) {
        res.status(500).json({ message: "Error updating club", error });
    }
};
exports.updatePartVClub = updatePartVClub;
/**
 * DELETE
 */
const deletePartVClub = async (req, res) => {
    try {
        const deleted = await PartVClub_1.PartVClubModel.findByIdAndDelete(req.params.id);
        if (!deleted) {
            return res.status(404).json({ message: "Club not found" });
        }
        res.json({ message: "Part V Club deleted successfully" });
    }
    catch (error) {
        res.status(500).json({ message: "Error deleting club", error });
    }
};
exports.deletePartVClub = deletePartVClub;
const migrateCSVPartV = async (_req, res) => {
    try {
        const clubMap = new Map();
        fs_1.default.createReadStream("./partvclub_1.csv")
            .pipe((0, csv_parser_1.default)({
            mapHeaders: ({ header }) => header.replace(/\uFEFF/g, "").trim(), // remove BOM
        }))
            .on("data", (row) => {
            const club_code = row.club_code?.trim();
            if (!club_code)
                return;
            if (!clubMap.has(club_code)) {
                clubMap.set(club_code, {
                    club_name: row.club_name.trim(),
                    club_code,
                    incharges: [],
                });
            }
            clubMap.get(club_code).incharges.push({
                staff_id: row.staff_id.trim(),
                position_number: row.position_number.trim(),
            });
        })
            .on("end", async () => {
            try {
                let updated = 0;
                let inserted = 0;
                for (const club of clubMap.values()) {
                    const result = await PartVClub_1.PartVClubModel.updateOne({ club_code: club.club_code }, {
                        $set: {
                            club_name: club.club_name,
                            incharges: club.incharges,
                        },
                    }, { upsert: true });
                    if (result.upsertedCount === 1)
                        inserted++;
                    else if (result.matchedCount === 1)
                        updated++;
                }
                return res.status(200).json({
                    message: "Part V Club CSV migration completed",
                    totalClubs: clubMap.size,
                    inserted,
                    updated,
                });
            }
            catch (err) {
                return res.status(500).json({
                    message: "Database update failed",
                    error: err.message,
                });
            }
        })
            .on("error", (err) => {
            console.error(err);
            res.status(500).json({ message: "CSV read error" });
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.migrateCSVPartV = migrateCSVPartV;
const migrateCSVPartVStudentClub = async (_req, res) => {
    try {
        const rows = [];
        fs_1.default.createReadStream("./student_registered_club.csv")
            .pipe((0, csv_parser_1.default)({
            mapHeaders: ({ header }) => header.replace(/\uFEFF/g, "").trim(), // remove BOM
        }))
            .on("data", (row) => {
            if (!row.rollno || !row.club_code)
                return;
            rows.push(row);
        })
            .on("end", async () => {
            try {
                let updated = 0;
                let skipped = 0;
                let notFound = 0;
                for (const row of rows) {
                    const rollNo = Number(row.rollno);
                    const clubCode = row.club_code.trim();
                    // 🔹 Fetch club
                    const club = await PartVClub_1.PartVClubModel.findOne({ club_code: clubCode }, { club_name: 1 });
                    if (!club) {
                        notFound++;
                        continue;
                    }
                    // 🔹 Update student part_five
                    const result = await Student_1.Student.updateOne({ roll_no: rollNo }, {
                        $set: {
                            "current_academic.part_five": club.club_name,
                        },
                    });
                    if (result.matchedCount === 1 && result.modifiedCount === 1) {
                        updated++;
                    }
                    else {
                        skipped++;
                    }
                }
                return res.status(200).json({
                    message: "Student Part-V Club migration completed",
                    total: rows.length,
                    updated,
                    skipped,
                    clubNotFound: notFound,
                });
            }
            catch (err) {
                return res.status(500).json({
                    message: "Migration failed during update",
                    error: err.message,
                });
            }
        })
            .on("error", (err) => {
            console.error("CSV error:", err);
            res.status(500).json({ message: "CSV read error" });
        });
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
};
exports.migrateCSVPartVStudentClub = migrateCSVPartVStudentClub;
