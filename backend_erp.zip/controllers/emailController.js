"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailController = void 0;
const nodemailer_1 = __importDefault(require("nodemailer"));
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const handlebars_1 = __importDefault(require("handlebars"));
const premiumTemplatePath = path_1.default.join(process.cwd(), 'dist', 'templates', 'premiumEmailTemplate.html');
// ✅ Load template asynchronously
let premiumEmailTemplate;
async function loadTemplate() {
    try {
        const templateSource = await promises_1.default.readFile(premiumTemplatePath, 'utf8');
        premiumEmailTemplate = handlebars_1.default.compile(templateSource);
        console.log('✅ Premium email template loaded successfully');
    }
    catch (error) {
        console.error('❌ Failed to load email template:', error);
        // Create a fallback template
        premiumEmailTemplate = handlebars_1.default.compile(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{{title}} - {{appName}}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; color: white; text-align: center; border-radius: 10px 10px 0 0; }
          .content { padding: 30px; background: #f8fafc; border-radius: 0 0 10px 10px; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 14px; }
          .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>{{appName}}</h1>
          <p>{{collegeName}}</p>
        </div>
        <div class="content">
          {{{body}}}
        </div>
        <div class="footer">
          <p>© {{currentYear}} {{collegeName}}. All rights reserved.</p>
          <p>{{collegeAddress}} | {{phone}} | <a href="{{website}}" style="color: #667eea;">{{website}}</a></p>
          <p>Need help? Contact <a href="mailto:{{supportEmail}}" style="color: #667eea;">{{supportEmail}}</a></p>
        </div>
      </body>
      </html>
    `);
    }
}
// Load template when module is imported
loadTemplate();
// ✅ Configure email transporter
const transporter = nodemailer_1.default.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
        user: process.env.SMTP_USER || 'bishophebercollegeweb@gmail.com',
        pass: process.env.SMTP_PASS || 'qnxcfbldushagbih',
    },
});
const appConfig = {
    appName: process.env.APP_NAME || 'Heber ERP',
    appUrl: process.env.APP_URL || 'https://bhc.edu.in',
    supportEmail: process.env.SUPPORT_EMAIL || 'support@bhc.edu.in',
    collegeName: 'Bishop Heber College',
    collegeAddress: 'Tiruchirappalli - 620017, Tamil Nadu, India',
    phone: '+91-431-277 0133',
    website: 'https://bhc.edu.in'
};
// ✅ Purpose display mapping with proper typing
const purposeDisplayMap = {
    'account verification': 'Account Verification',
    'password reset': 'Password Reset',
    'email change': 'Email Change',
    'login verification': 'Login Verification',
    'transaction confirmation': 'Transaction Confirmation'
};
// ✅ Priority configuration with proper typing
const priorityConfigMap = {
    high: { color: '#dc2626', icon: '🚨', label: 'High Priority' },
    normal: { color: '#2563eb', icon: '📢', label: 'Notification' },
    low: { color: '#059669', icon: '💡', label: 'Update' }
};
// ✅ Importance icon mapping with proper typing
const importanceIconMap = {
    high: '📌',
    normal: '📝',
    low: '📄'
};
// ✅ Category icons mapping with proper typing
const categoryIconsMap = {
    academic: '🎓',
    financial: '💳',
    administrative: '📋',
    security: '🔒',
    event: '📅',
    system: '⚙️',
    general: '📢'
};
/**
 * Utility function to render premium email template
 */
function renderPremiumEmailTemplate(title, bodyContent) {
    // Check if template is loaded, if not use fallback
    if (!premiumEmailTemplate) {
        console.warn('Template not loaded yet, using fallback');
        return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${title} - ${appConfig.appName}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; color: white; text-align: center; border-radius: 10px 10px 0 0; }
          .content { padding: 30px; background: #f8fafc; border-radius: 0 0 10px 10px; }
          .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${appConfig.appName}</h1>
          <p>${appConfig.collegeName}</p>
        </div>
        <div class="content">
          <h2>${title}</h2>
          ${bodyContent}
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} ${appConfig.collegeName}. All rights reserved.</p>
          <p>${appConfig.collegeAddress} | ${appConfig.phone} | <a href="${appConfig.website}">${appConfig.website}</a></p>
          <p>Need help? Contact <a href="mailto:${appConfig.supportEmail}">${appConfig.supportEmail}</a></p>
        </div>
      </body>
      </html>
    `;
    }
    return premiumEmailTemplate({
        title,
        appName: appConfig.appName,
        appUrl: appConfig.appUrl,
        supportEmail: appConfig.supportEmail,
        collegeName: appConfig.collegeName,
        collegeAddress: appConfig.collegeAddress,
        currentYear: new Date().getFullYear(),
        body: bodyContent,
    });
}
exports.emailController = {
    /**
     * @desc Send premium welcome email
     */
    async sendWelcomeEmail(req, res) {
        try {
            const { to, name, loginUrl = `${appConfig.appUrl}/login`, dashboardUrl = `${appConfig.appUrl}/dashboard`, studentId = '', department = '' } = req.body;
            if (!to || !name) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, name'
                });
            }
            const studentInfo = studentId ? `
        <div style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); padding: 20px; border-radius: 12px; margin: 20px 0; text-align: center;">
          <strong>Student ID:</strong> ${studentId}${department ? ` | <strong>Department:</strong> ${department}` : ''}
        </div>
      ` : '';
            const htmlBody = renderPremiumEmailTemplate('Welcome to Heber ERP!', `
        <h2 class="greeting">Welcome to ${appConfig.appName}, ${name}! 🎉</h2>
        
        <p class="message">
          We're absolutely delighted to welcome you to <strong>${appConfig.appName}</strong> 
          at <strong>${appConfig.collegeName}</strong>. Your account has been successfully 
          created and you're now part of our innovative digital learning ecosystem.
        </p>
        
        ${studentInfo}
        
        <div class="message-highlight">
          <strong>🚀 Ready to Get Started?</strong><br>
          Your journey towards academic excellence begins here. Explore our comprehensive 
          platform designed to streamline your educational experience.
        </div>
        
        <div class="feature-grid">
          <div class="feature-item">
            <div class="feature-icon">📊</div>
            <div class="feature-title">Smart Dashboard</div>
            <div class="feature-description">Personalized overview of your academic progress and updates</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">📚</div>
            <div class="feature-title">Course Management</div>
            <div class="feature-description">Access courses, materials, and assignments seamlessly</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">📅</div>
            <div class="feature-title">Academic Calendar</div>
            <div class="feature-description">Stay updated with important dates and deadlines</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">💼</div>
            <div class="feature-title">Resource Center</div>
            <div class="feature-description">Library resources, research materials, and more</div>
          </div>
        </div>
        
        <div style="text-align: center; margin: 40px 0;">
          <a href="${loginUrl}" class="action-button" style="margin-right: 15px;">
            🚀 Launch Your Account
          </a>
          <a href="${dashboardUrl}" class="action-button" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
            📋 Explore Dashboard
          </a>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">💡 Pro Tips for Success</div>
            <div class="alert-message">
              • Complete your student profile with accurate information<br>
              • Set up notification preferences in account settings<br>
              • Download our mobile app for on-the-go access<br>
              • Bookmark the student handbook for quick reference<br>
              • Connect with your faculty advisor early in the semester
            </div>
          </div>
        </div>
        
        <p class="message">
          <strong>Need assistance?</strong> Our dedicated support team is here to ensure your success. 
          Contact us at <a href="mailto:${appConfig.supportEmail}" style="color: #667eea; text-decoration: none;">${appConfig.supportEmail}</a> 
          or visit our comprehensive help center.
        </p>
        
        <div class="divider"></div>
        
        <p class="message" style="text-align: center; font-style: italic; color: #6b7280;">
          "Education is the most powerful weapon which you can use to change the world."<br>
          <strong>- Nelson Mandela</strong>
        </p>
        
        <p class="message" style="text-align: center;">
          Once again, welcome to ${appConfig.collegeName}! We're excited to embark on 
          this educational journey with you and support your academic achievements.
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Welcome Team" <${process.env.SMTP_USER}>`,
                to,
                subject: `🎓 Welcome to ${appConfig.appName}, ${name}! Your Academic Journey Begins`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium welcome email sent successfully',
                data: { to, name, studentId, department }
            });
        }
        catch (error) {
            console.error('Error sending premium welcome email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send welcome email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium OTP verification email
     */
    async sendOTPEmail(req, res) {
        try {
            const { to, otp, purpose = 'account verification', expiresIn = '10 minutes', userName = 'there' } = req.body;
            if (!to || !otp) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, otp'
                });
            }
            // ✅ Fixed: Use type-safe access to purposeDisplayMap
            const purposeDisplay = purposeDisplayMap[purpose] || purpose;
            const htmlBody = renderPremiumEmailTemplate('Secure Verification Code', `
        <h2 class="greeting">Hello ${userName}! 👋</h2>
        
        <p class="message">
          You've requested a secure verification code for <strong>${purposeDisplay}</strong>. 
          This one-time password ensures the security of your account and information.
        </p>
        
        <div class="otp-container">
          <div class="otp-label">Your Secure Verification Code</div>
          <div class="otp-code">${otp}</div>
          <div class="otp-instructions">Enter this code to complete your ${purposeDisplay} process</div>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">🔒 Important Security Information</div>
            <div class="alert-message">
              <strong>This verification code expires in ${expiresIn}.</strong><br><br>
              For your protection, please remember:<br>
              • Never share this code with anyone<br>
              • Our team will never ask for your OTP<br>
              • This code can only be used once<br>
              • If unauthorized, contact support immediately
            </div>
          </div>
        </div>
        
        <p class="message" style="text-align: center;">
          If you didn't request this verification or need assistance,<br>
          please contact our security team at 
          <a href="mailto:${appConfig.supportEmail}" style="color: #667eea; text-decoration: none;">${appConfig.supportEmail}</a>
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Security" <${process.env.SMTP_USER}>`,
                to,
                subject: `🔐 Your Verification Code: ${otp} - ${appConfig.appName}`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium OTP email sent successfully',
                data: { to, purpose: purposeDisplay, expiresIn }
            });
        }
        catch (error) {
            console.error('Error sending premium OTP email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send OTP email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium confirmation email
     */
    async sendConfirmationEmail(req, res) {
        try {
            const { to, action, link, userName = 'User', expiresIn = '24 hours', instructions = 'Click the button below to confirm your action.', details = '' } = req.body;
            if (!to || !action || !link) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, action, link'
                });
            }
            const htmlBody = renderPremiumEmailTemplate('Action Confirmation Required', `
        <h2 class="greeting">Confirm Your ${action}, ${userName}!</h2>
        
        <p class="message">
          ${instructions}
        </p>
        
        ${details ? `
        <div style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); padding: 25px; border-radius: 12px; margin: 25px 0;">
          <h3 style="color: #166534; margin-bottom: 15px;">📋 Action Details</h3>
          <div style="color: #166534; line-height: 1.6;">${details}</div>
        </div>
        ` : ''}
        
        <div style="text-align: center; margin: 40px 0;">
          <a href="${link}" class="action-button">
            ✅ Confirm ${action}
          </a>
        </div>
        
        <div style="background: #f8fafc; padding: 25px; border-radius: 12px; margin: 30px 0; text-align: center;">
          <p style="margin: 0; color: #4b5563; font-size: 0.95rem;">
            <strong>🔗 Alternative Method</strong><br>
            Can't click the button? Copy and paste this link in your browser:<br>
            <a href="${link}" style="color: #667eea; word-break: break-all; text-decoration: none; font-family: 'Courier New', monospace;">${link}</a>
          </p>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">⏰ Important Information</div>
            <div class="alert-message">
              This confirmation link will expire in <strong>${expiresIn}</strong>. 
              For your security, please do not share this link with anyone. 
              If you didn't initiate this ${action.toLowerCase()}, please ignore this email 
              and contact our support team immediately.
            </div>
          </div>
        </div>
        
        <p class="message" style="text-align: center;">
          If you have any questions or need assistance, please don't hesitate to 
          contact our support team at <a href="mailto:${appConfig.supportEmail}" style="color: #667eea; text-decoration: none;">${appConfig.supportEmail}</a>.
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Notifications" <${process.env.SMTP_USER}>`,
                to,
                subject: `✅ Confirm Your ${action} - ${appConfig.appName}`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium confirmation email sent successfully',
                data: { to, action, expiresIn }
            });
        }
        catch (error) {
            console.error('Error sending premium confirmation email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send confirmation email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium password reset email
     */
    async sendPasswordResetEmail(req, res) {
        try {
            const { to, resetLink, userName = 'User', expiresIn = '1 hour' } = req.body;
            if (!to || !resetLink) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, resetLink'
                });
            }
            const htmlBody = renderPremiumEmailTemplate('Password Reset Request', `
        <h2 class="greeting">Password Reset Request, ${userName}</h2>
        
        <p class="message">
          We received a request to reset your password for your <strong>${appConfig.appName}</strong> account. 
          Click the button below to create a new secure password:
        </p>
        
        <div style="text-align: center; margin: 40px 0;">
          <a href="${resetLink}" class="action-button" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
            🔑 Reset Your Password
          </a>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">🔒 Security Notice</div>
            <div class="alert-message">
              <strong>This reset link expires in ${expiresIn}.</strong><br><br>
              If you didn't request this password reset, please ignore this email. 
              Your account remains secure. For additional protection, we recommend:
              <ul style="margin: 10px 0; padding-left: 20px;">
                <li>Using a strong, unique password with special characters</li>
                <li>Enabling two-factor authentication</li>
                <li>Regularly updating your password every 90 days</li>
                <li>Using a password manager for better security</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div style="background: #fef2f2; padding: 25px; border-radius: 12px; margin: 25px 0;">
          <h3 style="color: #dc2626; margin-bottom: 15px;">🚨 Security Tips</h3>
          <ul style="color: #dc2626; line-height: 1.6;">
            <li>Never share your password with anyone</li>
            <li>Avoid using the same password across multiple sites</li>
            <li>Log out from shared computers immediately</li>
            <li>Regularly monitor your account activity</li>
          </ul>
        </div>
        
        <p class="message">
          <strong>Need help?</strong> Contact our security team at 
          <a href="mailto:${appConfig.supportEmail}" style="color: #667eea; text-decoration: none;">${appConfig.supportEmail}</a> 
          if you have any questions about your account security.
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Security" <${process.env.SMTP_USER}>`,
                to,
                subject: '🔐 Reset Your Password - Action Required',
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium password reset email sent successfully',
                data: { to, expiresIn }
            });
        }
        catch (error) {
            console.error('Error sending premium password reset email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send password reset email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium notification email
     */
    async sendNotificationEmail(req, res) {
        try {
            const { to, subject, notificationType = 'general', message, priority = 'normal', actionLink, actionText = 'View Details', category = 'General' } = req.body;
            if (!to || !subject || !message) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, subject, message'
                });
            }
            // ✅ Fixed: Use type-safe access to priorityConfigMap
            const priorityConfig = priorityConfigMap[priority] || priorityConfigMap.normal;
            // ✅ Fixed: Use type-safe access to categoryIconsMap
            const categoryIcon = categoryIconsMap[category] || '📢';
            const htmlBody = renderPremiumEmailTemplate(subject, `
        <div style="display: flex; align-items: center; margin-bottom: 25px; padding: 20px; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border-radius: 16px;">
          <div style="width: 8px; height: 60px; background: ${priorityConfig.color}; border-radius: 4px; margin-right: 20px;"></div>
          <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <span style="font-size: 1.5rem;">${categoryIcon}</span>
              <h2 class="greeting" style="margin: 0; font-size: 1.5rem;">${priorityConfig.icon} ${subject}</h2>
            </div>
            <div style="color: #6b7280; font-size: 0.9rem; font-weight: 500;">
              ${priorityConfig.label} • ${category} • ${new Date().toLocaleDateString()}
            </div>
          </div>
        </div>
        
        <div style="background: #ffffff; padding: 30px; border-radius: 16px; margin: 25px 0; border: 1px solid #e5e7eb;">
          <div class="message" style="font-size: 1.1rem; line-height: 1.8;">${message}</div>
        </div>
        
        ${actionLink ? `
        <div style="text-align: center; margin: 35px 0;">
          <a href="${actionLink}" class="action-button" style="background: linear-gradient(135deg, ${priorityConfig.color} 0%, ${priorityConfig.color}99 100%);">
            ${actionText}
          </a>
        </div>
        ` : ''}
        
        <div class="divider"></div>
        
        <div style="background: #f8fafc; padding: 25px; border-radius: 12px; margin: 25px 0;">
          <h3 style="color: #374151; margin-bottom: 15px;">ℹ️ About This Notification</h3>
          <p style="color: #6b7280; margin: 0; line-height: 1.6;">
            This is an automated notification from ${appConfig.appName}. 
            Please do not reply to this email. To manage your notification preferences, 
            visit your account settings in the application.
          </p>
        </div>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Notifications" <${process.env.SMTP_USER}>`,
                to: Array.isArray(to) ? to : [to],
                subject: `${priorityConfig.icon} ${subject} - ${appConfig.appName}`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium notification email sent successfully',
                data: { to, subject, notificationType, priority, category }
            });
        }
        catch (error) {
            console.error('Error sending premium notification email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send notification email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium general purpose email
     */
    async sendGeneralEmail(req, res) {
        try {
            const { to, subject, message, greeting = 'Hello', closing = 'Best regards', attachments = [], importance = 'normal' } = req.body;
            if (!to || !subject || !message) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, subject, message'
                });
            }
            // ✅ Fixed: Use type-safe access to importanceIconMap
            const importanceIcon = importanceIconMap[importance] || importanceIconMap.normal;
            const htmlBody = renderPremiumEmailTemplate(subject, `
        <h2 class="greeting">${greeting},</h2>
        
        <div style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); padding: 25px; border-radius: 12px; margin: 25px 0;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
            <span style="font-size: 1.25rem;">${importanceIcon}</span>
            <h3 style="color: #374151; margin: 0;">Message Contents</h3>
          </div>
          <div class="message-content" style="color: #4b5563; line-height: 1.8;">
            ${message}
          </div>
        </div>
        
        ${attachments && attachments.length > 0 ? `
        <div style="background: #fff7ed; padding: 20px; border-radius: 12px; margin: 25px 0;">
          <h4 style="color: #ea580c; margin-bottom: 15px;">📎 Attachments Included</h4>
          <ul style="color: #ea580c; line-height: 1.6;">
            ${attachments.map((attachment) => `<li>${attachment}</li>`).join('')}
          </ul>
        </div>
        ` : ''}
        
        <div class="divider"></div>
        
        <div style="text-align: center; margin: 30px 0;">
          <p class="closing" style="color: #374151; font-size: 1.1rem;">
            ${closing},<br>
            <strong style="color: #667eea;">The ${appConfig.appName} Team</strong><br>
            <span style="color: #6b7280; font-size: 0.95rem;">${appConfig.collegeName}</span>
          </p>
        </div>
        
        <div style="background: #f0fdf4; padding: 20px; border-radius: 12px; margin: 25px 0; text-align: center;">
          <p style="margin: 0; color: #166534; font-size: 0.9rem;">
            💬 <strong>Need to respond?</strong> Please reply to this email or contact us at 
            <a href="mailto:${appConfig.supportEmail}" style="color: #166534; text-decoration: none;">${appConfig.supportEmail}</a>
          </p>
        </div>
      `);
            const mailOptions = {
                from: `"${appConfig.appName}" <${process.env.SMTP_USER}>`,
                to: Array.isArray(to) ? to : [to],
                subject: `${importanceIcon} ${subject} - ${appConfig.appName}`,
                html: htmlBody,
            };
            await transporter.sendMail(mailOptions);
            res.json({
                success: true,
                message: 'Premium general email sent successfully',
                data: { to, subject, importance, attachments: attachments?.length || 0 }
            });
        }
        catch (error) {
            console.error('Error sending premium general email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send email',
                details: error.message
            });
        }
    },
    /**
     * @desc Send premium academic notification email
     */
    async sendAcademicEmail(req, res) {
        try {
            const { to, subject, message, courseCode = '', courseName = '', instructor = '', deadline = '', attachment = '' } = req.body;
            if (!to || !subject || !message) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required fields: to, subject, message'
                });
            }
            const courseInfo = courseCode ? `
        <div style="background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%); padding: 25px; border-radius: 12px; margin: 25px 0;">
          <h3 style="color: #0369a1; margin-bottom: 15px;">🎓 Course Information</h3>
          <div style="color: #0369a1; line-height: 1.8;">
            <strong>Course:</strong> ${courseCode} - ${courseName}<br>
            ${instructor ? `<strong>Instructor:</strong> ${instructor}<br>` : ''}
            ${deadline ? `<strong>Deadline:</strong> ${deadline}<br>` : ''}
            ${attachment ? `<strong>Attachment:</strong> ${attachment}` : ''}
          </div>
        </div>
      ` : '';
            const htmlBody = renderPremiumEmailTemplate(subject, `
        <h2 class="greeting">Academic Update 📚</h2>
        
        <p class="message">
          ${message}
        </p>
        
        ${courseInfo}
        
        <div style="text-align: center; margin: 35px 0;">
          <a href="${appConfig.appUrl}/academic" class="action-button" style="background: linear-gradient(135deg, #0369a1 0%, #0c4a6e 100%);">
            📖 View Academic Portal
          </a>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">💡 Academic Reminder</div>
            <div class="alert-message">
              • Regularly check your academic dashboard for updates<br>
              • Maintain communication with your instructors<br>
              • Keep track of assignment deadlines and exam schedules<br>
              • Utilize library and learning resources available
            </div>
          </div>
        </div>
        
        <p class="message" style="text-align: center;">
          For academic inquiries, please contact your department coordinator<br>
          or visit the academic affairs office.
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Academic Office" <${process.env.SMTP_USER}>`,
                to: Array.isArray(to) ? to : [to],
                subject: `📚 ${subject} - ${appConfig.appName}`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium academic email sent successfully',
                data: { to, subject, courseCode, courseName }
            });
        }
        catch (error) {
            console.error('Error sending premium academic email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send academic email',
                details: error.message
            });
        }
    },
    /**
     * @desc Check email service health
     */
    async emailHealth(_req, res) {
        try {
            await transporter.verify();
            res.status(200).json({
                status: 'healthy',
                message: 'Premium email service is operational',
                service: 'SMTP',
                timestamp: new Date().toISOString(),
                appName: appConfig.appName,
                features: ['welcome', 'otp', 'confirmation', 'password-reset', 'notification', 'general', 'academic']
            });
        }
        catch (error) {
            console.error('Email service health check failed:', error);
            res.status(500).json({
                status: 'unhealthy',
                error: 'Email service connection failed',
                details: error.message,
                timestamp: new Date().toISOString()
            });
        }
    },
    /**
     * @desc Get email templates info
     */
    async getTemplatesInfo(_req, res) {
        try {
            const templates = {
                availableTemplates: [
                    { name: 'welcome', description: 'Welcome new users to the platform' },
                    { name: 'otp', description: 'Send verification codes for security' },
                    { name: 'confirmation', description: 'Confirm user actions and changes' },
                    { name: 'password-reset', description: 'Handle password reset requests' },
                    { name: 'notification', description: 'Send various types of notifications' },
                    { name: 'general', description: 'General purpose communication' },
                    { name: 'academic', description: 'Academic-specific communications' }
                ],
                features: {
                    premiumDesign: true,
                    responsive: true,
                    customizable: true,
                    securityFeatures: true,
                    animations: true,
                    accessibility: true
                },
                appConfig: {
                    appName: appConfig.appName,
                    appUrl: appConfig.appUrl,
                    supportEmail: appConfig.supportEmail,
                    collegeName: appConfig.collegeName
                },
                version: '2.0.0',
                lastUpdated: new Date().toISOString()
            };
            res.json({
                success: true,
                data: templates
            });
        }
        catch (error) {
            console.error('Error getting templates info:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to get templates information',
                details: error.message
            });
        }
    },
    /**
     * @desc Send test email
     */
    async sendTestEmail(req, res) {
        try {
            const { to = process.env.SMTP_USER } = req.body;
            if (!to) {
                return res.status(400).json({
                    success: false,
                    error: 'Missing required field: to'
                });
            }
            const htmlBody = renderPremiumEmailTemplate('Test Email - Premium Template', `
        <h2 class="greeting">Test Email Successful! 🎉</h2>
        
        <p class="message">
          This is a test email from <strong>${appConfig.appName}</strong> to verify that 
          our premium email system is working correctly.
        </p>
        
        <div class="feature-grid">
          <div class="feature-item">
            <div class="feature-icon">✅</div>
            <div class="feature-title">Email Service</div>
            <div class="feature-description">SMTP configuration is working properly</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">🎨</div>
            <div class="feature-title">Premium Design</div>
            <div class="feature-description">Template rendering successfully</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">📱</div>
            <div class="feature-title">Responsive Layout</div>
            <div class="feature-description">Optimized for all devices</div>
          </div>
          
          <div class="feature-item">
            <div class="feature-icon">⚡</div>
            <div class="feature-title">Fast Delivery</div>
            <div class="feature-description">Quick email processing</div>
          </div>
        </div>
        
        <div style="text-align: center; margin: 40px 0;">
          <div class="action-button" style="background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%); cursor: default;">
            🚀 Test Completed Successfully
          </div>
        </div>
        
        <div class="alert-box">
          <div class="alert-content">
            <div class="alert-title">📊 System Information</div>
            <div class="alert-message">
              • Server Time: ${new Date().toLocaleString()}<br>
              • App Version: 2.0.0<br>
              • Template: Premium Design<br>
              • Status: Operational
            </div>
          </div>
        </div>
        
        <p class="message" style="text-align: center;">
          If you received this email, your email configuration is working perfectly!<br>
          All premium email features are available and ready to use.
        </p>
      `);
            await transporter.sendMail({
                from: `"${appConfig.appName} Testing" <${process.env.SMTP_USER}>`,
                to,
                subject: `✅ Test Email - ${appConfig.appName} Premium System`,
                html: htmlBody,
            });
            res.json({
                success: true,
                message: 'Premium test email sent successfully',
                data: {
                    to,
                    timestamp: new Date().toISOString(),
                    features: ['premium-design', 'responsive', 'animations', 'security']
                }
            });
        }
        catch (error) {
            console.error('Error sending test email:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to send test email',
                details: error.message
            });
        }
    },
    /**
     * @desc Reload email template
     */
    async reloadTemplate(_req, res) {
        try {
            await loadTemplate();
            res.json({
                success: true,
                message: 'Email template reloaded successfully'
            });
        }
        catch (error) {
            console.error('Error reloading template:', error);
            res.status(500).json({
                success: false,
                error: 'Failed to reload template',
                details: error.message
            });
        }
    }
};
exports.default = exports.emailController;
