"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const courseRoutes_1 = __importDefault(require("./routes/admin/courseRoutes"));
const staff_routes_1 = __importDefault(require("./routes/staff/staff.routes"));
// REMOVED: import fileUpload from "express-fileupload"; // THIS WAS CONFLICTING WITH MULTER
const programsRoutes_1 = __importDefault(require("./routes/admin/programsRoutes"));
const timtableRoutes_1 = __importDefault(require("./routes/admin/timtableRoutes"));
const departmentRoutes_1 = __importDefault(require("./routes/admin/departmentRoutes"));
const partvRoutes_1 = __importDefault(require("./routes/admin/partvRoutes"));
const academicCalendar_routes_1 = __importDefault(require("./routes/admin/academicCalendar.routes"));
const StudentAttendance_routes_1 = __importDefault(require("./routes/student/StudentAttendance.routes"));
const mentorship_routes_1 = __importDefault(require("./routes/staff/mentorship.routes"));
const subjectsRoutes_1 = __importDefault(require("./routes/student/subjectsRoutes"));
const examsRoutes_1 = __importDefault(require("./routes/student/examsRoutes"));
const studentRoutes_1 = __importDefault(require("./routes/student/studentRoutes"));
const StudentLeave_route_1 = __importDefault(require("./routes/student/StudentLeave.route"));
const upload_routes_1 = __importDefault(require("./routes/upload.routes"));
const strictAccessControl_1 = require("./middlewares/strictAccessControl");
const swagger_1 = require("./swagger");
const path_1 = __importDefault(require("path"));
// import fileUpload from 'express-fileupload';
const db_1 = require("./config/db");
const app = (0, express_1.default)();
(0, db_1.connectDB)();
(0, swagger_1.setupSwagger)(app);
app.use((0, cors_1.default)({
    origin: true,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    credentials: true
}));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// app.use(fileUpload());
// Serve static files from uploads directory
//app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));
app.use("/uploads", express_1.default.static(path_1.default.join(__dirname, "../uploads")));
app.use(strictAccessControl_1.strictAccessControl);
/**
 * @swagger
 * /health:
 *   get:
 *     summary: Health check
 *     tags: [common]
 *     responses:
 *       200:
 *         description: API is running
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                 timestamp:
 *                   type: string
 */
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString()
    });
});
app.get('/', (_req, res) => {
    res.json({
        service: "Heber ERP API",
        status: "operational",
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || "1.0.0",
        endpoints: {
            docs: "/api-docs",
            health: "/health",
        }
    });
});
app.use('/file', upload_routes_1.default);
app.use('/students', studentRoutes_1.default);
app.use('/students/subjects', subjectsRoutes_1.default);
app.use('/students/exams', examsRoutes_1.default);
app.use('/students/attendance', StudentAttendance_routes_1.default);
app.use('/students/leave', StudentLeave_route_1.default);
// --------------------------------------------------
app.use('/staff/mentorship', mentorship_routes_1.default);
app.use('/staff', staff_routes_1.default);
// -------------------------------------------------
app.use('/admin/course_master', courseRoutes_1.default);
app.use('/admin/programs', programsRoutes_1.default);
app.use('/admin/departments', departmentRoutes_1.default);
app.use('/admin/timetable', timtableRoutes_1.default);
app.use('/admin/part-v-club', partvRoutes_1.default);
app.use('/academic_calendar', academicCalendar_routes_1.default);
app.use((err, req, res, _next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, message: err.message || 'Server Error' });
});
app.listen(5000, () => {
    console.log("🚀 Server running on 5000");
});
exports.default = app;
