"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sql = void 0;
exports.getPool = getPool;
// db.ts
const mssql_1 = __importDefault(require("mssql"));
exports.sql = mssql_1.default;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
let pool = null;
const config = {
    user: process.env.DB_USER ?? "sa",
    password: process.env.DB_PASS ?? "Bhc@2k25",
    server: process.env.DB_SERVER ?? "10.10.0.248",
    port: Number(process.env.DB_PORT ?? 2025),
    database: process.env.DB_NAME ?? "essl",
    options: {
        encrypt: true, // provided in your PHP config
        trustServerCertificate: true, // disable strict cert check
    },
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000,
    },
};
async function getPool() {
    if (pool && pool.connected)
        return pool;
    pool = await mssql_1.default.connect(config);
    return pool;
}
