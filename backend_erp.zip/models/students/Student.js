"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Student = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const SubjectSchema = new mongoose_1.default.Schema({
    paper_code: String,
    ese: {
        ese_total: Number,
        credit: Number,
        grade: String,
        grade_point: Number,
    },
    cia: {
        Int_1: Number,
        Int_2: Number,
        seminar: Number,
        records: Number,
        innovative: Number,
        MCQ: Number,
        library: Number,
        attendance: Number,
        cia_total: Number,
    },
}, { _id: false });
const SemesterSchema = new mongoose_1.default.Schema({
    subjects: [SubjectSchema],
}, { _id: false });
const PreviousAcademicSchema = new mongoose_1.default.Schema({
    qualification: String,
    institution: String,
    board: String,
    year_of_passing: Number,
    percentage: Number,
    marksheet: String,
    schooling_type: String,
    study_medium: String,
    umis: String,
    emis: String,
    achievement: [String],
    schooling_address: {
        address_type: String,
        city: String,
        state: String,
        pincode: String,
        country: String,
    },
}, { _id: false });
const FamilyMemberSchema = new mongoose_1.default.Schema({
    name: String,
    occupation: String,
    mobile_no: String,
    email: String,
    income: Number,
}, { _id: false });
const FamilySchema = new mongoose_1.default.Schema({
    ex_service: Boolean,
    ex_grade: String,
    father: FamilyMemberSchema,
    mother: FamilyMemberSchema,
    guardian: {
        name: String,
        relationship: String,
        mobile_no: Number,
        email: String,
    },
}, { _id: false });
const AddressDetailSchema = new mongoose_1.default.Schema({
    address_line1: String,
    address_line2: String,
    city: String,
    state: String,
    pincode: String,
    country: String,
}, { _id: false });
const AddressSchema = new mongoose_1.default.Schema({
    communication: AddressDetailSchema,
    permanent: AddressDetailSchema,
}, { _id: false });
const HostelSchema = new mongoose_1.default.Schema({
    room_number: String,
    hostel_code: String,
    is_active: Boolean,
    fees: Number,
    block: String,
}, { _id: false });
const TransportSchema = new mongoose_1.default.Schema({
    route_number: String,
    stop_name: String,
    is_active: Boolean,
    fees_status: String,
    fees: Number,
}, { _id: false });
const DisciplinaryRecordSchema = new mongoose_1.default.Schema({
    description: String,
    date: Date,
    action_taken: String,
}, { _id: false });
const StudentSchema = new mongoose_1.default.Schema({
    name: { type: String, required: true },
    roll_no: { type: Number, required: true, unique: true },
    application_no: { type: Number, required: true, unique: true },
    college_id: { type: String, default: null },
    stream: { type: String, enum: ["Aided", "Self-Finance", null], default: null },
    shift: { type: String, enum: ["Shift-1", "Shift-2", null], default: null },
    admission_number: { type: Number, default: null },
    admission_date: { type: Date, default: null },
    batch: { type: String, default: null },
    photo: String,
    personal_info: {
        dob: { type: Date, default: null },
        gender: { type: String, enum: ["Male", "Female", "Other", null], default: null },
        blood_group: String,
        nationality: String,
        religion: String,
        community: String,
        caste: String,
        denom: String,
        denom_group: String,
        diocese: String,
        aadhar: String,
        passport_number: String,
        epic_voter_no: String,
        first_graduation: Boolean,
        physically_challenged: Boolean,
        disability_type: String,
        disability_percent: String,
        mother_tongue: String,
        family: FamilySchema,
    },
    contact: {
        student_email: String,
        mobile_no: Number,
        alternate_mobile_no: Number,
        address: AddressSchema,
    },
    academic_info: [PreviousAcademicSchema],
    current_academic: {
        program_type: {
            type: String,
            enum: ["UG", "PG", "M_Phil", "PHD", "Diploma", "Certificate", null],
            default: null,
        },
        program_name: { type: String, default: null },
        program_code: { type: String, default: null },
        department_name: { type: String, default: null },
        department_code: { type: String, default: null },
        section: String,
        part_one: String,
        part_five: String,
        umis: String,
        semesters: [SemesterSchema],
        extra_curricular: [String],
    },
    hostel: HostelSchema,
    transport: TransportSchema,
    disciplinary: [DisciplinaryRecordSchema],
    remarks: String,
    change_date: Date,
    registration_date: Date,
    left_date: Date,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
    updatedBy: String,
    status: {
        type: String,
        enum: ["Active", "Inactive", "Alumni", "Discontinued"],
        default: "Active",
    },
});
exports.Student = mongoose_1.default.model("Students", StudentSchema, "students");
