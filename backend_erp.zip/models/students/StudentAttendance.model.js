"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StudentAttendance = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const Studentattendance_types_1 = require("../../interfaces/Studentattendance.types");
/* ========== SUB-SCHEMAS ========== */
/* Hourly Attendance */
const HourlyAttendanceSchema = new mongoose_1.Schema({
    hour: { type: String, required: true },
    status: { type: String, enum: Object.values(Studentattendance_types_1.AttendanceStatus), required: true },
    staffId: { type: String },
    updatedAt: { type: Date, required: true }
}, { _id: false });
/* Leave Approval */
const ApprovalSchema = new mongoose_1.Schema({
    approver: {
        type: String,
        enum: Object.values(Studentattendance_types_1.ApproverRole), // This should be uppercase
        required: true
    },
    status: { type: String, enum: ["approved", "rejected", "pending"], required: true },
    approvedBy: { type: String, },
    documentVerified: { type: Boolean, required: true },
    remarks: { type: String },
    updatedAt: { type: Date, required: true }
}, { _id: false });
/* Leave */
const LeaveSchema = new mongoose_1.Schema({
    leaveType: { type: String, enum: Object.values(Studentattendance_types_1.LeaveType), required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    reason: { type: String, required: true },
    remarks: { type: String, default: null },
    supportingDocument: [
        {
            fileName: { type: String, required: true },
            filePath: { type: String, required: true },
            originalName: { type: String },
            mimeType: { type: String },
            size: { type: Number }
        }
    ],
    status: { type: String, enum: Object.values(Studentattendance_types_1.LeaveStatus), required: true },
    approvals: { type: [ApprovalSchema], required: true },
    appliedAt: { type: Date, required: true },
    updatedAt: { type: Date, required: true },
});
/* Daily Attendance */
const DailyAttendanceSchema = new mongoose_1.Schema({
    date: { type: Date, required: true },
    dayOrder: { type: Number, required: true },
    attendanceType: { type: String, enum: ["hourly", "daily"], required: true },
    status: { type: String, enum: Object.values(Studentattendance_types_1.AttendanceStatus), required: true },
    hours: { type: [HourlyAttendanceSchema], default: [] },
    remarks: { type: String },
    leaveId: { type: mongoose_1.Schema.Types.ObjectId },
    updatedBy: { type: String },
    updatedAt: { type: Date, required: true }
});
/* Summary */
const SummarySchema = new mongoose_1.Schema({
    totalWorkingDays: Number,
    presentDays: Number,
    absentDays: Number,
    lateDays: Number,
    onDutyDays: Number,
    leaveDays: Number,
    medicalLeaveDays: Number,
    halfDays: Number,
    holidayDays: Number,
    attendancePercentage: Number,
    casualLeaves: Number,
    medicalLeaves: Number,
    odLeaves: Number,
    lastUpdated: { type: Date, required: true }
}, { _id: false });
/* Semester Attendance */
const SemesterAttendanceSchema = new mongoose_1.Schema({
    semesterType: { type: String, enum: Object.values(Studentattendance_types_1.Semester), required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    attendance: {
        type: [
            {
                type: mongoose_1.Schema.Types.Mixed,
                required: true
            }
        ],
        default: []
    },
    leaves: { type: [LeaveSchema], default: [] },
    summary: { type: SummarySchema, required: true }
});
/* Academic Year Attendance */
const AcademicYearAttendanceSchema = new mongoose_1.Schema({
    academicYear: { type: String, required: true },
    sem_odd: { type: SemesterAttendanceSchema, required: true },
    sem_even: { type: SemesterAttendanceSchema, required: true }
});
/* Registered Club */
const RegistredClubSchema = new mongoose_1.Schema({
    club_name: { type: String, required: true }
}, { _id: false });
/* ========== MAIN STUDENT SCHEMA ========== */
const StudentAttendanceSchema = new mongoose_1.Schema({
    roll_no: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    gender: { type: String, enum: Object.values(Studentattendance_types_1.Gender), required: true },
    department_code: { type: String, required: true },
    department_name: { type: String, required: true },
    program_id: { type: String, required: true },
    program_name: { type: String, required: true },
    section: { type: String, required: true },
    batch: { type: String, required: true },
    shift: { type: String, enum: Object.values(Studentattendance_types_1.Shift), required: true },
    stream: { type: String, enum: Object.values(Studentattendance_types_1.Stream), required: true },
    part_five: { type: [String], default: [] },
    registredClubs: { type: [RegistredClubSchema], default: [] },
    attendanceRecords: { type: [AcademicYearAttendanceSchema], default: [] },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });
/* ========== EXPORT MODEL ========== */
exports.StudentAttendance = mongoose_1.default.model("StudentAttendance", StudentAttendanceSchema, "student_attendance");
