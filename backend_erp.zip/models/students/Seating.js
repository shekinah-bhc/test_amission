"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const seatAllocationSchema = new mongoose_1.default.Schema({
    _id: {
        type: mongoose_1.default.Schema.Types.ObjectId,
        required: true
    },
    Session: {
        type: String,
        required: true,
        enum: ['Session - FN', 'Session - AN']
    },
    Seat_No: {
        type: String,
        required: true
    },
    Roll_No: {
        type: String,
        required: true,
        unique: true
    },
    Block: {
        type: String,
        required: true
    },
    Department: {
        type: String,
        required: true
    },
    Section: {
        type: String,
        default: 'NILL'
    },
    Date: {
        type: String,
        required: true
    }
}, {
    timestamps: true,
    collection: 'student_seating'
});
const SeatAllocation = mongoose_1.default.model('student_seating', seatAllocationSchema);
exports.default = SeatAllocation;
