"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AcademicCalendar = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const examSchema = new mongoose_1.Schema({
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    remarks: {
        type: String,
        trim: true
    },
    createdBy: {
        type: String,
        trim: true
    }
}, { _id: false });
const examsSchema = new mongoose_1.Schema({
    internal1: {
        type: examSchema,
        default: null
    },
    internal2: {
        type: examSchema,
        default: null
    },
    practical: {
        type: examSchema,
        default: null
    },
    ese: {
        type: examSchema,
        default: null
    }
}, { _id: false });
const holidaySchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    remarks: {
        type: String,
        trim: true
    },
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    holidayType: {
        type: String,
        required: true,
        enum: ['National', 'College']
    },
    createdBy: {
        type: String,
        trim: true
    }
});
const eventSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    remarks: {
        type: String,
        trim: true
    },
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    eventType: {
        type: String,
        required: true,
        enum: ['Sports', 'Department', 'Staff', 'Student', 'Common Events']
    },
    createdBy: {
        type: String,
        trim: true
    }
});
const semesterMetadataSchema = new mongoose_1.Schema({
    nationalHolidays: {
        type: Number,
        default: 0
    },
    collegeHolidays: {
        type: Number,
        default: 0
    },
    sportsEvents: {
        type: Number,
        default: 0
    },
    departmentEvents: {
        type: Number,
        default: 0
    },
    staffEvents: {
        type: Number,
        default: 0
    },
    studentEvents: {
        type: Number,
        default: 0
    },
    commonEvents: {
        type: Number,
        default: 0
    },
    totalWorkingDays: {
        type: Number,
        default: 0
    },
    totalWeeks: {
        type: Number,
        default: 0
    }
}, { _id: false });
const semesterSchema = new mongoose_1.Schema({
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    exams: {
        type: examsSchema,
        required: true,
        default: () => ({
            internal1: null,
            internal2: null,
            practical: null,
            ese: null
        })
    },
    holidays: [holidaySchema],
    events: [eventSchema],
    metadata: {
        type: semesterMetadataSchema,
        default: () => ({
            nationalHolidays: 0,
            collegeHolidays: 0,
            sportsEvents: 0,
            departmentEvents: 0,
            staffEvents: 0,
            studentEvents: 0,
            commonEvents: 0,
            totalWorkingDays: 0,
            totalWeeks: 0
        })
    }
}, { _id: false });
const academicCalendarSchema = new mongoose_1.Schema({
    academicYear: {
        type: String,
        required: true,
        unique: true,
        match: [/^\d{4}-\d{4}$/, 'Academic year must be in format YYYY-YYYY']
    },
    sem_odd: {
        type: semesterSchema,
        required: true,
        default: () => ({
            startDate: new Date(),
            endDate: new Date(),
            exams: {
                internal1: null,
                internal2: null,
                practical: null,
                ese: null
            },
            holidays: [],
            events: [],
            metadata: {
                nationalHolidays: 0,
                collegeHolidays: 0,
                sportsEvents: 0,
                departmentEvents: 0,
                staffEvents: 0,
                studentEvents: 0,
                commonEvents: 0,
                totalWorkingDays: 0,
                totalWeeks: 0
            }
        })
    },
    sem_even: {
        type: semesterSchema,
        required: true,
        default: () => ({
            startDate: new Date(),
            endDate: new Date(),
            exams: {
                internal1: null,
                internal2: null,
                practical: null,
                ese: null
            },
            holidays: [],
            events: [],
            metadata: {
                nationalHolidays: 0,
                collegeHolidays: 0,
                sportsEvents: 0,
                departmentEvents: 0,
                staffEvents: 0,
                studentEvents: 0,
                commonEvents: 0,
                totalWorkingDays: 0,
                totalWeeks: 0
            }
        })
    }
}, {
    timestamps: true
});
academicCalendarSchema.pre('save', function (next) {
    this.sem_odd.metadata.nationalHolidays = this.sem_odd.holidays.filter((h) => h.holidayType === 'National').length;
    this.sem_odd.metadata.collegeHolidays = this.sem_odd.holidays.filter((h) => h.holidayType === 'College').length;
    this.sem_odd.metadata.sportsEvents = this.sem_odd.events.filter((e) => e.eventType === 'Sports').length;
    this.sem_odd.metadata.departmentEvents = this.sem_odd.events.filter((e) => e.eventType === 'Department').length;
    this.sem_odd.metadata.staffEvents = this.sem_odd.events.filter((e) => e.eventType === 'Staff').length;
    this.sem_odd.metadata.studentEvents = this.sem_odd.events.filter((e) => e.eventType === 'Student').length;
    this.sem_odd.metadata.commonEvents = this.sem_odd.events.filter((e) => e.eventType === 'Common Events').length;
    this.sem_even.metadata.nationalHolidays = this.sem_even.holidays.filter((h) => h.holidayType === 'National').length;
    this.sem_even.metadata.collegeHolidays = this.sem_even.holidays.filter((h) => h.holidayType === 'College').length;
    this.sem_even.metadata.sportsEvents = this.sem_even.events.filter((e) => e.eventType === 'Sports').length;
    this.sem_even.metadata.departmentEvents = this.sem_even.events.filter((e) => e.eventType === 'Department').length;
    this.sem_even.metadata.staffEvents = this.sem_even.events.filter((e) => e.eventType === 'Staff').length;
    this.sem_even.metadata.studentEvents = this.sem_even.events.filter((e) => e.eventType === 'Student').length;
    this.sem_even.metadata.commonEvents = this.sem_even.events.filter((e) => e.eventType === 'Common Events').length;
    // Calculate working days and weeks for sem_odd
    if (this.sem_odd.startDate && this.sem_odd.endDate) {
        const { workingDays, weeks } = calculateWorkingDaysAndWeeks(this.sem_odd.startDate, this.sem_odd.endDate, this.sem_odd.holidays, this.sem_odd.exams);
        this.sem_odd.metadata.totalWorkingDays = workingDays;
        this.sem_odd.metadata.totalWeeks = weeks;
    }
    // Calculate working days and weeks for sem_even
    if (this.sem_even.startDate && this.sem_even.endDate) {
        const { workingDays, weeks } = calculateWorkingDaysAndWeeks(this.sem_even.startDate, this.sem_even.endDate, this.sem_even.holidays, this.sem_even.exams);
        this.sem_even.metadata.totalWorkingDays = workingDays;
        this.sem_even.metadata.totalWeeks = weeks;
    }
    next();
});
function calculateWorkingDaysAndWeeks(startDate, endDate, holidays, exams) {
    let workingDays = 0;
    const currentDate = new Date(startDate);
    const end = new Date(endDate);
    // Get all non-working dates (holidays + exam days)
    const nonWorkingDates = new Set();
    // Add holiday dates
    holidays.forEach(holiday => {
        const holidayStart = new Date(holiday.startDate);
        const holidayEnd = new Date(holiday.endDate);
        let currentHolidayDate = new Date(holidayStart);
        while (currentHolidayDate <= holidayEnd) {
            nonWorkingDates.add(currentHolidayDate.toDateString());
            currentHolidayDate.setDate(currentHolidayDate.getDate() + 1);
        }
    });
    // Add exam dates (internal1, internal2, ese)
    const examTypes = ['internal1', 'internal2', 'ese'];
    examTypes.forEach(examType => {
        if (exams[examType] && exams[examType].startDate && exams[examType].endDate) {
            const examStart = new Date(exams[examType].startDate);
            const examEnd = new Date(exams[examType].endDate);
            let currentExamDate = new Date(examStart);
            while (currentExamDate <= examEnd) {
                nonWorkingDates.add(currentExamDate.toDateString());
                currentExamDate.setDate(currentExamDate.getDate() + 1);
            }
        }
    });
    // Calculate working days (excluding Sundays and non-working dates)
    while (currentDate <= end) {
        const dayOfWeek = currentDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
        const dateString = currentDate.toDateString();
        // Count only weekdays (Monday to Saturday) that are not in non-working dates
        if (dayOfWeek !== 0 && !nonWorkingDates.has(dateString)) {
            workingDays++;
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    // Calculate weeks (rounded up)
    const timeDiff = end.getTime() - startDate.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    const weeks = Math.ceil(daysDiff / 7);
    return { workingDays, weeks };
}
exports.AcademicCalendar = mongoose_1.default.model('AcademicCalendar', academicCalendarSchema, "academic_calendar");
exports.default = exports.AcademicCalendar;
