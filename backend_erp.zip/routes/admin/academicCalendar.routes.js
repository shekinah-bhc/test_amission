"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const academicCalendar_controller_1 = require("../../controllers/admin/academicCalendar.controller");
const router = express_1.default.Router();
/**
 * @swagger
 * components:
 *   schemas:
 *     AcademicCalendar:
 *       type: object
 *       required:
 *         - academicYear
 *       properties:
 *         _id:
 *           type: string
 *           description: Auto-generated ID
 *         academicYear:
 *           type: string
 *           description: Academic year in format "YYYY-YYYY"
 *         sem_odd:
 *           type: object
 *           properties:
 *             startDate:
 *               type: string
 *               format: date
 *             endDate:
 *               type: string
 *               format: date
 *             exams:
 *               type: object
 *               properties:
 *                 internal1:
 *                   $ref: '#/components/schemas/Exam'
 *                 internal2:
 *                   $ref: '#/components/schemas/Exam'
 *                 practical:
 *                   $ref: '#/components/schemas/Exam'
 *                 ese:
 *                   $ref: '#/components/schemas/Exam'
 *             holidays:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Holiday'
 *             events:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Event'
 *             metadata:
 *               $ref: '#/components/schemas/SemesterMetadata'
 *         sem_even:
 *           type: object
 *           properties:
 *             startDate:
 *               type: string
 *               format: date
 *             endDate:
 *               type: string
 *               format: date
 *             exams:
 *               type: object
 *             holidays:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Holiday'
 *             events:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Event'
 *             metadata:
 *               $ref: '#/components/schemas/SemesterMetadata'
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 *
 *     Exam:
 *       type: object
 *       required:
 *         - startDate
 *         - endDate
 *         - title
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *         endDate:
 *           type: string
 *           format: date
 *         title:
 *           type: string
 *         description:
 *           type: string
 *         remarks:
 *           type: string
 *         createdBy:
 *           type: string
 *
 *     Holiday:
 *       type: object
 *       required:
 *         - title
 *         - startDate
 *         - endDate
 *         - holidayType
 *       properties:
 *         title:
 *           type: string
 *         description:
 *           type: string
 *         remarks:
 *           type: string
 *         startDate:
 *           type: string
 *           format: date
 *         endDate:
 *           type: string
 *           format: date
 *         holidayType:
 *           type: string
 *           enum: [National, College]
 *         createdBy:
 *           type: string
 *         _id:
 *           type: string
 *
 *     Event:
 *       type: object
 *       required:
 *         - title
 *         - startDate
 *         - endDate
 *         - eventType
 *       properties:
 *         title:
 *           type: string
 *         description:
 *           type: string
 *         remarks:
 *           type: string
 *         startDate:
 *           type: string
 *           format: date
 *         endDate:
 *           type: string
 *           format: date
 *         eventType:
 *           type: string
 *           enum: [Sports, Department, Staff, Student, Common Events]
 *         createdBy:
 *           type: string
 *         _id:
 *           type: string
 *
 *     SemesterMetadata:
 *       type: object
 *       properties:
 *         nationalHolidays:
 *           type: number
 *         collegeHolidays:
 *           type: number
 *         sportsEvents:
 *           type: number
 *         departmentEvents:
 *           type: number
 *         staffEvents:
 *           type: number
 *         studentEvents:
 *           type: number
 *         commonEvents:
 *           type: number
 *         totalWorkingDays:
 *           type: number
 *         totalWeeks:
 *           type: number
 *
 *     SemesterDates:
 *       type: object
 *       required:
 *         - startDate
 *         - endDate
 *       properties:
 *         startDate:
 *           type: string
 *           format: date
 *         endDate:
 *           type: string
 *           format: date
 *
 *     ApiResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *         message:
 *           type: string
 *         data:
 *           type: object
 *         error:
 *           type: string
 */
// Academic Calendar CRUD Routes
/**
 * @swagger
 * /academic_calendar:
 *   post:
 *     summary: Create a new academic calendar
 *     tags: [admin]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - academicYear
 *             properties:
 *               academicYear:
 *                 type: string
 *                 example: "2024-2025"
 *     responses:
 *       201:
 *         description: Academic calendar created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Academic calendar for this year already exists
 *       500:
 *         description: Internal server error
 */
router.post('/', academicCalendar_controller_1.createAcademicCalendar);
/**
 * @swagger
 * /academic_calendar:
 *   get:
 *     summary: Get all academic calendars
 *     tags: [admin]
 *     responses:
 *       200:
 *         description: List of all academic calendars
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AcademicCalendar'
 *       500:
 *         description: Internal server error
 */
router.get('/', academicCalendar_controller_1.getAllAcademicCalendars);
/**
 * @swagger
 * /academic_calendar/{academicYear}:
 *   get:
 *     summary: Get academic calendar by year
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *         description: Academic year in format "YYYY-YYYY"
 *     responses:
 *       200:
 *         description: Academic calendar found
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.get('/:academicYear', academicCalendar_controller_1.getAcademicCalendar);
/**
 * @swagger
 * /academic_calendar/{academicYear}:
 *   delete:
 *     summary: Delete academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *         description: Academic year in format "YYYY-YYYY"
 *     responses:
 *       200:
 *         description: Academic calendar deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:academicYear', academicCalendar_controller_1.deleteAcademicCalendar);
// Semester Dates Routes
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/dates:
 *   put:
 *     summary: Update semester start and end dates
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SemesterDates'
 *     responses:
 *       200:
 *         description: Semester dates updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester or date range
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.put('/:academicYear/:semester/dates', academicCalendar_controller_1.updateSemesterDates);
// Exam Routes
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/exams/{examType}:
 *   post:
 *     summary: Add exam to academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: examType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [internal1, internal2, practical, ese]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Exam'
 *     responses:
 *       200:
 *         description: Exam added successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester, exam type, or exam already exists
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.post('/:academicYear/:semester/exams/:examType', academicCalendar_controller_1.addExam);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/exams/{examType}:
 *   put:
 *     summary: Update exam in academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: examType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [internal1, internal2, practical, ese]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Exam'
 *     responses:
 *       200:
 *         description: Exam updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester or exam type
 *       404:
 *         description: Academic calendar or exam not found
 *       500:
 *         description: Internal server error
 */
router.put('/:academicYear/:semester/exams/:examType', academicCalendar_controller_1.updateExam);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/exams/{examType}:
 *   delete:
 *     summary: Delete exam from academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: examType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [internal1, internal2, practical, ese]
 *     responses:
 *       200:
 *         description: Exam deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester or exam type
 *       404:
 *         description: Academic calendar or exam not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:academicYear/:semester/exams/:examType', academicCalendar_controller_1.deleteExam);
// Holiday Routes
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/holidays:
 *   post:
 *     summary: Add holiday to academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Holiday'
 *     responses:
 *       200:
 *         description: Holiday added successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.post('/:academicYear/:semester/holidays', academicCalendar_controller_1.addHoliday);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/holidays/{holidayId}:
 *   put:
 *     summary: Update holiday in academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: holidayId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Holiday'
 *     responses:
 *       200:
 *         description: Holiday updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar or holiday not found
 *       500:
 *         description: Internal server error
 */
router.put('/:academicYear/:semester/holidays/:holidayId', academicCalendar_controller_1.updateHoliday);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/holidays/{holidayId}:
 *   delete:
 *     summary: Delete holiday from academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: holidayId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Holiday deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar or holiday not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:academicYear/:semester/holidays/:holidayId', academicCalendar_controller_1.deleteHoliday);
// Event Routes
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/events:
 *   post:
 *     summary: Add event to academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Event'
 *     responses:
 *       200:
 *         description: Event added successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar not found
 *       500:
 *         description: Internal server error
 */
router.post('/:academicYear/:semester/events', academicCalendar_controller_1.addEvent);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/events/{eventId}:
 *   put:
 *     summary: Update event in academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Event'
 *     responses:
 *       200:
 *         description: Event updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar or event not found
 *       500:
 *         description: Internal server error
 */
router.put('/:academicYear/:semester/events/:eventId', academicCalendar_controller_1.updateEvent);
/**
 * @swagger
 * /academic_calendar/{academicYear}/{semester}/events/{eventId}:
 *   delete:
 *     summary: Delete event from academic calendar
 *     tags: [admin]
 *     parameters:
 *       - in: path
 *         name: academicYear
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: semester
 *         required: true
 *         schema:
 *           type: string
 *           enum: [sem_odd, sem_even]
 *       - in: path
 *         name: eventId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Event deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid semester
 *       404:
 *         description: Academic calendar or event not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:academicYear/:semester/events/:eventId', academicCalendar_controller_1.deleteEvent);
exports.default = router;
