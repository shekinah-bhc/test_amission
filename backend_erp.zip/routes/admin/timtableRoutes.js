"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const TimetableController_1 = require("../../controllers/admin/TimetableController");
const multer_1 = __importDefault(require("multer"));
const upload = (0, multer_1.default)({ dest: "uploads/" });
const router = express_1.default.Router();
// GET routes for timetable data
router.get('/', TimetableController_1.getTimetableByFilters);
// PUT routes for updating timetable
router.put('/update/:departmentName/:programId/:year/:sectionName/:dayOrder/:hour', TimetableController_1.updateTimetableHour);
router.put('/clear/:departmentName/:programId/:year/:sectionName/:dayOrder/:hour', TimetableController_1.clearTimetableHour);
// POST route for bulk update
router.post('/bulk-update', TimetableController_1.bulkUpdateTimetable);
// Get all sections for a specific programs   
router.get('/section/:programCode/:sectionName/:currentYear', TimetableController_1.getSectionTimetable);
// Get specific department by name
router.get('/departments/:departmentName', TimetableController_1.getOneDepartments);
router.get('/programs', TimetableController_1.getProgramsByDepartment);
router.get('/years', TimetableController_1.getYearsByDepartmentAndProgram);
router.get('/sections', TimetableController_1.getSectionsByDepartmentProgramAndYear);
router.delete("/reset-all", TimetableController_1.resetAllDepartmentTimetables);
// 🔹 Reset timetable for ONE department
router.delete("/reset/:department_code", TimetableController_1.resetDepartmentTimetable);
router.post("/timetable/migrate", upload.single("file"), // field name MUST be "file"
TimetableController_1.migrateCsvToTimeTable);
exports.default = router;
// import express from 'express';
// import {
//   getTimetableByFilters,
//   updateTimetableHour,
//   clearTimetableHour,
//   bulkUpdateTimetable,
//   getOneDepartments,
//   getSectionTimetable,
//   getProgramsByDepartment,
//   getYearsByDepartmentAndProgram,
//   getSectionsByDepartmentProgramAndYear,
//   getStudentTimetable,
//   getStaffTimetable,
//   getAllStaffWithAssignments
// } from '../../controllers/admin/TimetableController.js';
// const router = express.Router();
// /**
//  * @swagger
//  * tags:
//  *   - name: Departments
//  *     description: Department management endpoints
//  *   - name: Timetable
//  *     description: Timetable management endpoints
//  *   - name: Staff
//  *     description: Staff timetable endpoints
//  *   - name: Student
//  *     description: Student timetable endpoints
//  */
// // ==================== DEPARTMENT ROUTES ====================
// /**
//  * @swagger
//  * /api/departments:
//  *   get:
//  *     summary: Get all departments or a specific department
//  *     tags: [Departments]
//  *     parameters:
//  *       - in: path
//  *         name: departmentName
//  *         required: false
//  *         schema:
//  *           type: string
//  *         description: Department name (optional)
//  *     responses:
//  *       200:
//  *         description: Departments retrieved successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 message:
//  *                   type: string
//  *                 data:
//  *                   type: array
//  *                   items:
//  *                     type: object
//  *                     properties:
//  *                       department_code:
//  *                         type: string
//  *                       department_name:
//  *                         type: string
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/departments/:departmentName?', getOneDepartments);
// /**
//  * @swagger
//  * /api/programs:
//  *   get:
//  *     summary: Get programs by department
//  *     tags: [Departments]
//  *     parameters:
//  *       - in: query
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *     responses:
//  *       200:
//  *         description: Programs retrieved successfully
//  *       400:
//  *         description: Department name is required
//  *       404:
//  *         description: Department not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/programs', getProgramsByDepartment);
// /**
//  * @swagger
//  * /api/years:
//  *   get:
//  *     summary: Get years by department and program
//  *     tags: [Departments]
//  *     parameters:
//  *       - in: query
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *       - in: query
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *     responses:
//  *       200:
//  *         description: Years retrieved successfully
//  *       400:
//  *         description: Department name and program ID are required
//  *       404:
//  *         description: Department or program not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/years', getYearsByDepartmentAndProgram);
// /**
//  * @swagger
//  * /api/sections:
//  *   get:
//  *     summary: Get sections by department, program and year
//  *     tags: [Departments]
//  *     parameters:
//  *       - in: query
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *       - in: query
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *       - in: query
//  *         name: year
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Academic year
//  *     responses:
//  *       200:
//  *         description: Sections retrieved successfully
//  *       400:
//  *         description: Department name, program ID and year are required
//  *       404:
//  *         description: Department, program or year not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/sections', getSectionsByDepartmentProgramAndYear);
// // ==================== TIMETABLE MANAGEMENT ROUTES ====================
// /**
//  * @swagger
//  * /api/timetable/filters:
//  *   get:
//  *     summary: Get timetable by multiple filters
//  *     tags: [Timetable]
//  *     parameters:
//  *       - in: query
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *       - in: query
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *       - in: query
//  *         name: year
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Academic year
//  *       - in: query
//  *         name: sectionName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Section name
//  *     responses:
//  *       200:
//  *         description: Timetable retrieved successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 message:
//  *                   type: string
//  *                 data:
//  *                   type: object
//  *                   properties:
//  *                     department:
//  *                       type: object
//  *                       properties:
//  *                         _id:
//  *                           type: string
//  *                         department_code:
//  *                           type: string
//  *                         department_name:
//  *                           type: string
//  *                     program:
//  *                       type: object
//  *                       properties:
//  *                         program_id:
//  *                           type: string
//  *                         program_name:
//  *                           type: string
//  *                     year:
//  *                       type: integer
//  *                     section:
//  *                       type: object
//  *                       properties:
//  *                         section_name:
//  *                           type: string
//  *                         section_shift:
//  *                           type: string
//  *                         TimeTable:
//  *                           type: array
//  *                           items:
//  *                             type: object
//  *       400:
//  *         description: Missing required parameters
//  *       404:
//  *         description: Department, program, year or section not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/timetable/filters', getTimetableByFilters);
// /**
//  * @swagger
//  * /api/timetable/section/{programName}/{sectionName}/{currentYear}:
//  *   get:
//  *     summary: Get section timetable by program name and section
//  *     tags: [Timetable]
//  *     parameters:
//  *       - in: path
//  *         name: programName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program name
//  *       - in: path
//  *         name: sectionName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Section name
//  *       - in: path
//  *         name: currentYear
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Current academic year
//  *     responses:
//  *       200:
//  *         description: Section timetable retrieved successfully
//  *       400:
//  *         description: Program name and section name are required
//  *       404:
//  *         description: Section timetable not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/timetable/section/:programName/:sectionName/:currentYear', getSectionTimetable);
// /**
//  * @swagger
//  * /api/timetable/update/{departmentName}/{programId}/{year}/{sectionName}/{dayOrder}/{hour}:
//  *   put:
//  *     summary: Update a specific hour in timetable
//  *     tags: [Timetable]
//  *     parameters:
//  *       - in: path
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *       - in: path
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *       - in: path
//  *         name: year
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Academic year
//  *       - in: path
//  *         name: sectionName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Section name
//  *       - in: path
//  *         name: dayOrder
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Day order (1-7)
//  *       - in: path
//  *         name: hour
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Hour slot (1-8)
//  *     requestBody:
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             type: object
//  *             properties:
//  *               staff_id:
//  *                 type: string
//  *                 description: Staff ID
//  *               staffName:
//  *                 type: string
//  *                 description: Staff name
//  *               course_code:
//  *                 type: string
//  *                 description: Course code
//  *               course_title:
//  *                 type: string
//  *                 description: Course title
//  *               course_type:
//  *                 type: string
//  *                 description: Course type (Theory/Lab)
//  *               language_type:
//  *                 type: string
//  *                 description: Language type (English/Other)
//  *               room:
//  *                 type: string
//  *                 description: Room number
//  *     responses:
//  *       200:
//  *         description: Timetable updated successfully
//  *       400:
//  *         description: Missing required parameters or invalid fields
//  *       404:
//  *         description: Department, program, year, section, day or hour not found
//  *       500:
//  *         description: Internal server error
//  */
// router.put('/timetable/update/:departmentName/:programId/:year/:sectionName/:dayOrder/:hour', updateTimetableHour);
// /**
//  * @swagger
//  * /api/timetable/clear/{departmentName}/{programId}/{year}/{sectionName}/{dayOrder}/{hour}:
//  *   delete:
//  *     summary: Clear a specific hour in timetable
//  *     tags: [Timetable]
//  *     parameters:
//  *       - in: path
//  *         name: departmentName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department name
//  *       - in: path
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *       - in: path
//  *         name: year
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Academic year
//  *       - in: path
//  *         name: sectionName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Section name
//  *       - in: path
//  *         name: dayOrder
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Day order (1-7)
//  *       - in: path
//  *         name: hour
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Hour slot (1-8)
//  *     responses:
//  *       200:
//  *         description: Timetable hour cleared successfully
//  *       400:
//  *         description: Missing required parameters
//  *       404:
//  *         description: Department, program, year, section, day or hour not found
//  *       500:
//  *         description: Internal server error
//  */
// router.delete('/timetable/clear/:departmentName/:programId/:year/:sectionName/:dayOrder/:hour', clearTimetableHour);
// /**
//  * @swagger
//  * /api/timetable/bulk-update:
//  *   put:
//  *     summary: Bulk update timetable hours
//  *     tags: [Timetable]
//  *     requestBody:
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             type: object
//  *             required:
//  *               - departmentName
//  *               - programId
//  *               - year
//  *               - sectionName
//  *               - updates
//  *             properties:
//  *               departmentName:
//  *                 type: string
//  *                 description: Department name
//  *               programId:
//  *                 type: string
//  *                 description: Program ID
//  *               year:
//  *                 type: integer
//  *                 description: Academic year
//  *               sectionName:
//  *                 type: string
//  *                 description: Section name
//  *               updates:
//  *                 type: array
//  *                 items:
//  *                   type: object
//  *                   required:
//  *                     - dayOrder
//  *                     - hour
//  *                     - updateData
//  *                   properties:
//  *                     dayOrder:
//  *                       type: integer
//  *                       description: Day order (1-7)
//  *                     hour:
//  *                       type: integer
//  *                       description: Hour slot (1-8)
//  *                     updateData:
//  *                       type: object
//  *                       properties:
//  *                         staff_id:
//  *                           type: string
//  *                         staffName:
//  *                           type: string
//  *                         course_code:
//  *                           type: string
//  *                         course_title:
//  *                           type: string
//  *                         course_type:
//  *                           type: string
//  *                         language_type:
//  *                           type: string
//  *                         room:
//  *                           type: string
//  *     responses:
//  *       200:
//  *         description: Timetable bulk updated successfully
//  *       400:
//  *         description: Missing required parameters
//  *       404:
//  *         description: Department, program, year or section not found
//  *       500:
//  *         description: Internal server error
//  */
// router.put('/timetable/bulk-update', bulkUpdateTimetable);
// // ==================== STUDENT ROUTES ====================
// /**
//  * @swagger
//  * /api/timetable/student:
//  *   get:
//  *     summary: Get student timetable
//  *     tags: [Student]
//  *     parameters:
//  *       - in: query
//  *         name: departmentCode
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Department code
//  *       - in: query
//  *         name: programId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Program ID
//  *       - in: query
//  *         name: year
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: Academic year
//  *       - in: query
//  *         name: sectionName
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Section name
//  *     responses:
//  *       200:
//  *         description: Student timetable retrieved successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 message:
//  *                   type: string
//  *                 data:
//  *                   type: object
//  *                   properties:
//  *                     department:
//  *                       type: object
//  *                       properties:
//  *                         department_code:
//  *                           type: string
//  *                         department_name:
//  *                           type: string
//  *                     program:
//  *                       type: object
//  *                       properties:
//  *                         program_id:
//  *                           type: string
//  *                         program_name:
//  *                           type: string
//  *                     year:
//  *                       type: integer
//  *                     section:
//  *                       type: object
//  *                       properties:
//  *                         section_name:
//  *                           type: string
//  *                         section_shift:
//  *                           type: string
//  *                         TimeTable:
//  *                           type: array
//  *       400:
//  *         description: Missing required parameters
//  *       404:
//  *         description: Department, program, year or section not found
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/timetable/student', getStudentTimetable);
// // ==================== STAFF ROUTES ====================
// /**
//  * @swagger
//  * /api/timetable/staff/{staffId}:
//  *   get:
//  *     summary: Get staff timetable by staff ID
//  *     tags: [Staff]
//  *     parameters:
//  *       - in: path
//  *         name: staffId
//  *         required: true
//  *         schema:
//  *           type: string
//  *         description: Staff ID
//  *     responses:
//  *       200:
//  *         description: Staff timetable retrieved successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 message:
//  *                   type: string
//  *                 data:
//  *                   type: array
//  *                   items:
//  *                     type: object
//  *                     properties:
//  *                       department:
//  *                         type: object
//  *                         properties:
//  *                           department_code:
//  *                             type: string
//  *                           department_name:
//  *                             type: string
//  *                       program:
//  *                         type: object
//  *                         properties:
//  *                           program_id:
//  *                             type: string
//  *                           program_name:
//  *                             type: string
//  *                       year:
//  *                         type: integer
//  *                       section:
//  *                         type: object
//  *                         properties:
//  *                           section_name:
//  *                             type: string
//  *                           section_shift:
//  *                             type: string
//  *                       day:
//  *                         type: object
//  *                         properties:
//  *                           dayOrder:
//  *                             type: integer
//  *                           hour:
//  *                             type: integer
//  *                       course:
//  *                         type: object
//  *                         properties:
//  *                           course_code:
//  *                             type: string
//  *                           course_title:
//  *                             type: string
//  *                           course_type:
//  *                             type: string
//  *                           language_type:
//  *                             type: string
//  *                           room:
//  *                             type: string
//  *       400:
//  *         description: Staff ID is required
//  *       404:
//  *         description: No timetable entries found for this staff member
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/timetable/staff/:staffId', getStaffTimetable);
// /**
//  * @swagger
//  * /api/timetable/staff-assignments:
//  *   get:
//  *     summary: Get all staff members with their assigned courses
//  *     tags: [Staff]
//  *     responses:
//  *       200:
//  *         description: Staff assignments retrieved successfully
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 message:
//  *                   type: string
//  *                 data:
//  *                   type: array
//  *                   items:
//  *                     type: object
//  *                     properties:
//  *                       staff_id:
//  *                         type: string
//  *                       staffName:
//  *                         type: string
//  *                       assignments:
//  *                         type: array
//  *                         items:
//  *                           type: object
//  *                           properties:
//  *                             department:
//  *                               type: string
//  *                             program:
//  *                               type: string
//  *                             year:
//  *                               type: integer
//  *                             section:
//  *                               type: string
//  *                             dayOrder:
//  *                               type: integer
//  *                             hour:
//  *                               type: integer
//  *                             course_code:
//  *                               type: string
//  *                             course_title:
//  *                               type: string
//  *                             course_type:
//  *                               type: string
//  *                             language_type:
//  *                               type: string
//  *                             room:
//  *                               type: string
//  *       500:
//  *         description: Internal server error
//  */
// router.get('/timetable/staff-assignments', getAllStaffWithAssignments);
// export default router;
