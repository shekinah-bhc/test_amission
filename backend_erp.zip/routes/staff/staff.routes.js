"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const staff_controller_1 = require("../../controllers/staff/staff.controller");
const stafflogin_controller_1 = require("../../controllers/staff/stafflogin.controller");
const staffSync_controller_1 = require("../../controllers/admin/staffSync.controller");
const router = (0, express_1.Router)();
router.post("/", staff_controller_1.createStaff);
router.get("/", staff_controller_1.getAllStaff);
router.get("/:id", staff_controller_1.getStaffById);
router.put("/:id", staff_controller_1.updateStaff);
router.delete("/:id", staff_controller_1.deleteStaff);
//=============== Update Publications and Academics ==================== \\
router.get("/publications/:staff_id", staff_controller_1.getPublications);
router.put("/publications/:staff_id/:publication_type/:publication_id", staff_controller_1.updatePublicationItem);
router.post("/publications/:staff_id/:publication_type", staff_controller_1.addPublicationItem);
router.delete("/publications/:staff_id/:publication_type/:publication_id", staff_controller_1.deletePublicationItem);
router.post("/upload-csv", staff_controller_1.uploadStaffCSV);
router.post("/fix-department-codes/bulk", staff_controller_1.fixAllStaffDepartmentCodes); // set department code using department model
router.post("/allTimeTableSync", staffSync_controller_1.syncAllStaffsTimeTable);
router.get("/sync-timetable/:staff_id", staffSync_controller_1.updateStaffClassAttend);
router.get("/attendance/:bio_id", staff_controller_1.getAllAttendanceStatusByBioId);
router.get("/staff-timing/:bio_id", staff_controller_1.getStaffTimingByBioId);
router.get('/login/:staff_id', stafflogin_controller_1.staffLogin);
router.post('/login/otp/', stafflogin_controller_1.verifyStaffOtp);
exports.default = router;
