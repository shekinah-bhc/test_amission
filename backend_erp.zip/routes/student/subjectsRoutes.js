"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const studentSubjectsController_1 = __importDefault(require("../../controllers/student/studentSubjectsController"));
const router = express_1.default.Router();
/**
 * @swagger
 * /students/subjects:
 *   post:
 *     summary: Get subjects assigned to a student section
 *     tags: [Student Subjects]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - program_name
 *               - year
 *               - section_name
 *             properties:
 *               program_name:
 *                 type: string
 *                 example: "B.Sc Computer Science"
 *               year:
 *                 type: integer
 *                 example: 1
 *               section_name:
 *                 type: string
 *                 example: "A"
 *     responses:
 *       200:
 *         description: Successfully fetched subjects
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     department_name:
 *                       type: string
 *                       example: "Computer Science"
 *                     department_code:
 *                       type: string
 *                       example: "CS"
 *                     program_name:
 *                       type: string
 *                       example: "B.Sc Computer Science"
 *                     year:
 *                       type: number
 *                       example: 1
 *                     section_name:
 *                       type: string
 *                       example: "A"
 *                     section_shift:
 *                       type: string
 *                       example: "Morning"
 *                     totalSubjects:
 *                       type: number
 *                       example: 5
 *                     subjects:
 *                       type: array
 *                       items:
 *                         $ref: "#/components/schemas/SubjectInfo"
 *       400:
 *         description: Missing required parameters
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Missing required parameters: program_name, year, section_name"
 *       404:
 *         description: No subjects found or invalid data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Program 'B.Sc Computer Science' not found"
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: "Failed to fetch student subjects"
 *                 error:
 *                   type: string
 *                   example: "Error message details"
 */
router.post("/", studentSubjectsController_1.default.getStudentSubjects);
/**
 * @swagger
 * /students/subjects/student-subjects/schedule:
 *   get:
 *     summary: Get subjects with timetable schedule
 *     tags: [Student Subjects]
 *     parameters:
 *       - name: program_name
 *         in: query
 *         required: true
 *         schema:
 *           type: string
 *           example: "B.Sc Computer Science"
 *       - name: year
 *         in: query
 *         required: true
 *         schema:
 *           type: integer
 *           example: 1
 *       - name: section_name
 *         in: query
 *         required: true
 *         schema:
 *           type: string
 *           example: "A"
 *     responses:
 *       200:
 *         description: Subject schedule data retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     department_name:
 *                       type: string
 *                       example: "Computer Science"
 *                     department_code:
 *                       type: string
 *                       example: "CS"
 *                     program_name:
 *                       type: string
 *                       example: "B.Sc Computer Science"
 *                     year:
 *                       type: number
 *                       example: 1
 *                     section_name:
 *                       type: string
 *                       example: "A"
 *                     section_shift:
 *                       type: string
 *                       example: "Morning"
 *                     totalSubjects:
 *                       type: number
 *                       example: 5
 *                     subjects:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           dayOrder:
 *                             type: number
 *                             example: 1
 *                           hour:
 *                             type: number
 *                             example: 1
 *                           course_code:
 *                             type: string
 *                             example: "CS101"
 *                           course_title:
 *                             type: string
 *                             example: "Introduction to Computer Science"
 *                           course_type:
 *                             type: string
 *                             example: "Theory"
 *                           staff_id:
 *                             type: string
 *                             example: "STAFF001"
 *                           staffName:
 *                             type: string
 *                             example: "John Doe"
 *                           language_type:
 *                             type: string
 *                             example: "English"
 *                           room:
 *                             type: string
 *                             example: "Lab-101"
 *                           isScheduled:
 *                             type: boolean
 *                             example: true
 *       400:
 *         description: Missing required parameters
 *       404:
 *         description: No subjects found
 *       500:
 *         description: Server error
 */
router.get("/student-subjects/schedule", studentSubjectsController_1.default.getStudentSubjectsWithSchedule);
/**
 * @swagger
 * /students/subjects/student-subjects/unique:
 *   get:
 *     summary: Get unique subject list (no duplicates)
 *     tags: [Student Subjects]
 *     parameters:
 *       - name: program_name
 *         in: query
 *         required: true
 *         schema:
 *           type: string
 *           example: "B.Sc Computer Science"
 *       - name: year
 *         in: query
 *         required: true
 *         schema:
 *           type: integer
 *           example: 1
 *       - name: section_name
 *         in: query
 *         required: true
 *         schema:
 *           type: string
 *           example: "A"
 *     responses:
 *       200:
 *         description: Unique subjects fetched successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     department_name:
 *                       type: string
 *                       example: "Computer Science"
 *                     department_code:
 *                       type: string
 *                       example: "CS"
 *                     program_name:
 *                       type: string
 *                       example: "B.Sc Computer Science"
 *                     year:
 *                       type: number
 *                       example: 1
 *                     section_name:
 *                       type: string
 *                       example: "A"
 *                     section_shift:
 *                       type: string
 *                       example: "Morning"
 *                     totalSubjects:
 *                       type: number
 *                       example: 5
 *                     subjects:
 *                       type: array
 *                       items:
 *                         $ref: "#/components/schemas/SubjectInfo"
 *       400:
 *         description: Missing required parameters
 *       404:
 *         description: No subjects found
 *       500:
 *         description: Server error
 */
router.get("/student-subjects/unique", studentSubjectsController_1.default.getUniqueStudentSubjects);
exports.default = router;
/**
 * @swagger
 * components:
 *   schemas:
 *     SubjectInfo:
 *       type: object
 *       properties:
 *         course_code:
 *           type: string
 *           example: "CS101"
 *         course_title:
 *           type: string
 *           example: "Introduction to Computer Science"
 *         course_type:
 *           type: string
 *           example: "Theory"
 *         staff_id:
 *           type: string
 *           example: "STAFF001"
 *         staffName:
 *           type: string
 *           example: "John Doe"
 *         language_type:
 *           type: string
 *           example: "English"
 *
 *   responses:
 *     NotFound:
 *       description: Resource not found
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               success:
 *                 type: boolean
 *                 example: false
 *               message:
 *                 type: string
 *                 example: "Program not found"
 *
 *     BadRequest:
 *       description: Bad request
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               success:
 *                 type: boolean
 *                 example: false
 *               message:
 *                 type: string
 *                 example: "Missing required parameters"
 *
 *     ServerError:
 *       description: Internal server error
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               success:
 *                 type: boolean
 *                 example: false
 *               message:
 *                 type: string
 *               error:
 *                 type: string
 */
/**
 * @swagger
 * tags:
 *   - name: Student Subjects
 *     description: Student subjects and timetable management
 */ 
