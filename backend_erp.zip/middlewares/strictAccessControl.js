"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.strictAccessControl = strictAccessControl;
const allowedHosts = [
    "192.168.12.135",
    "117.232.64.75",
    "157.51.42.253",
    "localhost",
    "localhost:5173",
    "localhost:5174",
    "localhost:5175",
    "localhost:5000",
    "localhost:5001",
    "localhost:3000",
    "localhost:3001",
    "http://10.240.151.162",
    "http://10.227.250.162",
];
function strictAccessControl(req, res, next) {
    const referer = req.headers.referer;
    const host = req.headers.host;
    console.log('Request Referer:', referer);
    console.log('Request Host:', host);
    console.log('Request Path:', req.path);
    console.log('Request Method:', req.method);
    if (req.path.startsWith("/api/api-docs"))
        return next();
    if (!referer && host && allowedHosts.includes(host)) {
        console.log('Blocking: Direct API access detected');
        return res.status(403).json({
            message: "Direct API access is not allowed",
            details: "Please access the API through the authorized frontend application"
        });
    }
    if (referer) {
        try {
            const refererUrl = new URL(referer);
            const refererHost = refererUrl.host;
            if (allowedHosts.includes(refererHost)) {
                console.log('Allowing: Valid referer detected');
                return next();
            }
        }
        catch (e) {
            console.error('Error parsing referer:', e);
        }
    }
    if (host && allowedHosts.includes(host)) {
        console.log('Allowing: Valid host detected');
        return next();
    }
    console.log('Blocking: No valid access method detected');
    return res.status(403).json({
        message: "Forbidden: Access not allowed",
        details: "API can only be accessed from approved frontend applications"
    });
}
