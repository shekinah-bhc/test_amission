"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSwagger = void 0;
const swagger_jsdoc_1 = __importDefault(require("swagger-jsdoc"));
const swagger_ui_express_1 = __importDefault(require("swagger-ui-express"));
const path_1 = __importDefault(require("path"));
const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Heber ERP API SYSTEM',
            version: '2.1.3',
            description: 'API Documentation for Heber Server - Separate Student and Admin APIs',
        },
        servers: [
            {
                url: 'http://localhost:5000/',
                description: 'Student API Server - All student related endpoints',
            }
        ],
        tags: [
            {
                name: 'common',
                description: 'Common endpoints accessible from both servers',
            },
            {
                name: 'student',
                description: 'Student related endpoints',
            },
            {
                name: 'admin',
                description: 'Administrator endpoints',
            }
        ],
    },
    apis: [path_1.default.join(__dirname, "routes/**/*.ts")],
};
const specs = (0, swagger_jsdoc_1.default)(options);
const swaggerOptions = {
    customCss: `
    .topbar-wrapper .link { display: none }
    .swagger-ui .topbar { display: none }
    .swagger-ui .info .title { color: #333; font-size: 24px; }
    .swagger-ui .info { margin: 20px 0; }
    
    /* Remove Swagger logo completely */
    .topbar-wrapper img { display: none !important; }
    .swagger-ui .topbar a { display: none !important; }
    
    /* Optional: Add your own logo */
    .topbar-wrapper .link::after {
      content: "Heber API";
      font-size: 1.5em;
      font-weight: bold;
      color: #333;
    }
    
    /* Style servers dropdown */
    .swagger-ui .scheme-container {
      background-color: #fafafa;
      border-bottom: 1px solid #ccc;
    }
  `,
    customSiteTitle: "Heber API",
    customfavIcon: "/favicon.ico",
};
const protectSwagger = (req, res, next) => {
    const auth = { login: 'admin', password: 'heber123' };
    const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');
    if (login === auth.login && password === auth.password) {
        return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="Heber ERP API Docs"');
    res.status(401).send('Authentication required');
};
const setupSwagger = (app) => {
    app.use('/api-docs', protectSwagger, swagger_ui_express_1.default.serve, swagger_ui_express_1.default.setup(specs, swaggerOptions));
};
exports.setupSwagger = setupSwagger;
