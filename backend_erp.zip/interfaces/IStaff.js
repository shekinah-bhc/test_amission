"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleEnum = void 0;
exports.RoleEnum = [
    "admin",
    "faculty",
    "mentor",
    "principal",
    "hod",
    "staff",
    "teaching staff",
    "non teaching staff",
];
